advancement revoke @s only electric:raw

summon lightning_bolt ~ ~ ~