advancement revoke @s only electric:roasted

tag @s add eletric
scoreboard players set @s eletric_timer 200