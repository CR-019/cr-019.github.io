particle electric_spark ~ ~0.5 ~ 0.4 0.6 0.4 0 20

execute if score @s eletric_timer matches 1.. run return run scoreboard players remove @s eletric_timer 1

tag @s remove eletric
summon lightning_bolt ~ ~ ~
summon lightning_bolt ~1 ~ ~1
summon lightning_bolt ~-1 ~ ~-1
summon lightning_bolt ~1 ~ ~-1
summon lightning_bolt ~-1 ~ ~1