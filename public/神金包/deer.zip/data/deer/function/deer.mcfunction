execute if score @s deer_timer matches ..0 run particle cloud ~ ~0.7 ~ 0.1 0.1 0.1 0 80
execute if score @s deer_timer matches ..0 run damage @s 2000 indirect_magic by @s

scoreboard players remove @s deer_timer 1
effect give @s slowness 1 3 true

swing @s mainhand