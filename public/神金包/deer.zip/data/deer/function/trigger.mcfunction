execute if entity @s[type=player] run return fail
tag @s add deer

scoreboard players set @s deer_timer 40

particle cloud ~ ~0.7 ~ 0.1 0.1 0.1 0 20
