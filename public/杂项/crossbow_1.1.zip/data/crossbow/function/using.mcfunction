#使用中触发
advancement revoke @s only crossbow:using
scoreboard players set @s consume_use 1