#检测玩家
execute as @a at @s run function crossbow:tick_as_player