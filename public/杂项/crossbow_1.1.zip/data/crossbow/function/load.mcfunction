scoreboard objectives add consume_use dummy
scoreboard objectives add consume_use_lt dummy
scoreboard objectives add consume_timer dummy

scoreboard objectives add crossbow_type dummy