execute store result entity @n[tag=crossbow_temp] item.count int 0.99 run data get entity @n[tag=crossbow_temp] item.count

item replace entity @s weapon.offhand from entity @n[tag=crossbow_temp] contents