#判断是不是玩家射出的，如否直接返回
execute on origin unless entity @s[tag=crossbow_shot_player] run return fail

#检查箭内含物
function crossbow:arrows/predicates

#将箭替换为指定的物品
function crossbow:arrows/shot

#如果原本不是箭，则清理原始的箭
execute unless score @s crossbow_type matches 2 run kill @s