#如果可以放置，则通过宏命令检查，计分板被设置。
$setblock ~ 319 ~ $(id)
scoreboard players set @s crossbow_type 1
setblock ~ 319 ~ air