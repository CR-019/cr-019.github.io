## 替换为指定实体

#首先保存数据
#如果item和components分开，则使用这个数据，如果合并，则直接使用实体数据
data modify storage crossbow:item item set value {}
data modify storage crossbow:item item set from entity @s item
data modify storage crossbow:item item.Motion set from entity @s Motion
data modify storage crossbow:item item.Owner set from entity @s Owner
data modify storage crossbow:item item.Rotation set from entity @s Rotation

#如果是方块，替换为下落的方块
execute if score @s crossbow_type matches 1 run return run function crossbow:shot/block
#如果是箭，不做任何处理
execute if score @s crossbow_type matches 2 run return fail
#如果是TNT，替换为点燃的TNT
execute if score @s crossbow_type matches 3 run return run function crossbow:shot/tnt with entity @s
#如果是末影珍珠，替换为末影珍珠
execute if score @s crossbow_type matches 4 run return run function crossbow:shot/ender_pearl with entity @s
#雪球
execute if score @s crossbow_type matches 5 run return run function crossbow:shot/snowball with entity @s
#鸡蛋
execute if score @s crossbow_type matches 6 run return run function crossbow:shot/egg with entity @s
#风弹
execute if score @s crossbow_type matches 7 run return run function crossbow:shot/wind_charge with entity @s
#三叉戟
execute if score @s crossbow_type matches 8 run return run function crossbow:shot/trident with entity @s


#其他物品兼容等会再写...

#如果均不成立，则为普通物品，直接射出
#上面的都写了return，这里可以不用写（if-else结构）

function crossbow:shot/item with entity @s
