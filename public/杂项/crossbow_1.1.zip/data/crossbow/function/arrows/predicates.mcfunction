#前置准备（0-普通物品）
scoreboard players set @s crossbow_type 0

#检查方块
function crossbow:arrows/block with entity @s item
#检查箭
execute if items entity @s contents #crossbow:arrows run scoreboard players set @s crossbow_type 2
#检查TNT
execute if items entity @s contents tnt run scoreboard players set @s crossbow_type 3
#检查末影珍珠
execute if items entity @s contents ender_pearl run scoreboard players set @s crossbow_type 4
#检查雪球
execute if items entity @s contents snowball run scoreboard players set @s crossbow_type 5
#检查鸡蛋
execute if items entity @s contents #crossbow:eggs run scoreboard players set @s crossbow_type 6
#检查风弹
execute if items entity @s contents wind_charge run scoreboard players set @s crossbow_type 7
#检查三叉戟
execute if items entity @s contents trident run scoreboard players set @s crossbow_type 8
#难点：刷怪蛋怎么做

#可以写更多兼容，先放着...