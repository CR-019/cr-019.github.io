## 松开时触发

#将副手物品装进主手
summon item_display ~ ~ ~ {Tags:["crossbow_temp"]}
item replace entity @n[tag=crossbow_temp] contents from entity @s weapon.offhand

execute if data entity @n[tag=crossbow_temp] item.components run function crossbow:crossbow_load_components with entity @n[tag=crossbow_temp] item
execute unless data entity @n[tag=crossbow_temp] item.components run function crossbow:crossbow_load with entity @n[tag=crossbow_temp] item

#副手物品-1
execute unless entity @s[gamemode=creative] if data entity @n[tag=crossbow_temp] {item:{count:1}} run item replace entity @s weapon.offhand with air
execute unless entity @s[gamemode=creative] unless data entity @n[tag=crossbow_temp] {item:{count:1}} run function crossbow:offhand

kill @n[tag=crossbow_temp]