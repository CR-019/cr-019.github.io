#检测弓发射
execute if score @s consume_use matches 0 if score @s consume_use_lt matches 1 at @s run function crossbow:shot

#检测当前使用状态
scoreboard players operation @s consume_use_lt = @s consume_use
scoreboard players set @s consume_use 0

