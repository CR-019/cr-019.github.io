#TNT
$summon tnt ~ ~ ~ {Motion:$(Motion),owner:$(Owner),fuse:80}