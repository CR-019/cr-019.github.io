#雪球
$summon snowball ~ ~ ~ {Item:$(item),Motion:$(Motion),Owner:$(Owner)}