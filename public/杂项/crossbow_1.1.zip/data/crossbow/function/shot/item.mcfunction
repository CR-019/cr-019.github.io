#物品
$summon item ~ ~ ~ {Item:$(item),Motion:$(Motion)}