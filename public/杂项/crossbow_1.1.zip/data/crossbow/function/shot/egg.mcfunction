#鸡蛋
$summon egg ~ ~ ~ {Item:$(item),Motion:$(Motion),Owner:$(Owner)}