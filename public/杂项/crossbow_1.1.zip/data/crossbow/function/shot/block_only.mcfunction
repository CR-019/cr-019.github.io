#无方块实体数据的方块
$summon falling_block ~ ~ ~ {BlockState:{Name:"$(id)"},Motion:$(Motion)}