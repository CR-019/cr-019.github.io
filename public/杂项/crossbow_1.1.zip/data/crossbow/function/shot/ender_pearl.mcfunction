#末影珍珠
$summon ender_pearl ~ ~ ~ {Item:$(item),Motion:$(Motion),Owner:$(Owner)}