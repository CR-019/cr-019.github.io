# 判断有没有方块实体信息
execute if data entity @s item.components run return run function crossbow:shot/block_components with storage crossbow:item item
execute unless data entity @s item.components run return run function crossbow:shot/block_only with storage crossbow:item item