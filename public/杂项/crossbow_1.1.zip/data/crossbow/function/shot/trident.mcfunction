#三叉戟
$summon trident ~ ~ ~ {Item:$(item),Motion:$(Motion),Owner:$(Owner),Rotation:$(Rotation)}