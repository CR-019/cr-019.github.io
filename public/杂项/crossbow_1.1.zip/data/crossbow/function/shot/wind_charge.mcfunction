#风弹
$summon wind_charge ~ ~ ~ {Item:$(item),Motion:$(Motion),Owner:$(Owner)}