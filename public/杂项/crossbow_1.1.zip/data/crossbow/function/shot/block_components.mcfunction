#有方块实体数据的方块
$summon falling_block ~ ~ ~ {BlockState:{Name:"$(id)"},TileEntityData:{components:$(components)},Motion:$(Motion)}