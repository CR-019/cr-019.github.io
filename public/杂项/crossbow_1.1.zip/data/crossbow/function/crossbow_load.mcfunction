#替换主手的弩
$item replace entity @s weapon.mainhand with crossbow[charged_projectiles=[{id:"$(id)",count:1}],custom_data={crossbow_loaded:1b}]

