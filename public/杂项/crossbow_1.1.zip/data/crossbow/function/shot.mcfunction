#检测发射箭
advancement revoke @s only crossbow:shot


#抓取周围的箭
tag @s add crossbow_shot_player
execute as @e[type=arrow,distance=..5] at @s run function crossbow:arrows/trigger
tag @s remove crossbow_shot_player