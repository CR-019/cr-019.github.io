import json
from copy import deepcopy

def remove_outer_layer(data):
    """移除models结构的最外层嵌套"""
    return data['on_false']

def process_json(
    original_path,
    target_path,
    base_case_path,  # 基础case的访问路径，e.g. ['model','models',1,'cases',0,'model','models',0,'cases',0]
    insert_parent_path,  # 插入新块的父节点路径
    num_new_blocks=9,
    time_pattern="s",
    special_last_block=True
):
    """处理JSON结构扩展的通用函数
    
    :param base_case_path: 基础case节点的JSON访问路径（交替使用字典键和列表索引）
    :param insert_parent_path: 新块需要插入的父节点路径
    :param num_new_blocks: 需要生成的新块数量
    :param time_pattern: 时间匹配模式，默认为秒"s"
    :param special_last_block: 是否特殊处理最后一个时间块
    """
    # 加载原始文件
    with open(original_path, 'r') as f:
        data = json.load(f)
    
    # ---------- 定位基础case节点 ----------
    def get_node(root, path):
        current = root
        for key in path:
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list) and isinstance(key, int):
                current = current[key]
            else:
                raise ValueError(f"无效路径: {path}")
        return current
    
    base_case = get_node(data, base_case_path)
    current_models_ref = deepcopy(base_case)

    # ---------- 生成新时间块 ----------
    new_models = []
    for i in range(1, num_new_blocks):
        # 复制基础结构并移除外层
        current_models_ref['model'] = current_models_ref['model']['on_false']
        #计算when
        for n in range(len(current_models_ref['when']),1,-1):
            if (n % (num_new_blocks+1-i) == 0): 
                del current_models_ref['when'][n-1]

        new_case = deepcopy(current_models_ref)
        
        new_models.append({
            "type": "select",
            "property": "local_time",
            "fallback": {"type": "empty"},
            "pattern": time_pattern,
            "cases": [new_case]
        })
    
    # ---------- 插入新块 ----------
    parent_node = get_node(data, insert_parent_path)
    parent_node.extend(new_models)
    
    # 保存文件
    with open(target_path, 'w') as f:
        json.dump(data, f, indent=4)

# 使用示例（对应原题需求）：
process_json(
    original_path='test/elytra.json',
    target_path='assets/minecraft/items/elytra.json',
     base_case_path=[
        'model', 'models', 1, 'cases', 0,  # 定位到第一个case
        'model', 'on_false',  # 进入condition的on_false分支
        'models', 0,  # 进入composite的models列表
        'cases', 0  # 定位到第一个时间选择块
    ],
    insert_parent_path=[
        'model', 'models', 1, 'cases', 0,  # 定位到第一个case
        'model', 'on_false',  # 进入condition的on_false分支
        'models'  # 插入到composite的models列表中
    ],
    num_new_blocks=4,
    special_last_block=True
)