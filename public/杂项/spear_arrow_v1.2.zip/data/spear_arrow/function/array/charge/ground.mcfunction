tag @s add spear_arrow_array_player_ground
tag @s add spear_arrow_array_player_ground_temp

schedule function spear_arrow:array/charge/main_ground 12t