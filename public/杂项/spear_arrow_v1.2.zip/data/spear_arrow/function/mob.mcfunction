tag @s add parched_detected

scoreboard players set #temp spear_cal_temp 0
execute on vehicle if entity @s[type=camel_husk] run scoreboard players set #temp spear_cal_temp 1
execute if predicate {condition:"random_chance",chance:0.2} run scoreboard players set #temp spear_cal_temp 1

execute if score #temp spear_cal_temp matches 1 run loot replace entity @s weapon.offhand loot spear_arrow:spears