scoreboard objectives add spear_arrow_timer dummy
scoreboard objectives add spear_arrow_damage dummy
scoreboard objectives add spear_arrow_array dummy
scoreboard objectives add spear_effect_timer dummy