$execute as @e[distance=..5,type=!item,type=!item_frame,tag=!spear_arrow_array_owner] run damage @s $(damage) spear by @n[tag=spear_arrow_array_owner] 
