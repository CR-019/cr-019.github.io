#识别类型
execute as @s[tag=spear_effect_spear_1] run function spear_arrow:array/effect/spear_1/tick

execute as @s[tag=spear_effect_spear_2] run function spear_arrow:array/effect/spear_2/tick
