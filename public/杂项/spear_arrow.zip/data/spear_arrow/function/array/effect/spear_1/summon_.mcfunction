scoreboard players set @s spear_effect_timer -5
tag @s remove spear_effect_temp

$data modify entity @s transformation.translation set value [0f,$(y)f,0f]

$data modify entity @s Rotation[0] set value $(rotation_x)f
$data modify entity @s Rotation[1] set value $(rotation_y)f

$data modify entity @s transformation.scale set value [$(scale)f,$(scale)f,$(scale)f]

data modify entity @s item set from storage spear item