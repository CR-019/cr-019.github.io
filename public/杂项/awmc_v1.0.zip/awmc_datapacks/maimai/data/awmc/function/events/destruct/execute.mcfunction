tag @s add awmc_remove
execute as @e[tag=awmc_maimai] if score @s dc_uid = @n[tag=awmc_remove] dc_uid run kill @s