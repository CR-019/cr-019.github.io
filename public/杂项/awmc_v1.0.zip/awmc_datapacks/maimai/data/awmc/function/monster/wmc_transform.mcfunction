data merge entity @s {Tags:["wmc","wmc_detected"],equipment:{head:{id:"firework_star",components:{item_model:"awmc:dxbear",equippable:{slot:"head"}}}},drop_chances:{head:0},DeathLootTable:"awmc:loot/wmc"}

loot replace entity @s weapon.mainhand loot awmc:glove
loot replace entity @s weapon.offhand loot awmc:glove

team join wmc @s