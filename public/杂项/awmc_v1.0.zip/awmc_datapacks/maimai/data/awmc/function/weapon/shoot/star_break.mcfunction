summon item_display ^ ^ ^3 {billboard:"vertical",item:{id:"firework_star",components:{item_model:"awmc:notes",custom_model_data:{strings:["star","break"],flags:[false]}}},Tags:["awmc_note","star","break","note_temp"],brightness:{block:15,sky:15},item_display:"fixed"}

execute store result score #temp awmc_timer run random value 1..2
execute if score #temp awmc_timer matches 1 run data modify entity @n[tag=note_temp] item.components."minecraft:custom_model_data".flags set value [true]

scoreboard players set @n[tag=note_temp] awmc_timer 60

rotate @n[tag=note_temp] ~ ~
tag @n[tag=note_temp] remove note_temp