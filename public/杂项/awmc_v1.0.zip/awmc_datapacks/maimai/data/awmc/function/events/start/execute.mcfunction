#打一局舞萌
execute unless score @s awmc_coin matches 6.. run return run playsound entity.villager.no block @a
playsound awmc:start_voice block @a ~ ~ ~
playsound awmc:slide block @a ~ ~ ~
effect give @a[tag=dc_click_temp] unluck 90
item modify entity @a[tag=dc_click_temp] weapon.mainhand awmc:glove/charge
item modify entity @a[tag=dc_click_temp] weapon.offhand awmc:glove/charge

scoreboard players remove @s awmc_coin 6
