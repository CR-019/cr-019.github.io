#生成slide
summon item_display ~ ~-0.5 ~ {item:{id:"firework_star",components:{item_model:"awmc:slides",custom_model_data:{strings:["normal"]}}},Tags:["slide","slide_temp"],brightness:{block:15,sky:15},item_display:"fixed"}

scoreboard players set @n[tag=slide_temp] awmc_timer 20
execute if entity @s[tag=break] run data modify entity @n[tag=slide_temp] item.components."minecraft:custom_model_data".strings set value ["break"]
execute if entity @s[tag=ex] run data modify entity @n[tag=slide_temp] item.components."minecraft:custom_model_data".strings set value ["ex"]

rotate @n[tag=slide_temp] ~ ~

tag @n[tag=slide_temp] remove slide_temp