scoreboard players remove @s awmc_timer 1
execute if score @s awmc_timer matches ..0 run kill @s