# 【maimaidx】舞萌
data modify storage dc:index input.maimaidx set value {\
    type:"hitbox",\
    extra_data:{\
        width:1f,\
        offset:0f\
    },\
    interactsize:{height:2.2f,width:2f},\
    loot_table:"awmc:maimaidx",\
    template:"kaleidoscope",\
    item:{\
        components:{"minecraft:item_model":"awmc:maimaidx"}\
    },\
    events:{\
        construct:[{event:"custom",args:{func:"awmc:events/construct"}}],\
        destruct:[{event:"custom",args:{func:"awmc:events/destruct"}}],\
        left_click:{fallback:{event:"destruct",args:{item:{},particle:"self",sound:"awmc:offline"}}},\
        right_click:{criteria:[{item:{components:{"minecraft:custom_data":{awmc_coin:1b}}},event:"custom",args:{func:"awmc:events/coin"}},{event:"custom",args:{func:"awmc:events/start"},predicate:"awmc:gloves",item:{}}]}\
    }\
}
data modify storage dc:index keylist append value "maimaidx"


# 【bigwater】大水
data modify storage dc:index input.bigwater set value {\
    interactsize:{height:0.5f,width:0.5f},\
    loot_table:"awmc:bigwater",\
    template:"kaleidoscope",\
    item:{\
        components:{"minecraft:item_model":"awmc:bigwater"}\
    },\
    events:{\
        left_click:{fallback:{event:"destruct",args:{item:{},particle:"self"}}},\
    }\
}
data modify storage dc:index keylist append value "bigwater"


# 【glovebox】手套箱
data modify storage dc:index input.glovebox set value {\
    interactsize:{height:0.5f,width:0.5f},\
    loot_table:"awmc:glovebox",\
    template:"kaleidoscope",\
    item:{\
        components:{"minecraft:item_model":"awmc:glove_box"}\
    },\
    events:{\
        left_click:{fallback:{event:"destruct",args:{item:{},particle:"self"}}},\
        right_click:{fallback:{event:"custom",args:{func:"awmc:events/give_glove"}}}\
    }\
}
data modify storage dc:index keylist append value "glovebox"