#star造成穿透伤害
execute if entity @e[type=!#awmc:non_mobs,distance=..1.5] run tag @s add awmc_slide_damage

execute if entity @s[tag=!break] as @e[type=!#awmc:non_mobs,distance=..1.5] run damage @s 8 magic
execute if entity @s[tag=break] as @e[type=!#awmc:non_mobs,distance=..1.5] run damage @s 16 magic

execute if entity @e[type=!#awmc:non_mobs,distance=..1.5] run playsound awmc:slide block @a ~ ~ ~ 20