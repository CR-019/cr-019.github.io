execute as @e[tag=awmc_note] at @s run function awmc:weapon/note_tick

execute as @e[tag=slide] at @s run function awmc:weapon/tick_slide
execute as @e[tag=awmc_judge] at @s run function awmc:weapon/tick_judge

execute as @a run function awmc:wmc_effect
#execute as @e[tag=awmc_maimai] at @s run function awmc:maimai_tick
#execute as @e[tag=wmc] at @s run function awmc:wmc_tick

team join wmc @e[type=villager]

execute as @e[type=#zombies,type=!camel_husk,type=!zoglin,type=!zombie_nautilus,tag=!wmc_detected] at @s run function awmc:monster/detect_zombie
execute as @e[type=#skeletons,tag=!wmc_detected] at @s run function awmc:monster/detect_skeleton