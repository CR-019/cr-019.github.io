summon zombie ~ ~ ~ {Tags:["wmc","wmc_temp","wmc_detected"],equipment:{head:{id:"firework_star",components:{item_model:"awmc:dxbear",equippable:{slot:"head"}}}},drop_chances:{head:0},DeathLootTable:"awmc:loot/wmc"}

loot replace entity @n[tag=wmc_temp] weapon.mainhand loot awmc:glove
loot replace entity @n[tag=wmc_temp] weapon.offhand loot awmc:glove

team join wmc @n[tag=wmc_temp]

tag @s remove wmc_temp