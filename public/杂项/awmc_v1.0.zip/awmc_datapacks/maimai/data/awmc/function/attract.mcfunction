damage @s 0.1 mob_attack by @n[tag=awmc_maimai]
tag @s add wmc_play