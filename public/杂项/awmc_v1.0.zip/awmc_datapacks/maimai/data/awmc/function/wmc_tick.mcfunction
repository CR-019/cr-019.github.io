execute on target if entity @s[tag=awmc_maimai] run return fail

tag @s remove wmc_play