tag @s add wmc_detected

execute if entity @e[tag=maimaidx,distance=..100] if predicate {condition:"random_chance",chance:0.3} run function awmc:monster/wmc_transform