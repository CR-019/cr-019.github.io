#星星结算
execute if entity @s[tag=awmc_slide_damage] run summon item_display ~ ~ ~ {billboard:"vertical",Tags:["awmc_judge","judge_temp"],item:{id:"firework_star",components:{item_model:"awmc:judges",custom_model_data:{strings:["cslide"]}}},brightness:{block:15,sky:15},item_display:"fixed"}
execute if entity @s[tag=!awmc_slide_damage] run summon item_display ~ ~ ~ {billboard:"vertical",Tags:["awmc_judge","judge_temp"],item:{id:"firework_star",components:{item_model:"awmc:judges",custom_model_data:{strings:["mslide"]}}},brightness:{block:15,sky:15},item_display:"fixed"}

scoreboard players set @n[tag=judge_temp] awmc_timer 20
tag @n[tag=judge_temp] remove judge_temp

kill @s