tag @s add wmc_detected

execute if entity @e[tag=maimaidx,distance=..100] if predicate {condition:"random_chance",chance:0.1} run function awmc:monster/odgirl_transform