scoreboard players remove @s awmc_timer 1
#向前飞行
execute if entity @s[tag=break] run tp ^ ^ ^1
execute if entity @s[tag=!break] run tp ^ ^ ^0.5

#slide持续判定
execute if entity @s[tag=star] run function awmc:weapon/summon_slide
execute if entity @s[tag=star] run function awmc:weapon/damage_star

#其他note触墙结算
execute at @s unless entity @s[tag=star] unless block ~ ~ ~ #awmc:pass run return run function awmc:weapon/judge

execute unless entity @s[tag=star] if entity @e[type=!#awmc:non_mobs,distance=..2.5] positioned ^ ^ ^0.5 unless entity @e[type=!#awmc:non_mobs,distance=..1.5] positioned ^ ^ ^0.5 unless entity @e[type=!#awmc:non_mobs,distance=..1.5] run return run function awmc:weapon/judge
execute unless entity @s[tag=star] if entity @e[type=!#awmc:non_mobs,distance=..1.5] positioned ^ ^ ^0.5 unless entity @e[type=!#awmc:non_mobs,distance=..1] positioned ^ ^ ^0.5 unless entity @e[type=!#awmc:non_mobs,distance=..1] run return run function awmc:weapon/judge

execute if score @s awmc_timer matches ..0 run function awmc:weapon/judge