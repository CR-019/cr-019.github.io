data modify entity @n[tag=dc_custom_display] transformation.translation[1] set value 0.25f
playsound awmc:start block @a
summon iron_golem ~ ~ ~ {Tags:["awmc_maimai"],Invulnerable:1b,attributes:[{id:"scale",base:0.1}],NoAI:1b,active_effects:[{id:"invisibility",duration:-1,show_particles:false}],DeathLootTable:"awmc:loot/empty",Silent:1b}
scoreboard players operation @n[tag=awmc_maimai] dc_uid = @s dc_uid

tag @s add maimaidx