#tap结算
execute if entity @e[type=!#awmc:non_mobs,distance=..3.5] run tag @s add perfect
execute unless entity @e[type=!#awmc:non_mobs,distance=..3.5] run tag @s add miss

#伤害
execute if entity @s[tag=perfect] as @e[type=!#awmc:non_mobs,distance=..3.5] run damage @s 8 magic


#judge
summon item_display ~ ~ ~ {billboard:"vertical",Tags:["awmc_judge","judge_temp"],item:{id:"firework_star",components:{item_model:"awmc:judges",custom_model_data:{strings:["perfect"]}}},brightness:{block:15,sky:15},item_display:"fixed"}

execute if entity @s[tag=miss] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["miss"]


scoreboard players set @n[tag=judge_temp] awmc_timer 20
tag @n[tag=judge_temp] remove judge_temp

execute if entity @s[tag=!miss] run playsound awmc:break block @a ~ ~ ~ 20
execute if entity @s[tag=!miss] run playsound awmc:judge_break block @a ~ ~ ~ 20
playsound entity.generic.explode block @a ~ ~ ~ 20

kill @s