summon item_display ^ ^ ^3 {billboard:"vertical",item:{id:"firework_star",components:{item_model:"awmc:notes",custom_model_data:{strings:["tap","break"]}}},Tags:["awmc_note","tap","break","note_temp"],brightness:{block:15,sky:15},item_display:"fixed"}

scoreboard players set @n[tag=note_temp] awmc_timer 60

rotate @n[tag=note_temp] ~ ~
tag @n[tag=note_temp] remove note_temp