scoreboard players set @s awmc_timer 10
execute store result score @s awmc_charge run data get entity @s SelectedItem.components."minecraft:custom_model_data".floats[0] 1
execute unless score @s awmc_charge matches 1.. run return fail
scoreboard players remove @s awmc_charge 1
item modify entity @s weapon.mainhand awmc:glove/damage

playsound awmc:touch block @a ~ ~ ~

execute store result score #temp1 awmc_timer run random value 1..10
execute store result score #temp2 awmc_timer run random value 1..10

execute if score #temp1 awmc_timer matches 1..4 if score #temp2 awmc_timer matches 1..4 anchored eyes run function awmc:weapon/shoot/tap
execute if score #temp1 awmc_timer matches 1..4 if score #temp2 awmc_timer matches 5..8 anchored eyes run function awmc:weapon/shoot/tap_break
execute if score #temp1 awmc_timer matches 1..4 if score #temp2 awmc_timer matches 9..10 anchored eyes run function awmc:weapon/shoot/tap_ex

execute if score #temp1 awmc_timer matches 5..8 if score #temp2 awmc_timer matches 1..4 anchored eyes run function awmc:weapon/shoot/star
execute if score #temp1 awmc_timer matches 5..8 if score #temp2 awmc_timer matches 5..8 anchored eyes run function awmc:weapon/shoot/star_break
execute if score #temp1 awmc_timer matches 5..8 if score #temp2 awmc_timer matches 9..10 anchored eyes run function awmc:weapon/shoot/star_ex

execute if score #temp1 awmc_timer matches 9..10 anchored eyes run function awmc:weapon/shoot/touchhold