execute as @e[tag=wmc,tag=!wmc_play,distance=..20] run function awmc:attract
