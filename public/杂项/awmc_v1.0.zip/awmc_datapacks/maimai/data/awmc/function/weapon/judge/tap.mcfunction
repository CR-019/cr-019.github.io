#tap结算
execute if entity @e[type=!#awmc:non_mobs,distance=..1] run tag @s add cperfect
execute if entity @e[type=!#awmc:non_mobs,distance=..1.5] run tag @s add perfect
execute unless entity @e[type=!#awmc:non_mobs,distance=..1.5] if entity @e[type=!#awmc:non_mobs,distance=..2.5] run tag @s add great
execute unless entity @e[type=!#awmc:non_mobs,distance=..2.5] if entity @e[type=!#awmc:non_mobs,distance=..3.5] run tag @s add good
execute unless entity @e[type=!#awmc:non_mobs,distance=..3.5] run tag @s add miss

execute if entity @s[tag=ex,tag=!miss] run tag @s add perfect
execute if entity @s[tag=ex] run tag @s remove great
execute if entity @s[tag=ex] run tag @s remove good

#伤害
execute if entity @s[tag=break,tag=cperfect] as @n[type=!#awmc:non_mobs,distance=..1] run damage @s 25 magic
execute if entity @s[tag=break,tag=!cperfect,tag=perfect] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 8 magic
execute if entity @s[tag=break,tag=!cperfect,tag=great] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 4 magic
execute if entity @s[tag=break,tag=!cperfect,tag=good] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 2 magic

execute if entity @s[tag=!break,tag=perfect] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 10 magic
execute if entity @s[tag=!break,tag=great] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 5 magic
execute if entity @s[tag=!break,tag=good] as @n[type=!#awmc:non_mobs,distance=..3.5] run damage @s 3 magic

#judge
summon item_display ~ ~ ~ {billboard:"vertical",Tags:["awmc_judge","judge_temp"],item:{id:"firework_star",components:{item_model:"awmc:judges",custom_model_data:{strings:["cperfect"]}}},brightness:{block:15,sky:15},item_display:"fixed"}

execute if entity @s[tag=perfect] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["perfect"]
execute if entity @s[tag=great] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["great"]
execute if entity @s[tag=good] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["good"]
execute if entity @s[tag=miss] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["miss"]

execute if entity @s[tag=break,tag=cperfect] run data modify entity @n[tag=judge_temp] item.components."minecraft:custom_model_data".strings set value ["cperfect"]

scoreboard players set @n[tag=judge_temp] awmc_timer 20
tag @n[tag=judge_temp] remove judge_temp

execute if entity @s[tag=break,tag=!miss] run playsound awmc:break block @a ~ ~ ~ 20
execute if entity @s[tag=break,tag=!miss] run playsound awmc:judge_break block @a ~ ~ ~ 20
execute if entity @s[tag=!break,tag=!miss] run playsound awmc:note block @a ~ ~ ~ 20

kill @s