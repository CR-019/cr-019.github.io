#结算
execute if entity @s[tag=star] run function awmc:weapon/judge/star
execute if entity @s[tag=tap] run function awmc:weapon/judge/tap
execute if entity @s[tag=touchhold] run function awmc:weapon/judge/touchhold