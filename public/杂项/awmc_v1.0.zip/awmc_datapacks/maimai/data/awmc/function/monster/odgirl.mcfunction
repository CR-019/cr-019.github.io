summon skeleton ~ ~ ~ {Tags:["wmc","wmc_temp","wmc_detected"],equipment:{head:{id:"firework_star",components:{item_model:"awmc:odgirl",equippable:{slot:"head"}}},"chest":{id:"firework_star",components:{item_model:"awmc:odgirl",equippable:{slot:"chest",asset_id:"awmc:jk"}}},legs:{id:"firework_star",components:{item_model:"awmc:odgirl",equippable:{slot:"legs",asset_id:"awmc:jk"}}}},drop_chances:{head:0,chest:0,feet:0,legs:0},DeathLootTable:"awmc:loot/wmc"}

loot replace entity @n[tag=wmc_temp] weapon.mainhand loot awmc:knife
loot replace entity @n[tag=wmc_temp] weapon.offhand loot awmc:glove

team join wmc @n[tag=wmc_temp]

tag @s remove wmc_temp