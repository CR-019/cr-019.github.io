scoreboard objectives add awmc_timer dummy
scoreboard objectives add awmc_charge dummy

scoreboard objectives add awmc_coin dummy

team add wmc