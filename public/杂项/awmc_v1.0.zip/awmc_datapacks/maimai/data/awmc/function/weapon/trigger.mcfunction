advancement revoke @s only awmc:use_glove

execute unless score @s awmc_timer matches 1.. run function awmc:weapon/shoot

scoreboard players remove @s awmc_timer 1