#投币
scoreboard players add @s awmc_coin 1
playsound awmc:slide block @a ~ ~ ~
title @a[tag=dc_click_temp] actionbar [{"text":"投币:"},{score:{name:"@s",objective:"awmc_coin"}},{text:"/6"}]

item modify entity @a[tag=dc_click_temp,gamemode=!creative] weapon.mainhand {function:"set_count",count:-1,add:true}