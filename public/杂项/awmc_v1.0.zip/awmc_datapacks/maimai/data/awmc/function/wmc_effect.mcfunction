execute if predicate awmc:effect run attribute @s attack_damage modifier add awmc 0.2 add_multiplied_base
execute if predicate awmc:effect run attribute @s attack_speed modifier add awmc -0.2 add_multiplied_base
execute if predicate awmc:effect run attribute @s movement_speed modifier add awmc -0.2 add_multiplied_base

execute unless predicate awmc:effect run attribute @s attack_damage modifier remove awmc
execute unless predicate awmc:effect run attribute @s attack_speed modifier remove awmc
execute unless predicate awmc:effect run attribute @s movement_speed modifier remove awmc