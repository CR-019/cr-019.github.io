$function $(func)/check
