data modify entity @s Rotation[0] set value 0f
