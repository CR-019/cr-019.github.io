tag @s add neddle_player

execute anchored eyes rotated ~ 0 positioned ^ ^-0.5 ^ run function neddle:ray

tag @s remove neddle_player