execute unless entity @s[distance=..8] run return run function neddle:settle

execute unless block ^ ^ ^1 #gun:piercable run return run function neddle:settle

execute positioned ~ ~-1 ~ if entity @e[distance=..2,tag=!neddle_player] run return run function neddle:settle_

particle end_rod ~ ~ ~ ~ ~ ~ 0 0

execute positioned ^ ^ ^0.5 run function neddle:ray