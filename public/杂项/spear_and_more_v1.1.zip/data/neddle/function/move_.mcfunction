execute at @n[tag=neddle] positioned ~ ~-1 ~ run tp ~ ~ ~
attribute @s gravity modifier remove 1
execute at @s run playsound entity.fishing_bobber.throw player @a ~ ~ ~
execute at @s run playsound entity.wind_charge.throw player @a ~ ~ ~

execute at @s if entity @e[tag=neddle_target,distance=..4] run tag @s add neddle_jump
execute at @s[tag=neddle_jump] run playsound entity.wind_charge.wind_burst player @a ~ ~ ~
execute at @s as @e[tag=neddle_target,distance=..4] run damage @s 4 player_attack by @a[limit=1,tag=neddle_jump,sort=nearest]
tag @e[tag=neddle_target,distance=..10] remove neddle_target

tag @s remove neddle_player_timer

execute at @s as @n[tag=neddle] run kill @s



schedule function neddle:move__ 1t