$execute at @s rotated as @s anchored eyes run summon item_display ^ ^ ^ {item:{id:"iron_spear"},item_display:"thirdperson_lefthand",Rotation:$(Rotation),teleport_duration:5,transformation:[-1.0000f,-0.0000f,0.0000f,0.0000f,0.0000f,-0.0000f,1.0000f,0.0000f,-0.0000f,1.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f],Tags:["neddle"]}

execute as @n[tag=neddle] run tp @s ~ ~ ~ ~ ~

tp @s @s
attribute @s gravity modifier add 1 -1 add_multiplied_total
tag @s add neddle_player_timer

playsound item.trident.throw player @a ~ ~ ~

schedule function neddle:move 10t

