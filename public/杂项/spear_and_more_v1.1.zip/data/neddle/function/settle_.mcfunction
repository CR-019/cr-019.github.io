tag @e[distance=..2,tag=!neddle_player] add neddle_target

function neddle:settle