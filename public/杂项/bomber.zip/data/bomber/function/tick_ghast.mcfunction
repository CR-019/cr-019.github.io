scoreboard players set @s bomb_count 0


tag @s add ghast_temp
execute on leasher if entity @s[type=sulfur_cube,predicate=bomber:contain_tnt] run function bomber:rematch
tag @s remove ghast_temp

