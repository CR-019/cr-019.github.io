data remove entity @s leash
data modify entity @s fuse set value 120