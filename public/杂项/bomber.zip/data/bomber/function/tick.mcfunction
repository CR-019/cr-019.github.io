execute as @e[type=happy_ghast,tag=!ghast_init] at @s run function bomber:ghast_init

execute as @e[type=happy_ghast,tag=ghast_init] at @s run function bomber:tick_ghast

execute as @e[type=sulfur_cube,predicate=bomber:contain_tnt] at @s run function bomber:tick_cube

execute as @e[type=interaction,tag=ghast_control] at @s run function bomber:tick_control



