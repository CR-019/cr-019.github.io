execute unless score @s bomb_count matches 1.. run return run playsound entity.villager.no neutral @a

playsound entity.tnt.primed neutral @a

execute on vehicle run tag @s add ghast_temp

execute as @e[type=sulfur_cube,predicate=bomber:contain_tnt] run function bomber:trigger_get_bomb

execute as @n[tag=bomb_temp] at @s run function bomber:trigger_bomb

execute on vehicle run tag @s remove ghast_temp
tag @e remove bomb_temp