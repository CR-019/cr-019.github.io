#重新匹配栓绳关系
data remove entity @n[tag=ghast_temp] leash
data modify entity @s leash.UUID set from entity @n[tag=ghast_temp] UUID