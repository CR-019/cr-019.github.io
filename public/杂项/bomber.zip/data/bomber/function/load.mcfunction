scoreboard objectives add bomb_count dummy


