tag @s add control_temp
execute on target if entity @s[tag=player_click] as @n[tag=control_temp] run function bomber:trigger_judge

tag @s remove control_temp