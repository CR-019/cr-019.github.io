#初始化善魂

tag @s add ghast_init

summon interaction ~ ~ ~ {Tags:[ghast_control,ghast_control_temp]}

ride @n[tag=ghast_control_temp] mount @s

tag @n[tag=ghast_control_temp] remove ghast_control_temp