execute on leasher if entity @s[tag=!ghast_temp] run return 0

tag @s add bomb_temp