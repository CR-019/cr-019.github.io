advancement revoke @s only bomber:releash

tag @s add player_click

execute as @e[distance=..20,type=interaction] run function bomber:trigger_get

tag @s remove player_click