
scoreboard players operation @s bomb_count = @n[type=happy_ghast] bomb_count

data modify entity @s CustomName set value {text:"",extra:[{object:"atlas",sprite:"block/tnt_side",atlas:"blocks"}]}

execute store result storage bomb temp int 1 run scoreboard players get @s bomb_count
data modify entity @s CustomName.text set string storage bomb temp 0

execute on vehicle run return 0

kill @s