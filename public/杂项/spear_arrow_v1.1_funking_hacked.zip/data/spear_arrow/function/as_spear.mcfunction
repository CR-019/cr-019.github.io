#rotation
execute on vehicle at @s positioned 0. 0. 0. positioned ^ ^ ^2 positioned ~ ~ 0. positioned ^ ^ ^-1 facing 0. 0. 0. on passengers run rotate @s ~ ~

#function
execute on vehicle run return 0

execute unless entity @s[tag=spear_arrow_display_inGround] run return run function spear_arrow:summon_arrow_temp

item modify entity @s contents {"function":"set_damage",damage:-0.01,add:true}

#array
execute if items entity @s contents *[enchantments~[{enchantments:["spear_arrow:spear_array"]}]] run function spear_arrow:array/main

tag @s remove spear_arrow_display
tag @s add spear_arrow_display_inGround
scoreboard players set @s spear_arrow_timer 1200