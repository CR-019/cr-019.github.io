scoreboard objectives add spear_arrow_timer dummy
scoreboard objectives add spear_arrow_damage dummy
scoreboard objectives add spear_arrow_array dummy
scoreboard objectives add spear_effect_timer dummy
scoreboard objectives add spear_cal_temp dummy

scoreboard objectives add spear_arrey_funking_hold dummy