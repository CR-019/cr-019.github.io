execute as @e[type=arrow,tag=!spear_arrow] if items entity @s contents #spears at @s run function spear_arrow:spear_summon
execute as @e[type=arrow,tag=spear_arrow] at @s run function spear_arrow:as_arrow

execute as @e[type=item_display,tag=spear_arrow_display] at @s run function spear_arrow:as_spear
execute as @e[type=item_display,tag=spear_arrow_display_inGround] at @s run function spear_arrow:inground

execute as @a at @s run function spear_arrow:array/charge/tick

execute as @e[tag=spear_effect] at @s run function spear_arrow:array/effect/tick