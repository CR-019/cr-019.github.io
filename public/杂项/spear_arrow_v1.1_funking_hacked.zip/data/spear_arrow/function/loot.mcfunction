summon item ~ ~ ~ {Item:{id:stone,count:1},Tags:["spear_arrow_item"]}
data modify entity @n[tag=spear_arrow_item] Item set from entity @s item

tag @n[tag=spear_arrow_item] remove spear_arrow_item
kill @s
