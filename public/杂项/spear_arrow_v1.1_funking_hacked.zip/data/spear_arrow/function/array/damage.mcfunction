tag @s add spear_arrow_array_spear
$execute as @e[distance=..5,type=!item,type=!item_frame,tag=!spear_arrow_array_owner] run damage @s $(damage) spear_arrow:mob_attack by @n[tag=spear_arrow_array_spear] from @n[tag=spear_arrow_array_owner] 
tag @s remove spear_arrow_array_spear