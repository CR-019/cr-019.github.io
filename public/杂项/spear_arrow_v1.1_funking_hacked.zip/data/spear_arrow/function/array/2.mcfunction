summon marker ~ ~ ~ {Tags:[spear_arrow_array_temp]}

data modify storage minecraft:spear item set from entity @s item

execute as @e[tag=spear_arrow_array_temp] at @s run function spear_arrow:array/effect/spear_2/summon

execute as @e[tag=spear_arrow_array_temp] run kill @s