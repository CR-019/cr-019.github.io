scoreboard players set @s spear_effect_timer -5
tag @s remove spear_effect_temp



data modify entity @s item set from storage spear item

