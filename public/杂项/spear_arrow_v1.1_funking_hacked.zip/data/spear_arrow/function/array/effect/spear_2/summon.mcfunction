summon item_display ~ ~ ~ {Tags:["spear_effect","spear_effect_spear_2","spear_effect_temp"],item_display:"thirdperson_righthand",transformation:[0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f],interpolation_duration:5}
data modify storage minecraft:spear effect set value {scale:1f,rotation_x:0f,rotation_y:0f,y:0f}
execute store result storage minecraft:spear effect.scale float 0.01 run random value 280..320
execute store result storage minecraft:spear effect.rotation_x float 0.01 run random value 0..36000
execute store result storage minecraft:spear effect.rotation_y float 0.01 run random value -500..500
execute store result storage minecraft:spear effect.y float 0.5 run data get storage minecraft:spear effect.scale

data modify entity @n[tag=spear_effect_temp] data.effect set from storage minecraft:spear effect

execute as @e[tag=spear_effect_temp,limit=1,sort=nearest] run function spear_arrow:array/effect/spear_2/summon_ with entity @s data.effect

