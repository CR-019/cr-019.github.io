$particle item{item:"$(id)"} ~ ~1 ~ 0.3 0.3 0.3 0 10
playsound entity.item.break neutral @a ~ ~ ~ 0.05

kill @s