$particle item{item:"$(id)"} ~ ~1 ~ 0.5 0.5 0.5 0 20
playsound entity.item.break neutral @a ~ ~ ~ 0.2

kill @s