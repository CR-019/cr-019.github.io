$data modify entity @s transformation.translation set value [0f,$(y)f,0f]

data modify entity @s transformation.translation set value [0f,-2f,0f]

$data modify entity @s Rotation[0] set value $(rotation_x)f
$data modify entity @s Rotation[1] set value $(rotation_y)f

$data modify entity @s transformation.scale set value [5f,$(scale)f,$(scale)f]

data modify entity @s interpolation_duration set value 1
data modify entity @s start_interpolation set value 0