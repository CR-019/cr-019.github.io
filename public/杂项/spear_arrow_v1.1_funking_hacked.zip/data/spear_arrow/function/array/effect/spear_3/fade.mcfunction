$particle item{item:"$(id)"} ~ ~ ~ 0.5 0.5 0.5 0 10
playsound entity.item.break neutral @a ~ ~ ~ 0.2

kill @s