#识别类型
execute as @s[tag=spear_effect_spear_1] run function spear_arrow:array/effect/spear_1/tick

execute as @s[tag=spear_effect_spear_2] run function spear_arrow:array/effect/spear_2/tick

execute as @s[tag=spear_effect_spear_3] run function spear_arrow:array/effect/spear_3/tick

execute as @s[tag=spear_effect_spear_4] run function spear_arrow:array/effect/spear_4/tick

execute as @s[tag=spear_effect_spear_5] run function spear_arrow:array/effect/spear_5/tick