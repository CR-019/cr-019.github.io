summon marker ~ ~ ~ {Tags:[spear_arrow_array_temp]}

data modify storage minecraft:spear item set from entity @s SelectedItem

execute store result score #temp spear_cal_temp run data get entity @s Rotation[0] 100

execute as @e[tag=spear_arrow_array_temp] at @s run function spear_arrow:array/effect/spear_5/summon

execute as @e[tag=spear_arrow_array_temp] run kill @s