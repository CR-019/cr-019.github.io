tag @s add spear_arrow_array_player_air


scoreboard players set @s spear_arrey_funking_hold 1