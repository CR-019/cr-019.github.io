execute as @s[tag=spear_arrow_array_player_air] if predicate {"condition":"entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run function spear_arrow:array/charge/main_air

#execute as @s[tag=spear_arrow_array_player_ground,tag=!spear_arrow_array_player_ground_temp] if predicate {"condition":"entity_properties",entity:"this",predicate:{movement:{speed:{max:0.5}},flags:{is_on_ground:true}}} run function spear_arrow:array/charge/main_ground

tag @a remove spear_arrow_array_player_ground_temp

