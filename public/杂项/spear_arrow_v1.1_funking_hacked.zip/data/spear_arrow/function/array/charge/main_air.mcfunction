#lvl
execute store result score @s spear_arrow_array run data get entity @s SelectedItem.components."minecraft:enchantments"."spear_arrow:spear_array"

#owner
tag @s add spear_arrow_array_owner


#height
execute store result score #temp spear_arrow_array run data get entity @s Pos[1]
scoreboard players add #temp spear_arrow_array 3
execute store result storage minecraft:spear height int 1 run scoreboard players get #temp spear_arrow_array

#damage
execute if items entity @s weapon.mainhand wooden_spear run scoreboard players set @s spear_arrow_damage 1
execute if items entity @s weapon.mainhand golden_spear run scoreboard players set @s spear_arrow_damage 1
execute if items entity @s weapon.mainhand stone_spear run scoreboard players set @s spear_arrow_damage 2
execute if items entity @s weapon.mainhand copper_spear run scoreboard players set @s spear_arrow_damage 2
execute if items entity @s weapon.mainhand iron_spear run scoreboard players set @s spear_arrow_damage 3
execute if items entity @s weapon.mainhand diamond_spear run scoreboard players set @s spear_arrow_damage 4
execute if items entity @s weapon.mainhand netherite_spear run scoreboard players set @s spear_arrow_damage 5

scoreboard players operation @s spear_arrow_damage *= @s spear_arrow_array
execute store result storage minecraft:spear charge.damage float 1 run scoreboard players get @s spear_arrow_damage

function spear_arrow:array/damage with storage minecraft:spear charge

#particle
summon item_display ~ ~ ~ {Tags:["spear_arrow_array_temp"]}
loot replace entity @e[limit=1,tag=spear_arrow_array_temp,sort=nearest] contents mine ~ ~-1 ~ diamond_pickaxe[enchantments={silk_touch:1}]
loot replace entity @e[limit=1,tag=spear_arrow_array_temp,sort=nearest] contents mine ~ ~ ~ diamond_pickaxe[enchantments={silk_touch:1}]
data modify storage spear block set value "dirt"
data modify storage spear block set from entity @e[limit=1,tag=spear_arrow_array_temp,sort=nearest] item.id
kill @e[type=item_display,tag=spear_arrow_array_temp]

function spear_arrow:array/particle with storage spear

#effect
execute if score @s spear_arrow_array matches 1.. run function spear_arrow:array/charge/air/1 with storage minecraft:spear
execute if score @s spear_arrow_array matches 2.. run function spear_arrow:array/charge/air/1 with storage minecraft:spear
execute if score @s spear_arrow_array matches 2 run function spear_arrow:array/charge/air/2 with storage minecraft:spear
execute if score @s spear_arrow_array matches 3.. run function spear_arrow:array/charge/air/3 with storage minecraft:spear

#sound
playsound item.spear.attack player @a ~ ~ ~
playsound item.spear.hit player @a ~ ~ ~
playsound item.mace.smash_ground player @a ~ ~ ~

tag @s remove spear_arrow_array_owner
tag @s remove spear_arrow_array_player_air