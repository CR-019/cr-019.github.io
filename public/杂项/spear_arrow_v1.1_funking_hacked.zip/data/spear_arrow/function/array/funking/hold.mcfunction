advancement revoke @s only spear_arrow:funking_hold

execute as @s if predicate {condition:random_chance,chance:0.0825714} at @s run function spear_arrow:array/charge/ground