execute store result score @s spear_arrow_damage run data get entity @s damage
execute if items entity @s contents wooden_spear run scoreboard players add @s spear_arrow_damage 1
execute if items entity @s contents golden_spear run scoreboard players add @s spear_arrow_damage 1
execute if items entity @s contents stone_spear run scoreboard players add @s spear_arrow_damage 2
execute if items entity @s contents copper_spear run scoreboard players add @s spear_arrow_damage 2
execute if items entity @s contents iron_spear run scoreboard players add @s spear_arrow_damage 3
execute if items entity @s contents diamond_spear run scoreboard players add @s spear_arrow_damage 4
execute if items entity @s contents netherite_spear run scoreboard players add @s spear_arrow_damage 5

execute store result entity @s damage double 1 run scoreboard players get @s spear_arrow_damage