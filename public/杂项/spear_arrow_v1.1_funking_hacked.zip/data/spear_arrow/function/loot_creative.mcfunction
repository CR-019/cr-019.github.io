playsound entity.item.pickup player @a ~ ~ ~
kill @s
