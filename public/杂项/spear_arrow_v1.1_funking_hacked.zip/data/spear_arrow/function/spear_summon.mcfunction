summon item_display ~ ~ ~ {Tags:["spear_arrow_display","spear_arrow_display_temp"],item_display:"thirdperson_righthand",transformation:[-1.0000f,-0.0000f,0.0000f,0.0000f,0.0000f,-0.0000f,1.0000f,0.0000f,-0.0000f,1.0000f,0.0000f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f]}
data modify entity @n[tag=spear_arrow_display_temp] transformation.translation[1] set value -0.35f
ride @n[tag=spear_arrow_display_temp] mount @s
data modify entity @n[tag=spear_arrow_display_temp] item set from entity @s item
data modify entity @n[tag=spear_arrow_display_temp] data.Owner set from entity @s Owner
data modify entity @n[tag=spear_arrow_display_temp] data.pickup set from entity @s pickup
tag @n[tag=spear_arrow_display_temp] remove spear_arrow_display_temp

data modify entity @s SoundEvent set value "item.spear.hit"

function spear_arrow:damage

tag @s add spear_arrow