execute if data entity @s {inGround:1b} on passengers run tag @s add spear_arrow_display_inGround
execute if data entity @s {inGround:1b} run kill @s