#计时器
execute unless score @s spear_arrow_timer matches 1.. run kill @s
scoreboard players remove @s spear_arrow_timer 1

execute if data entity @s {data:{pickup:1b}} if entity @a[distance=..2,gamemode=!spectator,gamemode=!creative] run function spear_arrow:loot
execute if data entity @s {data:{pickup:1b}} if entity @a[distance=..2,gamemode=creative] run function spear_arrow:loot_creative
execute if data entity @s {data:{pickup:2b}} if entity @a[distance=..2,gamemode=creative] run function spear_arrow:loot_creative
