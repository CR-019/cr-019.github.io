summon arrow ~ ~ ~ {Tags:["spear_arrow"],SoundEvent:"item.spear.hit"}
ride @s mount @n[tag=spear_arrow]