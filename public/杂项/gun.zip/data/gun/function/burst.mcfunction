particle gust_emitter_small ~ ~ ~ 0 0 0 0 1
playsound entity.wind_charge.wind_burst player @a ~ ~ ~ 20


execute as @e[distance=..2,tag=!gun_player] run damage @s 15 arrow by @n[tag=gun_player]
tag @s remove gun_player
