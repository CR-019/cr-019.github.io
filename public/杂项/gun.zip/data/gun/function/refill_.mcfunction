execute as @a[tag=gun_refill] if items entity @s weapon.mainhand *[custom_data~{gun_refill:1b}] run return run loot replace entity @s weapon.mainhand loot gun:gun

execute as @a[tag=gun_refill] if items entity @s weapon.offhand *[custom_data~{gun_refill:1b}] run return run loot replace entity @s weapon.offhand loot gun:gun

tag @a remove gun_refill