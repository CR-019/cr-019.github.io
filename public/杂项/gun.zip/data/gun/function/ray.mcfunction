execute unless entity @s[distance=..40] run return fail

particle end_rod ~ ~ ~ 0 0 0 0 0

tag @s add gun_player
execute unless block ~ ~ ~ #gun:piercable run return run function gun:burst

execute if entity @e[distance=..2,tag=!gun_player] run return run function gun:burst

tag @s remove gun_player

execute positioned ^ ^ ^1 run function gun:ray