tag @s add gun_refill
advancement revoke @s only gun:gun
schedule function gun:refill_ 2t