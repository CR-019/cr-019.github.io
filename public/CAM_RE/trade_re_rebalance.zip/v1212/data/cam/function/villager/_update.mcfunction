scoreboard players set $trade CAM_modules 19
