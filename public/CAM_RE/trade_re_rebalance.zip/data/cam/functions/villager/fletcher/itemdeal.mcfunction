tag @s add CAM_temp1
data modify entity @s PickupDelay set value 1000
function cam:villager/fletcher/exhaustion
loot spawn ~ ~ ~ loot cam:villager/emerald_bow
execute as @e[distance=..1,type=minecraft:item,tag=!CAM_temp1,limit=1] run tag @s add CAM_temp2
execute as @e[distance=..1,type=minecraft:item,tag=!CAM_temp1,limit=1] run data modify entity @s PickupDelay set value 1000