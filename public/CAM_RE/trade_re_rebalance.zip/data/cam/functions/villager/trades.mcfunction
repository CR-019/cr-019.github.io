function cam:villager/librarian/tick
function cam:villager/weaponsmith/weaponsmith/tick
function cam:villager/toolsmith/tick
function cam:villager/armorer/tick
function cam:villager/fletcher/tick