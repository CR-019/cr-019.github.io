scoreboard objectives add CAM_villager_level dummy
scoreboard objectives add CAM_villager_levelt dummy
scoreboard objectives add CAM_villager_leveldelta dummy

function cam:villager/librarian/load
function cam:villager/weaponsmith/weaponsmith/load
function cam:villager/toolsmith/load
function cam:villager/armorer/load
function cam:villager/fletcher/load