#交易
function cam:villager/main

execute as @e[type=villager] if score @s CAM_villager_leveldelta matches 1.. at @s run function cam:villager/trades
