execute store result score @s CAM_villager_level run data get entity @s VillagerData.level
scoreboard players operation @s CAM_villager_leveldelta = @s CAM_villager_level
scoreboard players operation @s CAM_villager_leveldelta -= @s CAM_villager_levelt
execute if score @s CAM_villager_level matches 1 if entity @s[nbt={VillagerData:{profession:"minecraft:none"}}] run scoreboard players set @s CAM_villager_level 0

scoreboard players operation @s CAM_villager_levelt = @s CAM_villager_level