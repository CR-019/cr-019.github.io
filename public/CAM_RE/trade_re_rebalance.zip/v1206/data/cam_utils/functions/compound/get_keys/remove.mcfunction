#cam_utils:compound/get_keys/remove

$data remove storage math:io compound.$(stemp)