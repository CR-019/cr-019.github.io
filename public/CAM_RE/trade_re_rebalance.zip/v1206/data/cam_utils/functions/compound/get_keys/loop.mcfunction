#cam_utils:compound/get_keys/loop

data modify entity @s text set value '{"nbt":"compound","storage":"math:io"}'
data modify storage math:io temp set from entity @s text
data modify storage test temp set from entity @s text
scoreboard players set sres int 1
scoreboard players set res int 0
scoreboard players set exc int 1 
scoreboard players set quot int -1
function cam_utils:compound/get_keys/sloop
execute store result storage math:io temp int 1 run scoreboard players remove res int 1
function cam_utils:compound/get_keys/first with storage math:io {}
execute unless score quot int matches 1.. run data modify storage math:io stemp set string storage math:io stemp 2
execute if score quot int matches 1.. run data modify storage math:io stemp set string storage math:io stemp 4 -2
data modify storage math:io result append from storage math:io stemp
function cam_utils:compound/get_keys/remove with storage math:io {}

scoreboard players remove ssloop int 1
execute if score ssloop int matches 1.. run function cam_utils:compound/get_keys/loop