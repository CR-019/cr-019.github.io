#cam_utils:compound/get_keys/sloop

data modify storage math:io stemp set string storage math:io temp 0 1
data modify storage math:io temp set string storage math:io temp 1

execute if data storage math:io {stemp:"\""} if score exc int matches 0 run scoreboard players set exct int 1
execute if data storage math:io {stemp:"\""} if score exc int matches 1 run scoreboard players set exct int 0
execute if data storage math:io {stemp:"\""} run scoreboard players add quot int 1

execute if score exct int matches 0 run scoreboard players set exc int 0
execute if score exct int matches 1 run scoreboard players set exc int 1

execute if score exc int matches 0 if data storage math:io {stemp:":"} run scoreboard players set sres int 0

scoreboard players add res int 1
execute if score sres int matches 1 run function cam_utils:compound/get_keys/sloop