tag @s add CAM_temp1
data modify entity @s PickupDelay set value 1000

data modify storage math:io compound set from entity @s Item.components."minecraft:stored_enchantments".levels
function cam_utils:compound/_get_keys
data modify storage cam:villager librarian.enchant.key set from storage math:io result[0]
function cam:villager/librarian/itemdeal_ with storage cam:villager librarian.enchant
data modify storage test 1 set from storage cam:villager librarian.enchant

loot spawn ~ ~ ~ loot cam:villager/emerald_lib
execute as @e[distance=..1,type=minecraft:item,tag=!CAM_temp1,limit=1] run tag @s add CAM_temp2
execute as @e[distance=..1,type=minecraft:item,tag=!CAM_temp1,limit=1] run data modify entity @s PickupDelay set value 1000
execute if data entity @s Item.components.minecraft:stored_enchantments.levels."minecraft:mending" as @e[distance=..1,type=item,tag=CAM_temp2] run function cam:villager/librarian/multi
execute if data entity @s Item.components.minecraft:stored_enchantments.levels."minecraft:frost_walker" as @e[distance=..1,type=item,tag=CAM_temp2] run function cam:villager/librarian/multi