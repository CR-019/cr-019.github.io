loot spawn ~ ~ ~ loot cam:villager/book
execute as @e[limit=1,type=item,sort=nearest] run tag @s add temp
execute as @e[tag=temp] run data modify storage math:io compound set from entity @s Item.components."minecraft:stored_enchantments".levels
function cam_utils:compound/_get_keys
kill @e[tag=temp]