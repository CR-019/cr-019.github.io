data modify storage cam:villager librarian.enchant.enchant set value {}
$data modify storage cam:villager librarian.enchant.enchant.$(key) set from entity @s Item.components."minecraft:stored_enchantments".levels.$(key)
data modify entity @s Item.components."minecraft:stored_enchantments".levels set from storage cam:villager librarian.enchant.enchant

$execute store result score @s CAM_booklvl run data get entity @s Item.components."minecraft:stored_enchantments".levels.$(key)

