execute if block ~ ~ ~ #cam:lanterns run playsound minecraft:block.lantern.break block @a ~ ~ ~
execute if block ~ ~ ~ #cam:troches run playsound minecraft:block.wood.break block @a ~ ~ ~
execute if block ~ ~ ~ minecraft:lantern run particle minecraft:block{block_state:"lantern"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ minecraft:soul_lantern run particle minecraft:block{block_state:"soul_lantern"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ minecraft:torch run particle minecraft:block{block_state:"torch"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ minecraft:soul_torch run particle minecraft:block{block_state:"soul_torch"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ minecraft:wall_torch run particle minecraft:block{block_state:"torch"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ minecraft:soul_wall_torch run particle minecraft:block{block_state:"soul_torch"} ~ ~ ~ 0.2 0.2 0.2 1 20 normal
execute if block ~ ~ ~ #cam:light_breakable[waterlogged=false] run setblock ~ ~ ~ minecraft:air
execute if block ~ ~ ~ #cam:light_breakable[waterlogged=true] run setblock ~ ~ ~ minecraft:water
execute if block ~ ~ ~ #cam:light_breakable run setblock ~ ~ ~ minecraft:air

#execute on origin run advancement grant @s only cam:countryside_and_magic/deluminator

kill @s[type=minecraft:arrow]
