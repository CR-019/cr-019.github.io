execute as @a[tag=temp] run item replace entity @s weapon.mainhand from entity @s enderchest.0
execute as @a[tag=temp] run tag @s remove temp