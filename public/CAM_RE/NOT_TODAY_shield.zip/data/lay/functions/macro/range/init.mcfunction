$scoreboard players set #min lay_range $(min)
$scoreboard players set #max lay_range $(max)
$scoreboard players set #step lay_range $(step)

#异常处理
scoreboard players set #error lay_range 0
execute if score #min lay_range > #max lay_range run function lay:macro/range/excp_range_0
execute if score #step lay_range matches ..0 run function lay:macro/range/excp_invalid_step
execute if score #error lay_range matches 1 run return 0

scoreboard players operation #current lay_range = #min lay_range
$function lay:macro/range/loop {func:"$(func)",path:"$(path)"}

