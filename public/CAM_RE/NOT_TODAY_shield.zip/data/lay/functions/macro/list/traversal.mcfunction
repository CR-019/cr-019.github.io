$data modify storage lay list.val.value set from $(list)[$(var)]
$function $(func) with storage lay list.val