scoreboard objectives remove CAM_modules
scoreboard objectives add CAM_modules dummy

function #cam:modules