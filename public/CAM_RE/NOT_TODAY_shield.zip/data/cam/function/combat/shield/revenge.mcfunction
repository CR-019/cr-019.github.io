function cam:combat/shield/defence
function cam:combat/shield/break
scoreboard players reset @s CAM_shieldblock