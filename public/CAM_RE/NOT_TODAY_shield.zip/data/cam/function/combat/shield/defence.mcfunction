#计算伤害
scoreboard players set @s CAM_shield_enchant_lvl 0
execute if predicate cam:shield/mainhand store result score @s CAM_shield_enchant_lvl run data get entity @s SelectedItem.components."minecraft:enchantments".levels."cam:thistle"
execute if predicate cam:shield/offhand store result score @s CAM_shield_enchant_lvl run data get entity @s Inventory[{Slot:-106b}].SelectedItem.components."minecraft:enchantments".levels."cam:thistle"

execute if score @s CAM_shield_enchant_lvl matches 1 run scoreboard players add @s CAM_shield_enchant_lvl 1
scoreboard players set @s CAM_shield_temp 25
scoreboard players operation @s CAM_shield_temp *= @s CAM_shield_enchant_lvl
scoreboard players add @s CAM_shield_temp 100
scoreboard players operation @s CAM_shield_temp *= @s CAM_shieldblock
execute store result storage cam:combat shield.damage float 0.001 run scoreboard players get @s CAM_shield_temp


execute if predicate cam:shield/resilience/both run function cam:combat/shield/resilience

function cam:combat/shield/defence_ with storage cam:combat shield

