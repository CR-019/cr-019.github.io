execute as @a if score @s CAM_shieldbreak matches 1.. run scoreboard players remove @s CAM_shieldbreak 1
#execute as @a if score @s CAM_shield_hold matches 1.. run scoreboard players remove @s CAM_shield_hold 1
execute as @a[tag=!CAM_shield_hold_] run scoreboard players set @s CAM_shield_hold 0
#破盾
execute as @a[tag=CAM_shield_hold_] at @s run function cam:combat/shield/when_hold

tag @a remove CAM_shield_hold_

