execute if predicate cam:shield/mainhand store result score @s CAM_shield_enchant_lvl run data get entity @s SelectedItem.components.minecraft:enchantments.levels."cam:agility"
execute if predicate cam:shield/offhand store result score @s CAM_shield_enchant_lvl run data get entity @s Inventory[{Slot:-106b}].components.minecraft:enchantments.levels."cam:agility"
scoreboard players operation @s CAM_shield_enchant_lvl *= #2 CAM_shield_temp
scoreboard players set @s CAM_shield_defence_t 10
scoreboard players operation @s CAM_shield_defence_t += @s CAM_shield_enchant_lvl