execute unless score @s CAM_shield_hold <= @s CAM_shield_defence_t run scoreboard players operation @s CAM_shieldblock /= #4 CAM_shield_temp
execute unless score @s CAM_shield_hold <= @s CAM_shield_defence_t run scoreboard players operation @s CAM_shieldbreak += @s CAM_shieldblock
advancement revoke @s only cam:combat/shield1
scoreboard players reset @s CAM_shieldblock