scoreboard objectives add CAM_shieldbreak dummy
scoreboard objectives add CAM_shield_hold dummy
scoreboard objectives add CAM_shield_strength dummy
scoreboard objectives add CAM_shield_temp dummy
scoreboard objectives add CAM_shield_defence_t dummy
scoreboard objectives add CAM_shield_effect dummy
scoreboard objectives add CAM_shieldblock custom:damage_blocked_by_shield

scoreboard objectives add CAM_shield_enchant_lvl dummy

#可调整参数
scoreboard players set #default CAM_shield_strength 240

#
scoreboard players set #10 CAM_shield_temp 10
scoreboard players set #2 CAM_shield_temp 2
scoreboard players set #4 CAM_shield_temp 4