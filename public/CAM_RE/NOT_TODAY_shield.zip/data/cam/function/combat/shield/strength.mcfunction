#计算玩家阈值
scoreboard players operation @s CAM_shield_strength = #default CAM_shield_strength
#盾的加成（加算）
execute if predicate cam:shield/mainhand store result score @s CAM_shield_temp run data get entity @s SelectedItem.components.minecraft:custom_data.CAM_ExtraStrength
execute if predicate cam:shield/offhand store result score @s CAM_shield_temp run data get entity @s Inventory[{Slot:-106b}].components.minecraft:custom_data.CAM_ExtraStrength
scoreboard players operation @s CAM_shield_strength += @s CAM_shield_temp
#附魔加成（乘算，一级加20%）
execute if predicate cam:shield/mainhand store result score @s CAM_shield_enchant_lvl run data get entity @s SelectedItem.components.minecraft:enchantments.levels."cam:tenacity"
execute if predicate cam:shield/offhand store result score @s CAM_shield_enchant_lvl run data get entity @s Inventory[{Slot:-106b}].components.minecraft:enchantments.levels."cam:tenacity"
scoreboard players operation @s CAM_shield_enchant_lvl *= #2 CAM_shield_temp
scoreboard players add @s CAM_shield_enchant_lvl 10
scoreboard players operation @s CAM_shield_strength *= @s CAM_shield_enchant_lvl
scoreboard players operation @s CAM_shield_strength /= #10 CAM_shield_temp


execute if score @s CAM_shieldbreak >= @s CAM_shield_strength at @s run function cam:combat/shield/break