execute if score @s CAM_shieldbreak matches 1.. run function cam:combat/shield/strength

function cam:combat/shield/defence_t