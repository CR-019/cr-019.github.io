tag @s add CAM_shieldbreaking
execute positioned ~ ~30 ~ run summon minecraft:armor_stand ^ ^ ^3 {HandItems:[{id:"minecraft:stone_axe",count:1b},{}],Invisible:true,ShowArms:true,Tags:["CAM_shieldbreaker"]}
execute as @e[tag=CAM_shieldbreaker] run damage @a[limit=1,sort=nearest,tag=CAM_shieldbreaking] 0.1 mob_attack by @s
kill @e[tag=CAM_shieldbreaker]
tag @s remove CAM_shieldbreaking
scoreboard players set @s CAM_shieldbreak 0
