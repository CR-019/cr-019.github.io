playsound minecraft:block.anvil.place player @a ~ ~ ~ 0.3 1.3
tag @s add CAM_reverse_dealt
$execute on attacker run damage @s $(damage) cam:reverse by @a[limit=1,sort=nearest,tag=CAM_reverse_dealt]
tag @s remove CAM_reverse_dealt
#advancement grant @s only cam:countryside_and_magic/shield
execute anchored eyes positioned ^ ^ ^1 run particle crit ~ ~ ~ .2 .2 .2 0 10
