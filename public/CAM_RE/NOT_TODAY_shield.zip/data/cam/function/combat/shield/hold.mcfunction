advancement revoke @s only cam:combat/defence
scoreboard players add @s CAM_shield_hold 1
tag @s add CAM_shield_hold_

