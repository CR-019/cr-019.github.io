advancement revoke @s only cam:combat/shield
execute if predicate cam:shield/revenge/both run function cam:combat/shield/revenge
execute if predicate cam:shield/revenge/both run return 0
execute unless score @s CAM_shield_hold <= @s CAM_shield_defence_t run function cam:combat/shield/add
execute if score @s CAM_shield_hold <= @s CAM_shield_defence_t run function cam:combat/shield/defence
scoreboard players reset @s CAM_shieldblock