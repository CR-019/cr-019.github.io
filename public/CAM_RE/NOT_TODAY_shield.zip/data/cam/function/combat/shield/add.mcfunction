scoreboard players add @s CAM_shieldblock 50
scoreboard players operation @s CAM_shieldbreak += @s CAM_shieldblock