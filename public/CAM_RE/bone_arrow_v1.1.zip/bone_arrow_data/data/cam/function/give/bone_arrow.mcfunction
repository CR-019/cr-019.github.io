give @p minecraft:arrow[item_model="cam:bone_arrow",custom_data={CAM_bone_arrow:1b},item_name="{\"translate\":\"item.cam.bone_arrow\"}"]

