execute as @e[type=arrow,tag=!CAM_bone_arrow_triggered] at @s run function cam:cm/bone_arrow/trigger

execute as @e[type=arrow,nbt={inGround:1b},tag=CAM_bone_arrow] at @s run function cam:cm/bone_arrow/tick_