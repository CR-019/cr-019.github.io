particle item{item:"bone"} ~ ~ ~ .2 .2 .2 0.05 20 normal
playsound block.bone_block.break player @a ~ ~ ~ 1
kill @s
