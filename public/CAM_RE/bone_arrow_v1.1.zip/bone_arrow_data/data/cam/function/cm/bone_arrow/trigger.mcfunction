tag @s add CAM_bone_arrow_triggered
scoreboard players set #temp CAM_arrow_con1 0
execute if entity @s[nbt={item:{components:{"minecraft:custom_data":{CAM_bone_arrow:1b}}}}] run function cam:cm/bone_arrow/trigger_
execute on origin if entity @s[type=#skeletons] run scoreboard players set #temp CAM_arrow_con1 1
execute if score #temp CAM_arrow_con1 matches 1 run function cam:cm/bone_arrow/trigger_