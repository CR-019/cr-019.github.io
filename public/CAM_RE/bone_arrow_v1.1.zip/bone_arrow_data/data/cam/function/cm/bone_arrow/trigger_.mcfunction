tag @s add CAM_bone_arrow
tag @s add CAM_not_pickup
data modify entity @s crit set value 0b