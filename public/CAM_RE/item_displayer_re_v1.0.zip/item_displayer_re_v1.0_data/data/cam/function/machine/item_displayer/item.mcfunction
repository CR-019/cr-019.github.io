scoreboard players operation #3 CAM_dis_number = @s CAM_dis_number
execute as @e[type=item,tag=cam_dis_item] if score @s CAM_dis_number = #3 CAM_dis_number run scoreboard players set #4 CAM_dis_number 1
execute unless score #4 CAM_dis_number matches 1 run summon item ~ ~1 ~ {Item:{count:1b,id:"minecraft:stone"},CustomNameVisible:0b,PickupDelay:32767,Age:-32768,Tags:["cam_dis_item","cam_sac_temp"]}
tag @s add CAM_displayer_temp
execute as @e[type=item,tag=cam_sac_temp] run scoreboard players operation @s CAM_dis_number = #3 CAM_dis_number
execute as @e[type=item,tag=cam_sac_temp] run data modify entity @s Owner set from entity @e[type=item_display,tag=CAM_displayer_temp,limit=1] UUID
execute as @e[type=item,tag=cam_sac_temp] run tag @s remove cam_sac_temp
tag @s remove CAM_displayer_temp