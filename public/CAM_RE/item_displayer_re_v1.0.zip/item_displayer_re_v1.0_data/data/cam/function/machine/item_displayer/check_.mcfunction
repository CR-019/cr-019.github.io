$execute at @s unless items block ~ ~ ~ container.$(var) *[custom_data~{CAM_bg:1b}] positioned ~ ~ ~ run function cam:machine/item_displayer/check_replace {var:$(var)}
