#放置与破坏处理
execute as @s[type=minecraft:item_display,tag=cam_item_displayer_temp] at @s align xyz run function cam:machine/item_displayer/replace
execute as @s[type=minecraft:item_display,tag=cam_item_displayer,tag=CAM_display_enable] at @s unless block ~ ~ ~ minecraft:barrel run function cam:machine/item_displayer/clear
execute as @s[type=minecraft:item_display,tag=cam_item_displayer,tag=CAM_display_enable] run data modify entity @s brightness set value {block:15,sky:15}
