execute unless items block ~ ~-1 ~ container.13 * run data modify entity @s Item.components."minecraft:item_model" set value "display:empty"
execute if items block ~ ~-1 ~ container.13 * run data remove entity @s Item.components."minecraft:item_model"
execute if items block ~ ~-1 ~ container.13 * run data modify entity @s Item.id set from block ~ ~-1 ~ Items[{Slot:13b}].id
execute if items block ~ ~-1 ~ container.13 * run data modify entity @s Item.components set from block ~ ~-1 ~ Items[{Slot:13b}].components