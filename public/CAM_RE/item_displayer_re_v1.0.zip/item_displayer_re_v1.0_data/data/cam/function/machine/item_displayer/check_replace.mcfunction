$execute if items block ~ ~ ~ container.$(var) * at @a[sort=nearest,limit=1,scores={CAM_diserror=1..}] run summon item ~ ~ ~ {Tags:[cam_item_displayer_item],Item:{id:"stone",count:1}}
$data modify entity @e[type=item,tag=cam_item_displayer_item,limit=1] Item set from block ~ ~ ~ Items[{Slot:$(var)b}]
tag @e[type=item,tag=cam_item_displayer_item,limit=1] remove cam_item_displayer_item

$item replace block ~ ~ ~ container.$(var) with firework_star[item_model="display:empty",item_name="{\"translate\":\"item.cam.item_displayer\"}",custom_data={CAM_bg:1b}]
