scoreboard players set @s CAM_lantern_type -1

summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}
summon marker ~ ~ ~ {Tags:["cam_kongmin_lantern_marker"],"data": {"CAM_lantern_type":-1}}

spreadplayers ~ ~ 0 20 false @e[type=marker,tag=cam_kongmin_lantern_marker]
execute as @e[type=marker,tag=cam_kongmin_lantern_marker] at @s run function cam:cm/palace_lantern/put_2
