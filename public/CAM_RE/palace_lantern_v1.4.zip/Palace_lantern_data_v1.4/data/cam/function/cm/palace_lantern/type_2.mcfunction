execute store result entity @s ArmorItems[3].components."minecraft:custom_data".CAM_lantern_type int 1 run scoreboard players get @s CAM_lantern_type

data modify storage cam:palace_lantern model.head set value "cm:palace_lantern/kongmin"
execute store result storage cam:palace_lantern model.id int 1 run data get entity @s ArmorItems[3].components."minecraft:custom_data".CAM_lantern_type
function cam:cm/palace_lantern/set_type with storage cam:palace_lantern model

execute store result score @s CAM_lantern_v run random value 100..300