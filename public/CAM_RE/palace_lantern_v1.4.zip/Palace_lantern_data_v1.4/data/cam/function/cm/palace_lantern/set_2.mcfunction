advancement revoke @s only cam:countryside_and_magic/kongmin_lantern

execute as @a if data entity @s SelectedItem.components.minecraft:custom_data.CAM_palace_lantern store result score @s CAM_lantern_type run data get entity @s SelectedItem.components.minecraft:custom_data.CAM_lantern_type
execute as @a if data entity @s Inventory[{Slot:-106b}].components.minecraft:custom_data.CAM_palace_lantern unless data entity @s SelectedItem.components.minecraft:custom_data.CAM_palace_lantern store result score @s CAM_lantern_type run data get entity @s Inventory[{Slot:-106b}].components.minecraft:custom_data.CAM_lantern_type

execute at @e[type=marker,distance=..7,tag=cam_kongmin_lantern_marker] run function cam:cm/palace_lantern/put_2
kill @e[type=marker,distance=..7,tag=cam_kongmin_lantern_marker]
