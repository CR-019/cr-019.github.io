execute if entity @s[tag=!CAM_hang] if block ~ ~ ~ minecraft:lantern[hanging=true] run function cam:cm/palace_lantern/hang

execute if entity @s[tag=CAM_hang] if block ~ ~ ~ minecraft:lantern[hanging=false] run function cam:cm/palace_lantern/hang_de


execute if block ~ ~ ~ minecraft:lantern[hanging=true] run tag @s add CAM_hang
execute if block ~ ~ ~ minecraft:lantern[hanging=false] run tag @s remove CAM_hang
