function cam:cm/palace_lantern/hang_de
execute at @s as @e[type=item,nbt={Item:{id:"minecraft:lantern"}},distance=..2,limit=1,nbt=!{Item:{components:{"minecraft:custom_data":{CAM_palace_lantern:1b}}}}] run data modify entity @s Item.components set from entity @e[limit=1,type=minecraft:armor_stand,tag=cam_palace_lantern,sort=nearest] ArmorItems[3].components
kill @s