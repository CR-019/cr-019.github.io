# 执行者：marker
execute store result score @s CAM_lantern_type run data get entity @s data.CAM_lantern_type


summon minecraft:armor_stand ~ ~ ~ {Invulnerable:0b,NoGravity:0b,Invisible:1b,Small:1b,DisabledSlots:7967,Tags:["cam_kongmin_lantern","cam_lantern_temp"],ArmorItems:[{},{},{},{id:"minecraft:lantern",count:1b,components:{custom_data:{CAM_palace_lantern:2b,CAM_lantern_type:1},item_model:"cm:palace_lantern/kongmin/1"}}]}
summon minecraft:slime ~ 319 ~ {NoAI:1b,Silent:1b,DeathLootTable:"cam:cam/empty",active_effects:[{id:"invisibility",amplifier:0,duration:-1,show_particles:0b}],Health:1,Size:0,Tags:["CAM_lantern_sub","CAM_lantern_sub_"],wasOnGround:false,OnGround:false,FallDistance:0}
execute as @e[type=slime,tag=CAM_lantern_sub_,sort=nearest,limit=1] run tp ~ ~ ~
execute as @e[type=slime,tag=CAM_lantern_sub_,sort=nearest,limit=1] run attribute @s scale base set 1.2
execute as @e[type=armor_stand,tag=cam_kongmin_lantern,limit=1,sort=nearest] run scoreboard players operation @s CAM_lantern_code = # CAM_lantern_code
execute as @e[type=slime,tag=CAM_lantern_sub_,sort=nearest,limit=1] run scoreboard players operation @s CAM_lantern_code = # CAM_lantern_code


scoreboard players operation @e[tag=cam_lantern_temp] CAM_lantern_type = @s CAM_lantern_type
execute as @e[type=minecraft:armor_stand,tag=cam_lantern_temp] if score @s CAM_lantern_type matches -1 run function cam:cm/palace_lantern/random
execute as @e[type=minecraft:armor_stand,tag=cam_lantern_temp] at @s run function cam:cm/palace_lantern/type_2
kill @e[type=area_effect_cloud,distance=..0.01,tag=CAM_block_pos]
tag @e[tag=cam_lantern_temp] remove cam_lantern_temp
kill @s

execute as @e[type=slime,tag=CAM_lantern_sub_] run tag @s remove CAM_lantern_sub_
scoreboard players add # CAM_lantern_code 1
