summon minecraft:armor_stand ~ ~ ~ {Invulnerable:1b,Invisible:1b,Small:1b,NoGravity:1b,Marker:1b,DisabledSlots:7967,Tags:["cam_palace_lantern","cam_lantern_temp"],ArmorItems:[{},{},{},{id:"minecraft:lantern",count:1b,components:{custom_data:{id:"cam:palace_lantern",CAM_palace_lantern:1b,CAM_lantern_type:1},item_model:"cm:palace_lantern/normal/1"}}]}
scoreboard players operation @e[tag=cam_lantern_temp] CAM_lantern_type = @s CAM_lantern_type
execute as @e[type=minecraft:armor_stand,tag=cam_lantern_temp] if score @s CAM_lantern_type matches -1 run function cam:cm/palace_lantern/random
execute as @e[type=minecraft:armor_stand,tag=cam_lantern_temp] at @s run function cam:cm/palace_lantern/type
kill @e[type=area_effect_cloud,distance=..0.01,tag=CAM_block_pos]
execute as @e[tag=cam_lantern_temp] run function cam:cm/palace_lantern/name
tag @e[tag=cam_lantern_temp] remove cam_lantern_temp
