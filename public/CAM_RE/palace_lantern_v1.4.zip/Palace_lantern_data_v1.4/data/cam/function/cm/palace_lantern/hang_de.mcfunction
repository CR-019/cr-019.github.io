data modify storage cam:palace_lantern model.head set value "cm:palace_lantern/normal"
execute store result storage cam:palace_lantern model.id int 1 run data get entity @s ArmorItems[3].components."minecraft:custom_data".CAM_lantern_type
function cam:cm/palace_lantern/set_type with storage cam:palace_lantern model