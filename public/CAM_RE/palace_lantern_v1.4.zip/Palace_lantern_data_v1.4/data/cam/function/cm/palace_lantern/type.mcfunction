execute store result entity @s ArmorItems[3].components.minecraft:custom_data.CAM_lantern_type int 1 run scoreboard players get @s CAM_lantern_type
execute if block ~ ~ ~ minecraft:lantern[hanging=true] run function cam:cm/palace_lantern/hang
execute unless block ~ ~ ~ minecraft:lantern[hanging=true] run function cam:cm/palace_lantern/hang_de
execute if block ~ ~ ~ minecraft:lantern[hanging=true] run tag @s add CAM_hang
