execute if items entity @s player.cursor *[custom_data~{CAM_chainblade_status:2b}] run clear @s *[custom_data~{CAM_chainblade_status:2b}]
execute if items entity @s hotbar.* *[custom_data~{CAM_chainblade_status:2b}] run clear @s *[custom_data~{CAM_chainblade_status:2b}]
execute if items entity @s inventory.* *[custom_data~{CAM_chainblade_status:2b}] run clear @s *[custom_data~{CAM_chainblade_status:2b}]
