#将等级参数传入

execute store result score #temp CAM_enchantments_bleed store result storage cam:enchant bleed.lvl int 1 run data get entity @s SelectedItem.components."minecraft:enchantments".levels."cam:bleed"