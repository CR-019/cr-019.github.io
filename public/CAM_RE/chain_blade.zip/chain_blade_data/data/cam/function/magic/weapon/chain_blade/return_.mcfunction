function lay:macro/inventory/init
data modify storage lay Inventory.target set value {components:{"minecraft:custom_data":{CAM_chainblade_status:1b}}}
data modify storage lay Inventory.func set value "cam:magic/weapon/chain_blade/return__"
function lay:macro/inventory/start