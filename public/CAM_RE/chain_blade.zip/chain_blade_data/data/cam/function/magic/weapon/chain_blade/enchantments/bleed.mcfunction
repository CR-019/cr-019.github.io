execute store result score #temp CAM_enchantments_bleed run data get entity @a[tag=CAM_chainowner,limit=1] SelectedItem.components.minecraft:enchantments.levels."cam:bleed"

execute as @n[type=!fishing_bobber,type=!minecraft:arrow,dx=0,dy=0,dz=0] at @s run function cam:magic/new_enchants/bleed/random