#寻找持有者
execute on origin run tag @s add CAM_chainowner

#判定与生成
tag @s add CAM_blade_temp
execute as @e[type=!fishing_bobber,dx=0,dy=0,dz=0,tag=!CAM_chainowner] positioned ~-1 ~-1 ~-1 if entity @s[type=!minecraft:item] run tag @s add find
execute as @e[type=!fishing_bobber,dx=0,dy=0,dz=0,tag=!CAM_chainowner] positioned ~-1 ~-1 ~-1 if entity @s[type=minecraft:item] run tag @s add find2
execute if entity @e[tag=find] if entity @s[tag=!first] run tag @s add CAM_shoot
execute if entity @e[tag=find2] if entity @s[tag=!first] run kill @s

#数据处理
execute as @a[tag=CAM_chainowner] if entity @e[tag=find] run scoreboard players add @s CAM_chain_damage 1

execute as @e[tag=find] store result score @s CAM_chain_damage run data get entity @a[tag=CAM_chainowner,limit=1] SelectedItem.components.minecraft:custom_data.dartsdamage
#附魔
execute as @e[tag=find] at @s run function cam:magic/weapon/chain_blade/enchantments
execute as @e[tag=find] run function cam:magic/weapon/chain_blade/test2
#音效与后处理
execute as @e[tag=CAM_shoot] run playsound minecraft:item.shield.break neutral @a ~ ~ ~
execute as @e[tag=CAM_shoot] run kill @s
execute as @e[tag=CAM_blade_temp,nbt={inGround:1b}] run kill @s
execute if entity @e[tag=!find] if entity @s[tag=first] run tag @s remove first
tag @e remove find
tag @e remove find2
tag @e remove find3
tag @e remove find4
tag @e remove CAM_blade_temp
tag @a remove CAM_chainowner