execute store result score #temp CAM_chain_damage run data get entity @s SelectedItem.components."minecraft:damage"

scoreboard players operation #temp CAM_chain_damage += @s CAM_chain_damage

scoreboard players reset @s CAM_chain_damage

execute store result storage cam:chainblade damage int 1 run scoreboard players get #temp CAM_chain_damage

execute unless entity @s[gamemode=creative] run function cam:magic/weapon/chain_blade/break_ with storage cam:chainblade