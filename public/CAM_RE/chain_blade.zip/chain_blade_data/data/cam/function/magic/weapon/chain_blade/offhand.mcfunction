#替换副手
execute if items entity @s weapon.offhand * unless predicate cam:weapon/chain_blade/sub at @s run function utils:drop/drop

execute if predicate cam:weapon/chain_blade/status_deactivate run function cam:magic/weapon/chain_blade/offhand_sync
execute unless predicate cam:weapon/chain_blade/sub run function cam:magic/weapon/chain_blade/offhand_sync