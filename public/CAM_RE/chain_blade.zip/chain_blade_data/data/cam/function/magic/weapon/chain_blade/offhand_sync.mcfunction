# 副刀替换
summon item_display ~ ~ ~ {Tags:["CAM_chainblade_temp"]}
item replace entity @n[type=item_display,tag=CAM_chainblade_temp] contents from entity @s weapon.mainhand
data modify entity @n[type=item_display,tag=CAM_chainblade_temp] item.id set value "minecraft:fishing_rod"
item modify entity @n[type=item_display,tag=CAM_chainblade_temp] contents cam:weapon/chain_blade/handheld_off
item replace entity @s weapon.offhand from entity @n[type=item_display,tag=CAM_chainblade_temp] contents
kill @n[type=item_display,tag=CAM_chainblade_temp]