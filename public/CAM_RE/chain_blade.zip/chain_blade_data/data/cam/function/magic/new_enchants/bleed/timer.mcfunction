scoreboard players remove @s CAM_enchantments_bleed_timer 1
scoreboard players operation #temp CAM_enchantments_bleed_timer = @s CAM_enchantments_bleed_timer
scoreboard players operation #temp CAM_enchantments_bleed_timer %= #40 CAM_enchantments_bleed_timer
execute if score #temp CAM_enchantments_bleed_timer matches 0 run damage @s 1 cam:bleed

execute store result score #temp2 CAM_enchantments_bleed_timer run random value 1..20
execute if score #temp2 CAM_enchantments_bleed_timer matches 1..3 run particle falling_lava ~ ~1 ~ 0.2 0.2 0.2 0 5

execute unless score @s CAM_enchantments_bleed_timer matches 1.. run tag @s remove CAM_bleed