#手持
execute as @a[predicate=cam:weapon/chain_blade/main] at @s run function cam:magic/weapon/chain_blade/replace

#副刀存在处理
execute as @a run function cam:magic/weapon/chain_blade/clear
execute as @a unless predicate cam:weapon/chain_blade/both run clear @s *[custom_data~{CAM_chainblade_status:2b}]
execute as @a if predicate cam:weapon/chain_blade/off run function cam:magic/weapon/chain_blade/offhand_swap
execute as @e[type=item] if items entity @s contents *[custom_data~{CAM_chainblade_status:2b}] run kill @s

#归位（滑动到其他位置触发）
execute as @a unless predicate cam:weapon/chain_blade/main run function cam:magic/weapon/chain_blade/return



#远程
execute as @a[scores={CAM_chain_use=1..},predicate=cam:weapon/chain_blade/sub] at @s run tag @n[type=minecraft:fishing_bobber,limit=1,sort=nearest] add CAM_chainblade
tag @e[type=fishing_bobber,tag=CAM_chainblade,tag=!start] add first
tag @e[type=fishing_bobber,tag=CAM_chainblade] add start

#副刀
execute as @e[type=fishing_bobber,tag=CAM_chainblade] at @s run function cam:magic/weapon/chain_blade/function

execute as @e[type=minecraft:arrow,nbt={inGround:1b},tag=CAM_arrow] run kill @s
scoreboard players set @a CAM_chain_use 0

#耐久
execute as @a[predicate=cam:weapon/chain_blade/main] if score @s CAM_chain_damage matches 1.. run function cam:magic/weapon/chain_blade/break