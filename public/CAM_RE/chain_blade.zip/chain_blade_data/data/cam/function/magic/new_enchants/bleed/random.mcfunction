execute store result score #random CAM_enchantments_bleed run random value 1..10
function cam:magic/new_enchants/bleed/random_ with storage cam:enchant bleed