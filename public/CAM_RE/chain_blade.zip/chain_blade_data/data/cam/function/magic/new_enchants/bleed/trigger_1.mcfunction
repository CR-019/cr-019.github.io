tag @s remove CAM_bleed

execute store result storage cam:enchant bleed.damage float 0.1 run scoreboard players get @s CAM_enchantments_bleed_timer
particle falling_lava ~ ~1 ~ 0.5 0.5 0.5 0 200
playsound minecraft:entity.iron_golem.damage player @a ~ ~ ~
function cam:magic/new_enchants/bleed/damage with storage cam:enchant bleed


scoreboard players set @s CAM_enchantments_bleed_timer 0