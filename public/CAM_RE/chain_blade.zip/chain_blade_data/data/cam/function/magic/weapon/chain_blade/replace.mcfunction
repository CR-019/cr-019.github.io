## 手中的其他链刃归位（切换时触发）
execute if predicate cam:weapon/chain_blade/status_deactivate run function cam:magic/weapon/chain_blade/return

## 副手设置
function cam:magic/weapon/chain_blade/offhand

## 设置激活状态
execute if predicate cam:weapon/chain_blade/status_deactivate run item modify entity @s weapon.mainhand cam:weapon/chain_blade/handheld_main

