tag @s add CAM_bleed
scoreboard players set @s CAM_enchantments_bleed_timer 160
particle trial_spawner_detection ~ ~0.5 ~ 0.2 0.2 0.2 0 20
playsound minecraft:entity.firework_rocket.large_blast player @a ~ ~ ~