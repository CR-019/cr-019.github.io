#失效
execute as @s[nbt={OnGround:1b}] run function cam:magic/weapon/chain_blade/groundsound
execute if predicate cam:weapon/chain_blade/water run playsound minecraft:entity.generic.splash neutral @a ~ ~ ~
execute if predicate cam:weapon/chain_blade/water run function cam:magic/weapon/chain_blade/groundsound
#有效
execute as @s[nbt={OnGround:0b}] run function cam:magic/weapon/chain_blade/test

