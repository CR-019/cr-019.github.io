#附魔
#execute as @s if entity @a[predicate=cam:weapon/fire_aspect,tag=CAM_chainowner,limit=1] run data modify entity @s Fire set value 2000s 
execute as @s if entity @a[predicate=cam:enchantments/sharpness,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/enchantments/sharp
execute at @s as @e[type=!fishing_bobber,type=!minecraft:arrow,dx=0,dy=0,dz=0] if entity @s[type=#uin:custom/graveborn] as @n[tag=find,sort=nearest,limit=1] if entity @a[predicate=cam:enchantments/smite,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/enchantments/smite
execute at @s as @e[type=!fishing_bobber,type=!minecraft:arrow,dx=0,dy=0,dz=0] if entity @s[type=#uin:tech/arthropods] as @n[tag=find,sort=nearest,limit=1] if entity @a[predicate=cam:enchantments/bane_of_arthropods,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/enchantments/bane_of_arthropods
#祭祀附魔
execute at @s as @e[type=!fishing_bobber,type=!minecraft:arrow,dx=0,dy=0,dz=0] as @n[tag=find,sort=nearest,limit=1] if entity @a[predicate=cam:enchantments/bleed,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/enchantments/bleed

#execute as @s if entity @a[predicate=cam:weapon/poison,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/poison
#execute as @s if entity @a[predicate=cam:weapon/wither,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/wither
#execute as @s if entity @a[predicate=cam:weapon/freeze,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/freeze
#execute as @s if entity @a[predicate=cam:weapon/decay,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/decay
#execute as @s if entity @a[predicate=cam:weapon/rattlesnake,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/rattlesnake
#execute as @s if entity @a[predicate=cam:weapon/bloodrage,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/bloodrage

#execute as @s if entity @a[predicate=cam:weapon/vampire,tag=CAM_chainowner,limit=1] run function cam:magic/weapon/chain_blade/vampire