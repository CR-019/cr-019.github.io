execute unless entity @s[tag=CAM_bleed] run scoreboard players set #trigger CAM_enchantments_bleed 0
execute if entity @s[tag=CAM_bleed] run scoreboard players set #trigger CAM_enchantments_bleed 1

execute if score #trigger CAM_enchantments_bleed matches 0 run function cam:magic/new_enchants/bleed/trigger_0
execute if score #trigger CAM_enchantments_bleed matches 1 run function cam:magic/new_enchants/bleed/trigger_1