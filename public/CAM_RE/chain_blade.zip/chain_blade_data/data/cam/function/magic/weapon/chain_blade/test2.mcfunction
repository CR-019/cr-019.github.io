execute store result storage cam chain_blade.damage float 1 run scoreboard players get @s CAM_chain_damage

function cam:magic/weapon/chain_blade/damage with storage cam chain_blade
