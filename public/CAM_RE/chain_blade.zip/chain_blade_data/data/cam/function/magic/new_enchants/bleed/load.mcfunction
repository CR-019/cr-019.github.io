scoreboard objectives add CAM_enchantments_bleed dummy
scoreboard objectives add CAM_enchantments_bleed_timer dummy

scoreboard players set #40 CAM_enchantments_bleed_timer 40
scoreboard players set #10 CAM_enchantments_bleed_timer 10