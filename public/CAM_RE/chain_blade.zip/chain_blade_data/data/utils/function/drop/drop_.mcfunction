data modify entity @s Owner set from entity @a[limit=1,tag=utils_drop_player_temp] UUID
data modify entity @s Item set from storage utils drop.item
tag @s remove utils_drop_temp