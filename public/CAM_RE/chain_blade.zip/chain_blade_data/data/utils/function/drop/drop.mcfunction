tag @s add utils_drop_player_temp
data modify storage utils drop.item set from entity @s Inventory[{Slot:-106b}]
summon item ~ ~ ~ {Tags:[utils_drop_temp],Item:{id:"stone",count:1}}
execute as @e[type=item,distance=..2,tag=utils_drop_temp] run function utils:drop/drop_
item replace entity @s weapon.offhand with air
tag @s remove utils_drop_player_temp