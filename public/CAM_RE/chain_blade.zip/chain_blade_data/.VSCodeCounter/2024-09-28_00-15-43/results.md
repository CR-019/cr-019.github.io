# Summary

Date : 2024-09-28 00:15:43

Directory d:\\360极速浏览器下载\\.minecraft\\saves\\dtp_lab25\\datapacks\\CAM_0.3.3_data

Total : 2842 files,  54478 codes, 449 comments, 2381 blanks, all 57308 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 1,123 | 41,578 | 0 | 1,023 | 42,601 |
| mcfunction | 1,717 | 12,640 | 449 | 1,313 | 14,402 |
| Markdown | 1 | 253 | 0 | 44 | 297 |
| MCMETA | 1 | 7 | 0 | 1 | 8 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 2,842 | 54,478 | 449 | 2,381 | 57,308 |
| . (Files) | 1 | 7 | 0 | 1 | 8 |
| data | 2,841 | 54,471 | 449 | 2,380 | 57,300 |
| data\\auto_encoder | 3 | 19 | 0 | 1 | 20 |
| data\\auto_encoder\\advancements | 1 | 15 | 0 | 1 | 16 |
| data\\auto_encoder\\functions | 2 | 4 | 0 | 0 | 4 |
| data\\cam | 2,343 | 32,227 | 407 | 1,928 | 34,562 |
| data\\cam\\advancements | 103 | 3,695 | 0 | 97 | 3,792 |
| data\\cam\\advancements\\3_year | 10 | 261 | 0 | 10 | 271 |
| data\\cam\\advancements\\combat | 5 | 121 | 0 | 0 | 121 |
| data\\cam\\advancements\\countryside_and_magic | 77 | 3,071 | 0 | 76 | 3,147 |
| data\\cam\\advancements\\enchants | 11 | 242 | 0 | 11 | 253 |
| data\\cam\\damage_type | 10 | 50 | 0 | 0 | 50 |
| data\\cam\\functions | 1,583 | 8,086 | 407 | 1,242 | 9,735 |
| data\\cam\\functions (Files) | 1 | 219 | 0 | 1 | 220 |
| data\\cam\\functions\\3_year | 15 | 35 | 0 | 5 | 40 |
| data\\cam\\functions\\3_year\\adv | 11 | 31 | 0 | 5 | 36 |
| data\\cam\\functions\\3_year\\give | 4 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\advancements | 15 | 49 | 3 | 7 | 59 |
| data\\cam\\functions\\cm | 157 | 767 | 29 | 130 | 926 |
| data\\cam\\functions\\cm (Files) | 3 | 10 | 3 | 4 | 17 |
| data\\cam\\functions\\cm\\arrow | 3 | 37 | 0 | 8 | 45 |
| data\\cam\\functions\\cm\\bone_arrow | 5 | 16 | 0 | 2 | 18 |
| data\\cam\\functions\\cm\\bushmeat | 1 | 12 | 0 | 1 | 13 |
| data\\cam\\functions\\cm\\butcher | 2 | 4 | 0 | 2 | 6 |
| data\\cam\\functions\\cm\\cane | 4 | 54 | 0 | 9 | 63 |
| data\\cam\\functions\\cm\\cat | 3 | 19 | 0 | 0 | 19 |
| data\\cam\\functions\\cm\\celebration_harpoon | 28 | 92 | 0 | 14 | 106 |
| data\\cam\\functions\\cm\\celebration_harpoon (Files) | 8 | 72 | 0 | 14 | 86 |
| data\\cam\\functions\\cm\\celebration_harpoon\\fireworks | 20 | 20 | 0 | 0 | 20 |
| data\\cam\\functions\\cm\\chinese_knot | 4 | 15 | 1 | 3 | 19 |
| data\\cam\\functions\\cm\\compass | 3 | 13 | 0 | 1 | 14 |
| data\\cam\\functions\\cm\\dream_catcher | 49 | 221 | 6 | 41 | 268 |
| data\\cam\\functions\\cm\\dream_catcher (Files) | 12 | 101 | 5 | 23 | 129 |
| data\\cam\\functions\\cm\\dream_catcher\\particle | 21 | 71 | 1 | 18 | 90 |
| data\\cam\\functions\\cm\\dream_catcher\\particle (Files) | 13 | 39 | 1 | 10 | 50 |
| data\\cam\\functions\\cm\\dream_catcher\\particle\\3 | 8 | 32 | 0 | 8 | 40 |
| data\\cam\\functions\\cm\\dream_catcher\\type | 16 | 49 | 0 | 0 | 49 |
| data\\cam\\functions\\cm\\float | 4 | 6 | 2 | 3 | 11 |
| data\\cam\\functions\\cm\\fox | 4 | 12 | 0 | 2 | 14 |
| data\\cam\\functions\\cm\\palace_lantern | 18 | 146 | 6 | 16 | 168 |
| data\\cam\\functions\\cm\\poisonous_potato | 3 | 7 | 0 | 0 | 7 |
| data\\cam\\functions\\cm\\rice | 7 | 25 | 1 | 5 | 31 |
| data\\cam\\functions\\cm\\sculk | 7 | 33 | 1 | 5 | 39 |
| data\\cam\\functions\\cm\\sculk (Files) | 3 | 9 | 0 | 0 | 9 |
| data\\cam\\functions\\cm\\sculk\\activate | 2 | 21 | 1 | 3 | 25 |
| data\\cam\\functions\\cm\\sculk\\senser | 2 | 3 | 0 | 2 | 5 |
| data\\cam\\functions\\cm\\totem | 3 | 18 | 0 | 1 | 19 |
| data\\cam\\functions\\cm\\woolball | 6 | 27 | 9 | 13 | 49 |
| data\\cam\\functions\\combat | 24 | 124 | 8 | 32 | 164 |
| data\\cam\\functions\\combat\\shield | 24 | 124 | 8 | 32 | 164 |
| data\\cam\\functions\\combat\\shield (Files) | 16 | 71 | 8 | 16 | 95 |
| data\\cam\\functions\\combat\\shield\\enchant | 8 | 53 | 0 | 16 | 69 |
| data\\cam\\functions\\death_tracer | 4 | 15 | 2 | 7 | 24 |
| data\\cam\\functions\\fisma_co | 3 | 50 | 0 | 4 | 54 |
| data\\cam\\functions\\fisma_co (Files) | 1 | 10 | 0 | 1 | 11 |
| data\\cam\\functions\\fisma_co\\error_stew | 2 | 40 | 0 | 3 | 43 |
| data\\cam\\functions\\give | 129 | 129 | 1 | 6 | 136 |
| data\\cam\\functions\\give (Files) | 99 | 99 | 1 | 5 | 105 |
| data\\cam\\functions\\give\\copper_pickaxe | 3 | 3 | 0 | 1 | 4 |
| data\\cam\\functions\\give\\copper_sword | 7 | 7 | 0 | 0 | 7 |
| data\\cam\\functions\\give\\dream_catcher | 16 | 16 | 0 | 0 | 16 |
| data\\cam\\functions\\give\\weapon_debris | 4 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\health_tracer | 4 | 8 | 1 | 2 | 11 |
| data\\cam\\functions\\knockback | 8 | 45 | 0 | 0 | 45 |
| data\\cam\\functions\\lay | 10 | 39 | 3 | 5 | 47 |
| data\\cam\\functions\\machine | 415 | 2,162 | 90 | 299 | 2,551 |
| data\\cam\\functions\\machine\\barrel | 67 | 577 | 8 | 93 | 678 |
| data\\cam\\functions\\machine\\barrel (Files) | 15 | 105 | 6 | 14 | 125 |
| data\\cam\\functions\\machine\\barrel\\execute | 25 | 316 | 2 | 79 | 397 |
| data\\cam\\functions\\machine\\barrel\\replace | 27 | 156 | 0 | 0 | 156 |
| data\\cam\\functions\\machine\\crafting_table | 118 | 274 | 19 | 54 | 347 |
| data\\cam\\functions\\machine\\crafting_table\\modules | 1 | 39 | 1 | 11 | 51 |
| data\\cam\\functions\\machine\\crafting_table\\recipes | 117 | 235 | 18 | 43 | 296 |
| data\\cam\\functions\\machine\\crafting_table\\recipes (Files) | 45 | 126 | 18 | 35 | 179 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\dream_catcher | 16 | 16 | 0 | 0 | 16 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\harpoon | 6 | 19 | 0 | 4 | 23 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern | 46 | 70 | 0 | 0 | 70 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern (Files) | 12 | 18 | 0 | 0 | 18 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern\\kongmin | 23 | 35 | 0 | 0 | 35 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern\\kongmin (Files) | 12 | 18 | 0 | 0 | 18 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern\\kongmin\\red | 11 | 17 | 0 | 0 | 17 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\palace_lantern\\red | 11 | 17 | 0 | 0 | 17 |
| data\\cam\\functions\\machine\\crafting_table\\recipes\\weapon_debris | 4 | 4 | 0 | 4 | 8 |
| data\\cam\\functions\\machine\\furnace | 45 | 170 | 0 | 29 | 199 |
| data\\cam\\functions\\machine\\furnace (Files) | 3 | 14 | 0 | 2 | 16 |
| data\\cam\\functions\\machine\\furnace\\tick | 42 | 156 | 0 | 27 | 183 |
| data\\cam\\functions\\machine\\furnace\\tick (Files) | 3 | 10 | 0 | 2 | 12 |
| data\\cam\\functions\\machine\\furnace\\tick\\recipes | 39 | 146 | 0 | 25 | 171 |
| data\\cam\\functions\\machine\\furnace\\tick\\recipes\\bamboo | 11 | 39 | 0 | 4 | 43 |
| data\\cam\\functions\\machine\\furnace\\tick\\recipes\\copper | 11 | 42 | 0 | 11 | 53 |
| data\\cam\\functions\\machine\\furnace\\tick\\recipes\\fish | 7 | 28 | 0 | 6 | 34 |
| data\\cam\\functions\\machine\\furnace\\tick\\recipes\\leather | 10 | 37 | 0 | 4 | 41 |
| data\\cam\\functions\\machine\\item_displayer | 51 | 337 | 19 | 34 | 390 |
| data\\cam\\functions\\machine\\item_displayer (Files) | 21 | 167 | 19 | 32 | 218 |
| data\\cam\\functions\\machine\\item_displayer\\replace | 29 | 167 | 0 | 2 | 169 |
| data\\cam\\functions\\machine\\item_displayer\\update | 1 | 3 | 0 | 0 | 3 |
| data\\cam\\functions\\machine\\sacrificing_table | 134 | 804 | 44 | 89 | 937 |
| data\\cam\\functions\\machine\\sacrificing_table (Files) | 37 | 370 | 39 | 73 | 482 |
| data\\cam\\functions\\machine\\sacrificing_table\\inventory | 36 | 180 | 0 | 0 | 180 |
| data\\cam\\functions\\machine\\sacrificing_table\\lore | 10 | 28 | 5 | 13 | 46 |
| data\\cam\\functions\\machine\\sacrificing_table\\lore_give | 22 | 59 | 0 | 2 | 61 |
| data\\cam\\functions\\machine\\sacrificing_table\\lore_give (Files) | 18 | 55 | 0 | 2 | 57 |
| data\\cam\\functions\\machine\\sacrificing_table\\lore_give\\catalyze | 4 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\machine\\sacrificing_table\\replace | 28 | 164 | 0 | 1 | 165 |
| data\\cam\\functions\\machine\\sacrificing_table\\update | 1 | 3 | 0 | 0 | 3 |
| data\\cam\\functions\\magic | 428 | 2,378 | 136 | 434 | 2,948 |
| data\\cam\\functions\\magic\\antigrind | 78 | 310 | 0 | 78 | 388 |
| data\\cam\\functions\\magic\\antigrind (Files) | 3 | 85 | 0 | 5 | 90 |
| data\\cam\\functions\\magic\\antigrind\\replace_1 | 36 | 144 | 0 | 72 | 216 |
| data\\cam\\functions\\magic\\antigrind\\replace_2 | 36 | 72 | 0 | 0 | 72 |
| data\\cam\\functions\\magic\\antigrind\\type | 3 | 9 | 0 | 1 | 10 |
| data\\cam\\functions\\magic\\bowenchant | 17 | 103 | 5 | 15 | 123 |
| data\\cam\\functions\\magic\\bowenchant (Files) | 8 | 75 | 1 | 15 | 91 |
| data\\cam\\functions\\magic\\bowenchant\\backtrack | 9 | 28 | 4 | 0 | 32 |
| data\\cam\\functions\\magic\\echo_prism | 12 | 59 | 0 | 16 | 75 |
| data\\cam\\functions\\magic\\heart | 4 | 10 | 0 | 2 | 12 |
| data\\cam\\functions\\magic\\killer | 3 | 8 | 0 | 0 | 8 |
| data\\cam\\functions\\magic\\new_dec_enchants | 32 | 114 | 6 | 12 | 132 |
| data\\cam\\functions\\magic\\new_dec_enchants\\chime | 3 | 8 | 0 | 2 | 10 |
| data\\cam\\functions\\magic\\new_dec_enchants\\meow | 3 | 4 | 0 | 2 | 6 |
| data\\cam\\functions\\magic\\new_dec_enchants\\notes | 3 | 22 | 0 | 1 | 23 |
| data\\cam\\functions\\magic\\new_dec_enchants\\rainbow | 8 | 42 | 3 | 1 | 46 |
| data\\cam\\functions\\magic\\new_dec_enchants\\rememberence | 5 | 11 | 0 | 2 | 13 |
| data\\cam\\functions\\magic\\new_dec_enchants\\sculk | 7 | 20 | 3 | 3 | 26 |
| data\\cam\\functions\\magic\\new_dec_enchants\\soul_taker | 2 | 3 | 0 | 1 | 4 |
| data\\cam\\functions\\magic\\new_dec_enchants\\water_blade | 1 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\magic\\new_enchants | 163 | 812 | 76 | 166 | 1,054 |
| data\\cam\\functions\\magic\\new_enchants\\_entity | 30 | 143 | 9 | 27 | 179 |
| data\\cam\\functions\\magic\\new_enchants\\_entity (Files) | 13 | 32 | 6 | 3 | 41 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc | 17 | 111 | 3 | 24 | 138 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\backbite | 4 | 13 | 0 | 0 | 13 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\br | 3 | 12 | 0 | 4 | 16 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\decay | 1 | 6 | 0 | 1 | 7 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\dizziness | 1 | 6 | 0 | 0 | 6 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\freeze | 1 | 8 | 0 | 0 | 8 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\phylactery | 1 | 35 | 2 | 12 | 49 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\poison | 1 | 3 | 0 | 2 | 5 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\rampage | 1 | 9 | 0 | 0 | 9 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\vampire | 3 | 16 | 1 | 3 | 20 |
| data\\cam\\functions\\magic\\new_enchants\\_entity\\misc\\wither | 1 | 3 | 0 | 2 | 5 |
| data\\cam\\functions\\magic\\new_enchants\\_master | 2 | 24 | 1 | 17 | 42 |
| data\\cam\\functions\\magic\\new_enchants\\armor | 2 | 3 | 0 | 1 | 4 |
| data\\cam\\functions\\magic\\new_enchants\\armor (Files) | 1 | 1 | 0 | 0 | 1 |
| data\\cam\\functions\\magic\\new_enchants\\armor\\tick | 1 | 2 | 0 | 1 | 3 |
| data\\cam\\functions\\magic\\new_enchants\\backbite | 7 | 15 | 1 | 0 | 16 |
| data\\cam\\functions\\magic\\new_enchants\\bleed | 6 | 51 | 10 | 13 | 74 |
| data\\cam\\functions\\magic\\new_enchants\\blinding | 2 | 3 | 1 | 5 | 9 |
| data\\cam\\functions\\magic\\new_enchants\\bloodrage | 6 | 20 | 1 | 0 | 21 |
| data\\cam\\functions\\magic\\new_enchants\\breakable | 4 | 22 | 1 | 2 | 25 |
| data\\cam\\functions\\magic\\new_enchants\\catalyze | 9 | 70 | 2 | 8 | 80 |
| data\\cam\\functions\\magic\\new_enchants\\decay | 3 | 9 | 1 | 5 | 15 |
| data\\cam\\functions\\magic\\new_enchants\\dizziness | 5 | 16 | 1 | 4 | 21 |
| data\\cam\\functions\\magic\\new_enchants\\edification | 6 | 42 | 3 | 8 | 53 |
| data\\cam\\functions\\magic\\new_enchants\\execution | 6 | 25 | 2 | 1 | 28 |
| data\\cam\\functions\\magic\\new_enchants\\freeze | 5 | 21 | 2 | 3 | 26 |
| data\\cam\\functions\\magic\\new_enchants\\looting | 5 | 11 | 1 | 1 | 13 |
| data\\cam\\functions\\magic\\new_enchants\\phylactery | 6 | 59 | 3 | 15 | 77 |
| data\\cam\\functions\\magic\\new_enchants\\poison | 4 | 6 | 2 | 2 | 10 |
| data\\cam\\functions\\magic\\new_enchants\\rampage | 5 | 20 | 4 | 3 | 27 |
| data\\cam\\functions\\magic\\new_enchants\\rattlesnake | 5 | 20 | 1 | 1 | 22 |
| data\\cam\\functions\\magic\\new_enchants\\shield | 12 | 68 | 7 | 17 | 92 |
| data\\cam\\functions\\magic\\new_enchants\\shield (Files) | 5 | 44 | 7 | 12 | 63 |
| data\\cam\\functions\\magic\\new_enchants\\shield\\particle | 7 | 24 | 0 | 5 | 29 |
| data\\cam\\functions\\magic\\new_enchants\\stormchop | 8 | 34 | 3 | 11 | 48 |
| data\\cam\\functions\\magic\\new_enchants\\tyrant | 13 | 96 | 12 | 12 | 120 |
| data\\cam\\functions\\magic\\new_enchants\\vampire | 8 | 28 | 3 | 4 | 35 |
| data\\cam\\functions\\magic\\new_enchants\\wither | 4 | 6 | 5 | 6 | 17 |
| data\\cam\\functions\\magic\\trident | 10 | 65 | 6 | 15 | 86 |
| data\\cam\\functions\\magic\\weapon | 109 | 897 | 43 | 130 | 1,070 |
| data\\cam\\functions\\magic\\weapon\\bow_with_blade | 3 | 5 | 1 | 0 | 6 |
| data\\cam\\functions\\magic\\weapon\\chain_blade | 57 | 422 | 23 | 32 | 477 |
| data\\cam\\functions\\magic\\weapon\\chain_blade (Files) | 19 | 161 | 23 | 29 | 213 |
| data\\cam\\functions\\magic\\weapon\\chain_blade\\forceset | 38 | 261 | 0 | 3 | 264 |
| data\\cam\\functions\\magic\\weapon\\chain_blade\\forceset (Files) | 1 | 39 | 0 | 3 | 42 |
| data\\cam\\functions\\magic\\weapon\\chain_blade\\forceset\\return | 37 | 222 | 0 | 0 | 222 |
| data\\cam\\functions\\magic\\weapon\\customdamage | 5 | 51 | 4 | 6 | 61 |
| data\\cam\\functions\\magic\\weapon\\echo_emitter | 9 | 69 | 1 | 28 | 98 |
| data\\cam\\functions\\magic\\weapon\\erosion_arrow | 6 | 66 | 0 | 3 | 69 |
| data\\cam\\functions\\magic\\weapon\\illager_axe | 8 | 66 | 4 | 13 | 83 |
| data\\cam\\functions\\magic\\weapon\\illager_axe (Files) | 3 | 29 | 3 | 10 | 42 |
| data\\cam\\functions\\magic\\weapon\\illager_axe\\shoot | 5 | 37 | 1 | 3 | 41 |
| data\\cam\\functions\\magic\\weapon\\long_rod | 8 | 68 | 1 | 13 | 82 |
| data\\cam\\functions\\magic\\weapon\\semi_crossbow | 13 | 150 | 9 | 35 | 194 |
| data\\cam\\functions\\modules | 146 | 729 | 59 | 124 | 912 |
| data\\cam\\functions\\modules (Files) | 8 | 156 | 52 | 23 | 231 |
| data\\cam\\functions\\modules\\collabration | 6 | 14 | 0 | 1 | 15 |
| data\\cam\\functions\\modules\\collabration (Files) | 3 | 8 | 0 | 0 | 8 |
| data\\cam\\functions\\modules\\collabration\\load | 3 | 6 | 0 | 1 | 7 |
| data\\cam\\functions\\modules\\dec | 3 | 7 | 0 | 1 | 8 |
| data\\cam\\functions\\modules\\func | 3 | 25 | 0 | 0 | 25 |
| data\\cam\\functions\\modules\\menu | 109 | 408 | 0 | 83 | 491 |
| data\\cam\\functions\\modules\\menu (Files) | 21 | 199 | 0 | 80 | 279 |
| data\\cam\\functions\\modules\\menu\\const | 2 | 12 | 0 | 2 | 14 |
| data\\cam\\functions\\modules\\menu\\print | 80 | 180 | 0 | 1 | 181 |
| data\\cam\\functions\\modules\\menu\\print (Files) | 76 | 172 | 0 | 1 | 173 |
| data\\cam\\functions\\modules\\menu\\print\\co | 2 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\modules\\menu\\print\\const | 2 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\modules\\menu\\shift | 6 | 17 | 0 | 0 | 17 |
| data\\cam\\functions\\modules\\misc | 3 | 30 | 0 | 0 | 30 |
| data\\cam\\functions\\modules\\modules | 8 | 56 | 7 | 11 | 74 |
| data\\cam\\functions\\modules\\village | 3 | 20 | 0 | 2 | 22 |
| data\\cam\\functions\\modules\\weapon | 3 | 13 | 0 | 3 | 16 |
| data\\cam\\functions\\monster | 14 | 51 | 10 | 7 | 68 |
| data\\cam\\functions\\monster (Files) | 1 | 3 | 0 | 0 | 3 |
| data\\cam\\functions\\monster\\drown | 1 | 7 | 0 | 1 | 8 |
| data\\cam\\functions\\monster\\husk | 1 | 6 | 0 | 1 | 7 |
| data\\cam\\functions\\monster\\skeleton | 4 | 11 | 0 | 1 | 12 |
| data\\cam\\functions\\monster\\warden | 7 | 24 | 10 | 4 | 38 |
| data\\cam\\functions\\monster\\warden (Files) | 1 | 1 | 0 | 0 | 1 |
| data\\cam\\functions\\monster\\warden\\allay | 6 | 23 | 10 | 4 | 37 |
| data\\cam\\functions\\random | 9 | 38 | 2 | 4 | 44 |
| data\\cam\\functions\\random (Files) | 4 | 15 | 2 | 2 | 19 |
| data\\cam\\functions\\random\\multi | 5 | 23 | 0 | 2 | 25 |
| data\\cam\\functions\\update | 20 | 57 | 5 | 11 | 73 |
| data\\cam\\functions\\update (Files) | 4 | 18 | 4 | 3 | 25 |
| data\\cam\\functions\\update\\entity | 3 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\update\\entity (Files) | 2 | 2 | 0 | 0 | 2 |
| data\\cam\\functions\\update\\entity\\craftsman | 1 | 2 | 0 | 0 | 2 |
| data\\cam\\functions\\update\\misc | 1 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\update\\versions | 12 | 31 | 1 | 8 | 40 |
| data\\cam\\functions\\village | 41 | 243 | 14 | 42 | 299 |
| data\\cam\\functions\\village\\egg | 5 | 24 | 0 | 2 | 26 |
| data\\cam\\functions\\village\\scarezombie | 9 | 28 | 0 | 4 | 32 |
| data\\cam\\functions\\village\\wine | 27 | 191 | 14 | 36 | 241 |
| data\\cam\\functions\\village\\wine (Files) | 2 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\village\\wine\\old | 6 | 23 | 0 | 9 | 32 |
| data\\cam\\functions\\village\\wine\\winedrink | 19 | 164 | 14 | 27 | 205 |
| data\\cam\\functions\\villager | 140 | 948 | 44 | 122 | 1,114 |
| data\\cam\\functions\\villager (Files) | 4 | 14 | 0 | 1 | 15 |
| data\\cam\\functions\\villager\\armorer | 9 | 89 | 0 | 8 | 97 |
| data\\cam\\functions\\villager\\axe | 1 | 4 | 0 | 0 | 4 |
| data\\cam\\functions\\villager\\butcher | 2 | 7 | 0 | 4 | 11 |
| data\\cam\\functions\\villager\\farmer | 24 | 191 | 19 | 8 | 218 |
| data\\cam\\functions\\villager\\farmer (Files) | 5 | 15 | 0 | 2 | 17 |
| data\\cam\\functions\\villager\\farmer\\farming | 8 | 65 | 0 | 4 | 69 |
| data\\cam\\functions\\villager\\farmer\\woodman | 11 | 111 | 19 | 2 | 132 |
| data\\cam\\functions\\villager\\fisherman | 32 | 199 | 10 | 37 | 246 |
| data\\cam\\functions\\villager\\fisherman\\craftsman | 32 | 199 | 10 | 37 | 246 |
| data\\cam\\functions\\villager\\fisherman\\craftsman (Files) | 22 | 138 | 10 | 26 | 174 |
| data\\cam\\functions\\villager\\fisherman\\craftsman\\itemdeal | 3 | 16 | 0 | 0 | 16 |
| data\\cam\\functions\\villager\\fisherman\\craftsman\\resupply | 7 | 45 | 0 | 11 | 56 |
| data\\cam\\functions\\villager\\fletcher | 31 | 213 | 12 | 38 | 263 |
| data\\cam\\functions\\villager\\fletcher (Files) | 10 | 44 | 0 | 17 | 61 |
| data\\cam\\functions\\villager\\fletcher\\hunter | 21 | 169 | 12 | 21 | 202 |
| data\\cam\\functions\\villager\\librarian | 8 | 40 | 0 | 0 | 40 |
| data\\cam\\functions\\villager\\tick | 3 | 9 | 0 | 0 | 9 |
| data\\cam\\functions\\villager\\toolsmith | 9 | 84 | 0 | 11 | 95 |
| data\\cam\\functions\\villager\\wander | 6 | 44 | 3 | 12 | 59 |
| data\\cam\\functions\\villager\\weaponsmith | 11 | 54 | 0 | 3 | 57 |
| data\\cam\\functions\\villager\\weaponsmith (Files) | 2 | 3 | 0 | 1 | 4 |
| data\\cam\\functions\\villager\\weaponsmith\\weaponsmith | 9 | 51 | 0 | 2 | 53 |
| data\\cam\\item_modifiers | 4 | 17 | 0 | 0 | 17 |
| data\\cam\\item_modifiers (Files) | 1 | 5 | 0 | 0 | 5 |
| data\\cam\\item_modifiers\\illager_axe | 3 | 12 | 0 | 0 | 12 |
| data\\cam\\loot_tables | 268 | 13,341 | 0 | 264 | 13,605 |
| data\\cam\\loot_tables\\3_year | 1 | 19 | 0 | 1 | 20 |
| data\\cam\\loot_tables\\cam | 127 | 2,479 | 0 | 127 | 2,606 |
| data\\cam\\loot_tables\\cam (Files) | 97 | 1,881 | 0 | 97 | 1,978 |
| data\\cam\\loot_tables\\cam\\copper_pickaxe | 3 | 57 | 0 | 3 | 60 |
| data\\cam\\loot_tables\\cam\\copper_sword | 7 | 161 | 0 | 7 | 168 |
| data\\cam\\loot_tables\\cam\\dream_catcher | 16 | 304 | 0 | 16 | 320 |
| data\\cam\\loot_tables\\cam\\weapon_debris | 4 | 76 | 0 | 4 | 80 |
| data\\cam\\loot_tables\\carapax | 34 | 2,604 | 0 | 32 | 2,636 |
| data\\cam\\loot_tables\\carapax (Files) | 2 | 316 | 0 | 1 | 317 |
| data\\cam\\loot_tables\\carapax\\curse | 3 | 157 | 0 | 3 | 160 |
| data\\cam\\loot_tables\\carapax\\magic | 10 | 801 | 0 | 10 | 811 |
| data\\cam\\loot_tables\\carapax\\mysterious | 4 | 132 | 0 | 4 | 136 |
| data\\cam\\loot_tables\\carapax\\physics | 9 | 789 | 0 | 9 | 798 |
| data\\cam\\loot_tables\\carapax\\shield | 6 | 409 | 0 | 5 | 414 |
| data\\cam\\loot_tables\\co_fisma | 3 | 280 | 0 | 3 | 283 |
| data\\cam\\loot_tables\\fishing | 8 | 639 | 0 | 8 | 647 |
| data\\cam\\loot_tables\\fishing (Files) | 4 | 523 | 0 | 4 | 527 |
| data\\cam\\loot_tables\\fishing\\fish | 4 | 116 | 0 | 4 | 120 |
| data\\cam\\loot_tables\\misc | 12 | 526 | 0 | 12 | 538 |
| data\\cam\\loot_tables\\sacrificing_table | 37 | 2,309 | 0 | 35 | 2,344 |
| data\\cam\\loot_tables\\sacrificing_table (Files) | 4 | 241 | 0 | 3 | 244 |
| data\\cam\\loot_tables\\sacrificing_table\\curse | 3 | 90 | 0 | 3 | 93 |
| data\\cam\\loot_tables\\sacrificing_table\\magic | 10 | 690 | 0 | 10 | 700 |
| data\\cam\\loot_tables\\sacrificing_table\\mysterious | 4 | 150 | 0 | 4 | 154 |
| data\\cam\\loot_tables\\sacrificing_table\\physics | 9 | 708 | 0 | 9 | 717 |
| data\\cam\\loot_tables\\sacrificing_table\\shield | 7 | 430 | 0 | 6 | 436 |
| data\\cam\\loot_tables\\vanilla | 1 | 75 | 0 | 1 | 76 |
| data\\cam\\loot_tables\\villager | 45 | 4,410 | 0 | 45 | 4,455 |
| data\\cam\\loot_tables\\villager (Files) | 11 | 1,908 | 0 | 11 | 1,919 |
| data\\cam\\loot_tables\\villager\\craftsman | 13 | 1,280 | 0 | 13 | 1,293 |
| data\\cam\\loot_tables\\villager\\hunter | 4 | 552 | 0 | 4 | 556 |
| data\\cam\\loot_tables\\villager\\wander | 17 | 670 | 0 | 17 | 687 |
| data\\cam\\loot_tables\\villager\\wander (Files) | 2 | 229 | 0 | 2 | 231 |
| data\\cam\\loot_tables\\villager\\wander\\normal | 15 | 441 | 0 | 15 | 456 |
| data\\cam\\predicates | 313 | 6,366 | 0 | 281 | 6,647 |
| data\\cam\\predicates\\crafting_table | 3 | 96 | 0 | 3 | 99 |
| data\\cam\\predicates\\enchant | 55 | 667 | 0 | 50 | 717 |
| data\\cam\\predicates\\enchant (Files) | 20 | 168 | 0 | 21 | 189 |
| data\\cam\\predicates\\enchant\\_master | 3 | 35 | 0 | 1 | 36 |
| data\\cam\\predicates\\enchant\\blindness | 1 | 7 | 0 | 1 | 8 |
| data\\cam\\predicates\\enchant\\catalyze | 5 | 129 | 0 | 5 | 134 |
| data\\cam\\predicates\\enchant\\decay | 4 | 28 | 0 | 4 | 32 |
| data\\cam\\predicates\\enchant\\execution | 1 | 7 | 0 | 1 | 8 |
| data\\cam\\predicates\\enchant\\freeze | 7 | 51 | 0 | 7 | 58 |
| data\\cam\\predicates\\enchant\\poison | 4 | 28 | 0 | 4 | 32 |
| data\\cam\\predicates\\enchant\\rainbow | 3 | 122 | 0 | 1 | 123 |
| data\\cam\\predicates\\enchant\\sculk | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\enchant\\wither | 4 | 28 | 0 | 4 | 32 |
| data\\cam\\predicates\\furance | 23 | 760 | 0 | 23 | 783 |
| data\\cam\\predicates\\furance (Files) | 3 | 81 | 0 | 3 | 84 |
| data\\cam\\predicates\\furance\\bamboo | 6 | 208 | 0 | 6 | 214 |
| data\\cam\\predicates\\furance\\copper | 8 | 263 | 0 | 8 | 271 |
| data\\cam\\predicates\\furance\\leather | 6 | 208 | 0 | 6 | 214 |
| data\\cam\\predicates\\item_displayer | 3 | 51 | 0 | 3 | 54 |
| data\\cam\\predicates\\misc | 104 | 2,207 | 0 | 102 | 2,309 |
| data\\cam\\predicates\\misc (Files) | 14 | 322 | 0 | 14 | 336 |
| data\\cam\\predicates\\misc\\antigrind | 36 | 684 | 0 | 36 | 720 |
| data\\cam\\predicates\\misc\\bowenchant | 10 | 431 | 0 | 10 | 441 |
| data\\cam\\predicates\\misc\\celebration_harpoon | 3 | 65 | 0 | 3 | 68 |
| data\\cam\\predicates\\misc\\chinese_knot | 4 | 77 | 0 | 4 | 81 |
| data\\cam\\predicates\\misc\\dream_catcher | 6 | 82 | 0 | 4 | 86 |
| data\\cam\\predicates\\misc\\echo_emitter | 9 | 195 | 0 | 9 | 204 |
| data\\cam\\predicates\\misc\\echo_prism | 4 | 81 | 0 | 4 | 85 |
| data\\cam\\predicates\\misc\\harpoon | 3 | 21 | 0 | 3 | 24 |
| data\\cam\\predicates\\misc\\semibow | 12 | 228 | 0 | 12 | 240 |
| data\\cam\\predicates\\misc\\trident | 3 | 21 | 0 | 3 | 24 |
| data\\cam\\predicates\\sacrifice | 36 | 1,150 | 0 | 31 | 1,181 |
| data\\cam\\predicates\\sacrifice (Files) | 19 | 837 | 0 | 18 | 855 |
| data\\cam\\predicates\\sacrifice\\carapax | 3 | 42 | 0 | 3 | 45 |
| data\\cam\\predicates\\sacrifice\\recasting | 10 | 126 | 0 | 10 | 136 |
| data\\cam\\predicates\\sacrifice\\weapon_type | 4 | 145 | 0 | 0 | 145 |
| data\\cam\\predicates\\shield | 33 | 703 | 0 | 13 | 716 |
| data\\cam\\predicates\\shield (Files) | 3 | 63 | 0 | 3 | 66 |
| data\\cam\\predicates\\shield\\blinding | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\decay | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\dizziness | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\freeze | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\poison | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\rampage | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\resilience | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\revenge | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\shield | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\shield\\wither | 3 | 64 | 0 | 1 | 65 |
| data\\cam\\predicates\\villager | 31 | 469 | 0 | 31 | 500 |
| data\\cam\\predicates\\villager (Files) | 7 | 277 | 0 | 7 | 284 |
| data\\cam\\predicates\\villager\\trigger | 24 | 192 | 0 | 24 | 216 |
| data\\cam\\predicates\\weapon | 25 | 263 | 0 | 25 | 288 |
| data\\cam\\predicates\\weapon (Files) | 12 | 132 | 0 | 12 | 144 |
| data\\cam\\predicates\\weapon\\chain_blade | 6 | 54 | 0 | 6 | 60 |
| data\\cam\\predicates\\weapon\\illager_axe | 7 | 77 | 0 | 7 | 84 |
| data\\cam\\recipes | 14 | 179 | 0 | 1 | 180 |
| data\\cam\\tags | 48 | 493 | 0 | 43 | 536 |
| data\\cam\\tags\\blocks | 7 | 76 | 0 | 7 | 83 |
| data\\cam\\tags\\damage_type | 1 | 5 | 0 | 0 | 5 |
| data\\cam\\tags\\entity_types | 7 | 63 | 0 | 7 | 70 |
| data\\cam\\tags\\functions | 7 | 112 | 0 | 3 | 115 |
| data\\cam\\tags\\items | 22 | 217 | 0 | 22 | 239 |
| data\\cam\\tags\\worldgen | 4 | 20 | 0 | 4 | 24 |
| data\\cam\\tags\\worldgen\\structure | 4 | 20 | 0 | 4 | 24 |
| data\\cam_music | 8 | 21 | 2 | 3 | 26 |
| data\\cam_music\\functions | 8 | 21 | 2 | 3 | 26 |
| data\\cam_music\\functions (Files) | 7 | 18 | 2 | 3 | 23 |
| data\\cam_music\\functions\\music | 1 | 3 | 0 | 0 | 3 |
| data\\cnc | 114 | 1,016 | 37 | 68 | 1,121 |
| data\\cnc\\advancements | 2 | 32 | 0 | 2 | 34 |
| data\\cnc\\advancements\\cnc | 2 | 32 | 0 | 2 | 34 |
| data\\cnc\\functions | 95 | 736 | 37 | 50 | 823 |
| data\\cnc\\functions\\machine | 95 | 736 | 37 | 50 | 823 |
| data\\cnc\\functions\\machine\\crafting_table | 95 | 736 | 37 | 50 | 823 |
| data\\cnc\\functions\\machine\\crafting_table (Files) | 27 | 322 | 36 | 39 | 397 |
| data\\cnc\\functions\\machine\\crafting_table\\inventory | 36 | 252 | 0 | 0 | 252 |
| data\\cnc\\functions\\machine\\crafting_table\\recipes | 11 | 45 | 0 | 10 | 55 |
| data\\cnc\\functions\\machine\\crafting_table\\recipes (Files) | 2 | 18 | 0 | 1 | 19 |
| data\\cnc\\functions\\machine\\crafting_table\\recipes\\clear | 9 | 27 | 0 | 9 | 36 |
| data\\cnc\\functions\\machine\\crafting_table\\replace | 19 | 112 | 0 | 0 | 112 |
| data\\cnc\\functions\\machine\\crafting_table\\update | 2 | 5 | 1 | 1 | 7 |
| data\\cnc\\loot_tables | 1 | 20 | 0 | 1 | 21 |
| data\\cnc\\loot_tables\\cnc | 1 | 20 | 0 | 1 | 21 |
| data\\cnc\\predicates | 3 | 43 | 0 | 3 | 46 |
| data\\cnc\\predicates\\crafting_table | 3 | 43 | 0 | 3 | 46 |
| data\\cnc\\tags | 13 | 185 | 0 | 12 | 197 |
| data\\cnc\\tags\\functions | 1 | 5 | 0 | 0 | 5 |
| data\\cnc\\tags\\items | 12 | 180 | 0 | 12 | 192 |
| data\\lay | 26 | 84 | 1 | 9 | 94 |
| data\\lay\\functions | 26 | 84 | 1 | 9 | 94 |
| data\\lay\\functions (Files) | 3 | 3 | 0 | 1 | 4 |
| data\\lay\\functions\\macro | 23 | 81 | 1 | 8 | 90 |
| data\\lay\\functions\\macro (Files) | 1 | 3 | 0 | 1 | 4 |
| data\\lay\\functions\\macro\\give | 8 | 21 | 0 | 1 | 22 |
| data\\lay\\functions\\macro\\inventory | 7 | 31 | 0 | 1 | 32 |
| data\\lay\\functions\\macro\\list | 2 | 6 | 0 | 0 | 6 |
| data\\lay\\functions\\macro\\range | 5 | 20 | 1 | 5 | 26 |
| data\\loymine | 3 | 3,709 | 2 | 9 | 3,720 |
| data\\loymine\\functions | 3 | 3,709 | 2 | 9 | 3,720 |
| data\\minecraft | 86 | 9,407 | 0 | 61 | 9,468 |
| data\\minecraft\\dimension_type | 2 | 46 | 0 | 2 | 48 |
| data\\minecraft\\loot_tables | 70 | 9,226 | 0 | 54 | 9,280 |
| data\\minecraft\\loot_tables\\archaeology | 6 | 536 | 0 | 0 | 536 |
| data\\minecraft\\loot_tables\\blocks | 26 | 2,760 | 0 | 21 | 2,781 |
| data\\minecraft\\loot_tables\\chests | 16 | 3,805 | 0 | 13 | 3,818 |
| data\\minecraft\\loot_tables\\entities | 18 | 1,583 | 0 | 16 | 1,599 |
| data\\minecraft\\loot_tables\\gameplay | 3 | 508 | 0 | 3 | 511 |
| data\\minecraft\\loot_tables\\random | 1 | 34 | 0 | 1 | 35 |
| data\\minecraft\\recipes | 1 | 23 | 0 | 0 | 23 |
| data\\minecraft\\tags | 13 | 112 | 0 | 5 | 117 |
| data\\minecraft\\tags (Files) | 1 | 10 | 0 | 0 | 10 |
| data\\minecraft\\tags\\damage_type | 4 | 25 | 0 | 0 | 25 |
| data\\minecraft\\tags\\entity_types | 5 | 58 | 0 | 5 | 63 |
| data\\minecraft\\tags\\functions | 2 | 12 | 0 | 0 | 12 |
| data\\minecraft\\tags\\items | 1 | 7 | 0 | 0 | 7 |
| data\\uin | 258 | 7,988 | 0 | 301 | 8,289 |
| data\\uin\\tags | 258 | 7,988 | 0 | 301 | 8,289 |
| data\\uin\\tags (Files) | 1 | 253 | 0 | 44 | 297 |
| data\\uin\\tags\\blocks | 182 | 5,400 | 0 | 182 | 5,582 |
| data\\uin\\tags\\blocks (Files) | 1 | 8 | 0 | 1 | 9 |
| data\\uin\\tags\\blocks\\general | 56 | 1,100 | 0 | 56 | 1,156 |
| data\\uin\\tags\\blocks\\tech | 125 | 4,292 | 0 | 125 | 4,417 |
| data\\uin\\tags\\blocks\\tech (Files) | 15 | 2,084 | 0 | 15 | 2,099 |
| data\\uin\\tags\\blocks\\tech\\blockstates | 28 | 532 | 0 | 28 | 560 |
| data\\uin\\tags\\blocks\\tech\\map | 82 | 1,676 | 0 | 82 | 1,758 |
| data\\uin\\tags\\blocks\\tech\\map (Files) | 62 | 1,518 | 0 | 62 | 1,580 |
| data\\uin\\tags\\blocks\\tech\\map\\group | 16 | 126 | 0 | 16 | 142 |
| data\\uin\\tags\\blocks\\tech\\map\\group2 | 4 | 32 | 0 | 4 | 36 |
| data\\uin\\tags\\entity_types | 23 | 479 | 0 | 23 | 502 |
| data\\uin\\tags\\entity_types (Files) | 1 | 8 | 0 | 1 | 9 |
| data\\uin\\tags\\entity_types\\custom | 1 | 8 | 0 | 1 | 9 |
| data\\uin\\tags\\entity_types\\general | 4 | 39 | 0 | 4 | 43 |
| data\\uin\\tags\\entity_types\\tech | 17 | 424 | 0 | 17 | 441 |
| data\\uin\\tags\\items | 52 | 1,856 | 0 | 52 | 1,908 |
| data\\uin\\tags\\items (Files) | 1 | 420 | 0 | 1 | 421 |
| data\\uin\\tags\\items\\general | 44 | 586 | 0 | 44 | 630 |
| data\\uin\\tags\\items\\tech | 7 | 850 | 0 | 7 | 857 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)