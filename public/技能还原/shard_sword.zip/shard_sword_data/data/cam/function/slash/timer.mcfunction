execute if score @s slash_timer matches ..40 run scoreboard players add @s slash_timer 1

execute if score @s slash_timer matches 40.. run function animated_java:slash/remove/this