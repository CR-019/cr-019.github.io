tag @s add slash_mark
scoreboard players set @s slash_timer 0
execute on passengers run data modify entity @s brightness set value {block:15,sky:15}

function animated_java:slash/animations/1/play