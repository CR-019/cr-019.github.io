execute rotated ~ 0 run function animated_java:slash/summon {args:{}}


execute as @e[distance=..2,limit=1,tag=!slash_mark,tag=aj.slash.root,type=item_display] run function cam:slash/play_