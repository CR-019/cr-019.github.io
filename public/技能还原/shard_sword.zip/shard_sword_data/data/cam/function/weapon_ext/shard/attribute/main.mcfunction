#生命倍率
execute if predicate cam:shard/buff run function cam:weapon_ext/shard/attribute/buff
execute unless predicate cam:shard/buff run attribute @s attack_damage modifier remove shard

#最大生命值时间补偿
execute if predicate cam:shard/both run scoreboard players set @s CAM_shard_timer3 200
execute if score @s CAM_shard_timer3 matches 1.. run attribute @s max_health modifier add shard 20 add_value
execute unless score @s CAM_shard_timer3 matches 1.. run attribute @s max_health modifier remove shard