summon item_display ~ ~0.5 ~ {Tags:["shard_effect_gsweep","shard_effect","shard_effect_temp"],item:{id:"firework_star",components:{item_model:"shard:gsweep",custom_model_data:{floats:[0f]}}},item_display:"fixed",brightness:{block:15,sky:15}}

execute as @e[tag=shard_effect_temp,limit=1,sort=nearest] run function cam:weapon_ext/shard/effect/gsweep/summon_