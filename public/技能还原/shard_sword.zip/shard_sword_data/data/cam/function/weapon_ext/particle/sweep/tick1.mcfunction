scoreboard players set #sweep CAM_particle_life 9200011
scoreboard players operation #sweep CAM_particle_life -= @s CAM_particle_life
execute store result entity @s item.tag.CustomModelData int 1 run scoreboard players get #sweep CAM_particle_life