summon item_display ~ ~1 ~ {Tags:["shard_effect_sweep","shard_effect","shard_effect_temp"],item:{id:"firework_star",components:{item_model:"shard:sweep",custom_model_data:{floats:[0f]}}},item_display:"fixed",billboard:"center"}

execute as @e[tag=shard_effect_temp,limit=1,sort=nearest] run function cam:weapon_ext/shard/effect/sweep/summon_

