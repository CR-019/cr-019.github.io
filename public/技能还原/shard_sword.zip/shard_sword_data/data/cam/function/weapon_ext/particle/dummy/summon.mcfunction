#玩家假人：用于固定玩家位置（tp），继承玩家朝向等数据
#预先设定假人持续时间:#dummy CAM_particle_life
summon marker ~ ~ ~ {Tags:["CAM_particle","CAM_particle_dummy","CAM_particle_temp"]}
scoreboard players operation @e[distance=..0.1,tag=CAM_particle_temp] CAM_particle_life = #dummy CAM_particle_life
data modify entity @e[distance=..0.1,tag=CAM_particle_temp,limit=1] Rotation set from entity @a[tag=CAM_dummy_owner,limit=1,sort=nearest] Rotation
tag @e[distance=..0.1,tag=CAM_particle_temp] remove CAM_particle_temp