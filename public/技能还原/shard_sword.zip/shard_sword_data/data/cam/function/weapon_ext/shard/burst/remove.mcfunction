execute as @a[tag=shard_half] run attribute @s max_health modifier remove shard_temp
execute as @a[tag=shard_half] run tag @s remove shard_half