#knockback
attribute @s knockback_resistance modifier add shard_temp -1 add_value

#damage
$damage @s $(damage) cam:bloodslash by @a[limit=1,tag=CAM_shard_dealer]

attribute @s knockback_resistance modifier remove shard_temp