tag @s remove shard_effect_temp

data modify entity @s transformation.scale set value [3f,3f,3f]