execute as @e[tag=CAM_particle] at @s run function cam:weapon_ext/particle/tick_
kill @e[tag=CAM_particle_kill]