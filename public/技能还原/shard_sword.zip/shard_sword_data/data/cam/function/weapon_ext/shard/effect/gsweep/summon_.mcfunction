tag @s remove shard_effect_temp
execute facing entity @a[limit=1,tag=CAM_shard_dealer] eyes run rotate @s ~ ~

data modify entity @s transformation.scale set value [20f,20f,1f]