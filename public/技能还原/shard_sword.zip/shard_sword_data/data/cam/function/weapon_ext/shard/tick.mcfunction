execute as @a at @s run function cam:weapon_ext/shard/tick_
execute as @e[type=item_display,tag=shard_effect] run function cam:weapon_ext/shard/effect/tick
execute as @e[tag=slash_mark,type=item_display] at @s run function cam:slash/timer