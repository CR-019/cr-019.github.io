data modify storage shard attribute.buff set value 0f
execute store result storage shard attribute.buff float 0.1 run attribute @s max_health get

function cam:weapon_ext/shard/attribute/buff_ with storage shard attribute