tag @s add fixation_temp
schedule function cam:weapon_ext/shard/consume/replace_1gt 1t
function cam:weapon_ext/shard/trigger