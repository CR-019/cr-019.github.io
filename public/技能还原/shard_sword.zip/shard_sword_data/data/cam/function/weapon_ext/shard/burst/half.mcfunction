execute store result score @s shard_health run attribute @s max_health get 0.5

data modify storage shard attribute.half set value 0f
execute store result storage shard attribute.half float 0.5 run attribute @s max_health get

function cam:weapon_ext/shard/burst/half_ with storage shard attribute

execute if score @s CAM_htracer < @s shard_health run effect give @s instant_health 1 20 true
execute if score @s CAM_htracer > @s shard_health run scoreboard players add @s CAM_shard_hurt 1

tag @s add shard_half
schedule function cam:weapon_ext/shard/burst/remove 2t