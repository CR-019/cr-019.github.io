tag @s remove shard_burst

tag @s add CAM_shard_dealer

data modify storage shard damages.damage set value 0f
execute store result score @s shard_smash run attribute @s attack_damage get 10
scoreboard players operation @s shard_smash += @s shard_bloodpool

execute store result storage shard damages.damage float 0.2 run scoreboard players get @s shard_smash

scoreboard players set @s shard_bloodpool 0

execute positioned ~ ~ ~ run function cam:slash/play
execute as @e[type=#uin:tech/mobs,distance=..15,tag=!CAM_shard_dealer] run function cam:weapon_ext/shard/burst/smash_ with storage shard damages
tag @s remove CAM_shard_dealer

#音效
playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1 2
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 1
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 0.5
playsound minecraft:entity.iron_golem.hurt player @a ~ ~ ~ 0.5 1.3
playsound minecraft:entity.iron_golem.hurt player @a ~ ~ ~ 0.5 0.5
playsound minecraft:entity.wither.shoot player @a ~ ~ ~ 0.5 0.8


scoreboard players set @s CAM_shard_timer4 30