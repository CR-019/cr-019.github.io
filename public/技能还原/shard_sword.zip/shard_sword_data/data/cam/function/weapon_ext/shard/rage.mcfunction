tag @s add CAM_shard_dealer
execute anchored eyes rotated ~ 0 positioned ^ ^ ^3 run function cam:weapon_ext/shard/rage_
effect give @s instant_health 1 1
effect give @s speed 1 30 true
effect give @s resistance 1 10 true

scoreboard players set @s CAM_shard_timer2 25

tag @s add CAM_dummy_owner
scoreboard players set #dummy CAM_particle_life 20
function cam:weapon_ext/particle/dummy/summon
tag @s remove CAM_dummy_owner

scoreboard players add @s CAM_shard_energy 5
scoreboard players set @s CAM_shard_hurt 0
tag @s remove CAM_shard_dealer
playsound minecraft:entity.ender_dragon.growl player @a ~ ~ ~ 0.3
playsound minecraft:item.trident.thunder player @a ~ ~ ~ 0.4 2
playsound minecraft:entity.breeze.hurt player @a ~ ~ ~