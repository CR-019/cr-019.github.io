summon item_display ~ ~ ~ {billboard:"center",item:{id:"minecraft:firework_star",Count:1b,tag:{CustomModelData:9200003}},Tags:["CAM_particle","CAM_particle_sweep2","CAM_particle_temp"],brightness:{block:15,sky:15}}
scoreboard players set @e[distance=..0.1,tag=CAM_particle_temp] CAM_particle_life 4
data modify entity @e[distance=..0.1,limit=1,tag=CAM_particle_temp] transformation.scale set value [3.0f,3.0f,3.0f]
tag @e[distance=..0.1,tag=CAM_particle_temp] remove CAM_particle_temp