execute unless predicate cam:shard/both run clear @s *[custom_data~"{shard_offhand:1b}"]
execute unless predicate cam:shard/offhand run clear @s *[custom_data~"{shard_offhand:1b}"]