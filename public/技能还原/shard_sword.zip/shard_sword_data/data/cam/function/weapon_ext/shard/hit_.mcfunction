tag @s add CAM_shard_dealer

data modify storage shard damages.damage set value 0f
execute store result storage shard damages.damage float 0.4 run attribute @s attack_damage get

execute positioned ~ ~-1 ~ run function cam:weapon_ext/shard/effect/sweep/summon
execute as @e[type=#uin:tech/mobs,distance=..2,tag=!CAM_shard_dealer] run function cam:weapon_ext/shard/hit__ with storage shard damages
tag @s remove CAM_shard_dealer
playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1 0