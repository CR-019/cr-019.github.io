loot replace entity @s weapon.mainhand loot cam:shard
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~