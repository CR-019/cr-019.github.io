execute positioned ~ ~-1 ~ run function cam:weapon_ext/shard/effect/gsweep/summon

#damage
data modify storage shard damages.damage set value 0f
execute store result storage shard damages.damage float 2 run attribute @s attack_damage get

execute as @e[type=#uin:tech/mobs,distance=..8,tag=!CAM_shard_dealer] run function cam:weapon_ext/shard/rage__ with storage shard damages