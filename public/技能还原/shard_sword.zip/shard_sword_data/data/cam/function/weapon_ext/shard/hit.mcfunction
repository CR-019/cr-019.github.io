execute if predicate cam:shard/buff if score @s CAM_htracer matches 3.. run damage @s 1 cam:bloodslash by @s
execute if predicate cam:shard/buff at @s anchored eyes positioned ^ ^ ^2.5 run function cam:weapon_ext/shard/hit_

execute if predicate cam:shard/both run scoreboard players add @s CAM_shard_energy 10
execute if predicate cam:shard/buff run scoreboard players add @s CAM_shard_energy 5

scoreboard players set @s CAM_shard_damage 0

