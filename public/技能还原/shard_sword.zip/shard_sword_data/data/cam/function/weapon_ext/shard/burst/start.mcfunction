scoreboard players set @s CAM_shard_energy 0

effect give @s resistance 5 5 true
effect give @a[distance=..15] darkness 5 0 true
execute rotated ~ 0 run function cam:misc/motion_macro {pos:"^ ^-1 ^-0.2",times:3}

#强制半血
function cam:weapon_ext/shard/burst/half
playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 0.5

tag @s add shard_burst