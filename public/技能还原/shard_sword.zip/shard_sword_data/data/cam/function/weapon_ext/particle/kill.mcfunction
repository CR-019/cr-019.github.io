scoreboard players reset @s CAM_particle_life
tag @s add CAM_particle_kill