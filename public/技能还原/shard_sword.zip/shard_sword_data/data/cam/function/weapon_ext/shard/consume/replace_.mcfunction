advancement revoke @s only cam:cam/consume
function lay:macro/inventory/init
data modify storage lay Inventory.target set value "{components:{\"minecraft:custom_data\":{shard_remainder:1b}}}"
data modify storage lay Inventory.func set value "cam:weapon_ext/shard/consume/replace__"
function lay:macro/inventory/start
