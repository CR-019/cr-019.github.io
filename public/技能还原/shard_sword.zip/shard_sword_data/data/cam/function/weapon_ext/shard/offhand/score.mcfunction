$item modify entity @s weapon.offhand {function:"set_lore",mode:"replace_all",entity:"this",lore:[\
                                    {"text":"[","italic": false,"color":"aqua","extra":[{"text":"能量","color":"aqua"},{"text":"]","color":"aqua"},{"text":": ","color":"white"},{"text":"$(energy)/160","color":"white"}]},\
                                    {"text":"能量满后，可释放终结技。","color":"gray","italic": false},\
                                    {"text":"[","italic": false,"color":"aqua","extra":[{"text":"充能","color":"aqua"},{"text":"]","color":"aqua"},{"text":": ","color":"white"},{"text":"$(hurt)/5","color":"white"}]},\
                                    {"text":"损失生命值时，获得一层[充能]。","color":"gray","italic": false},\
                                    {"text":"[充能]满5层时，触发反击[倏忽恩赐]。","color":"gray","italic": false},\
                                    {"text":"[","italic": false,"color":"aqua","extra":[{"text":"累计已损失生命值","color":"aqua"},{"text":"]","color":"aqua"},{"text":": $(blood)","color":"white"}]},\
                                    {"text":"最高值不超过40；释放终结技会清空并重新累计。","color":"gray","italic": false}\
                                ]\
}
