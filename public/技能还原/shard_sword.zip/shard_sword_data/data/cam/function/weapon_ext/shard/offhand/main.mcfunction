execute if data entity @s Inventory[{Slot:-106b}] unless predicate cam:shard/offhand run function cam:weapon_ext/shard/offhand/drop
loot replace entity @s weapon.offhand loot cam:energy

data modify storage shard score set value {energy:0,hurt:0,blood:0}
execute store result storage shard score.energy int 1 run scoreboard players get @s CAM_shard_energy
execute store result storage shard score.hurt int 1 run scoreboard players get @s CAM_shard_hurt
execute store result storage shard score.blood int 1 run scoreboard players get @s shard_bloodpool

function cam:weapon_ext/shard/offhand/score with storage shard score