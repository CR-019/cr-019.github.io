scoreboard objectives add CAM_shard_damage custom:damage_dealt

scoreboard objectives add CAM_shard_hurt dummy
scoreboard objectives add CAM_shard_energy dummy
scoreboard objectives add CAM_shard_timer dummy "强化计时器"
scoreboard objectives add CAM_shard_timer2 dummy "追击计时器"
scoreboard objectives add CAM_shard_timer3 dummy "生命补偿计时器"
scoreboard objectives add CAM_shard_timer4 dummy "延时计时器"

scoreboard objectives add shard_effect_timer dummy

scoreboard objectives add CAM_htracer health
scoreboard objectives add CAM_htracer_lt dummy
scoreboard objectives add CAM_htracer_delta dummy
scoreboard objectives add CAM_death deathCount

scoreboard objectives add gamemode dummy

scoreboard objectives add shard_health dummy
scoreboard objectives add shard_bloodpool dummy
scoreboard objectives add shard_smash dummy

scoreboard objectives add slash_timer dummy