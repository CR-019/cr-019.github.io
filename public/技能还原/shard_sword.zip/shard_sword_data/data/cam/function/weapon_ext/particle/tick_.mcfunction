execute if score @s CAM_particle_life matches 0 run function cam:weapon_ext/particle/kill
execute if entity @s[tag=CAM_particle_sweep] run function cam:weapon_ext/particle/sweep/tick1
execute if entity @s[tag=CAM_particle_sweep2] run function cam:weapon_ext/particle/sweep/tick2
execute if entity @s[tag=CAM_particle_sweep3] run function cam:weapon_ext/particle/sweep/tick3
execute if score @s CAM_particle_life matches 1.. run scoreboard players remove @s CAM_particle_life 1