#识别类型
execute as @s[tag=shard_effect_gsweep] run function cam:weapon_ext/shard/effect/gsweep/tick
execute as @s[tag=shard_effect_sweep] run function cam:weapon_ext/shard/effect/sweep/tick