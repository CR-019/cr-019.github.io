loot replace entity @s weapon.mainhand loot cam:shard_s
execute if score @s CAM_htracer matches 7.. run damage @s 6 generic by @s
scoreboard players set @s CAM_shard_timer 600
playsound minecraft:item.axe.wax_off player @a ~ ~ ~ 1 0
playsound minecraft:block.grindstone.use player @a ~ ~ ~ 1 1