#timer
execute if score @s CAM_shard_timer matches 1.. run scoreboard players remove @s CAM_shard_timer 1
execute if score @s CAM_shard_timer2 matches 5.. run tp @s @e[sort=nearest,tag=CAM_particle_dummy,limit=1]
execute if score @s CAM_shard_timer2 matches 1.. run scoreboard players remove @s CAM_shard_timer2 1
execute if score @s CAM_shard_timer3 matches 1.. run scoreboard players remove @s CAM_shard_timer3 1
execute if score @s CAM_shard_timer4 matches 1.. run scoreboard players remove @s CAM_shard_timer4 1


#damage
execute if score @s CAM_shard_damage matches 1.. run function cam:weapon_ext/shard/hit

#burst
execute if score @s CAM_death matches 1.. run scoreboard players set @s shard_bloodpool 0

scoreboard players operation @s CAM_htracer_delta = @s CAM_htracer
scoreboard players operation @s CAM_htracer_delta -= @s CAM_htracer_lt
execute if score @s CAM_htracer_delta matches ..-1 run scoreboard players operation @s shard_bloodpool -= @s CAM_htracer_delta
execute if score @s shard_bloodpool matches 40.. run scoreboard players set @s shard_bloodpool 40

scoreboard players operation @s CAM_htracer_lt = @s CAM_htracer
scoreboard players set @s CAM_death 0

execute as @s[tag=shard_burst] at @s run function cam:weapon_ext/shard/burst/tick

#offhand
execute as @a if predicate cam:shard/off at @s run function cam:weapon_ext/shard/offhand/burst_trigger

function cam:weapon_ext/shard/offhand/clear
execute if predicate cam:shard/main at @s run function cam:weapon_ext/shard/offhand/main

#energy
execute if score @s CAM_shard_energy matches 160.. run scoreboard players set @s CAM_shard_energy 160

#hurt
execute if predicate cam:shard/both if score @s CAM_shard_hurt matches 5.. unless score @s CAM_shard_timer4 matches 1.. unless entity @s[tag=shard_burst] at @s run function cam:weapon_ext/shard/rage

#attributes
function cam:weapon_ext/shard/attribute/main

#replace
execute if predicate cam:shard/buff if score @s CAM_shard_timer matches ..0 run function cam:weapon_ext/shard/deactivate
