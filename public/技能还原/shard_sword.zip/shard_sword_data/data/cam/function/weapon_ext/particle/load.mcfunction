scoreboard objectives add CAM_particle_life dummy

scoreboard players set #constant_2 CAM_particle_life 2