execute if predicate cam:shard/ground run function cam:weapon_ext/shard/burst/smash
execute if predicate cam:shard/smash rotated 0 0 run function cam:misc/motion_macro {pos:"^ ^1 ^",times:5}
