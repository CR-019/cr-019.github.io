advancement revoke @s only cam:cam/shard

scoreboard players add @s CAM_shard_hurt 1
scoreboard players add @s CAM_shard_energy 5

particle minecraft:dust{color:[0.447,0d,0d],scale:1} ~ ~1 ~ .3 .3 .3 3 15 normal
particle minecraft:dust{color:[0.706,0d,0d],scale:0.6} ~ ~1 ~ .3 .3 .3 1 10 normal
particle minecraft:dust{color:[1d,0d,0d],scale:0.2} ~ ~1 ~ .3 .3 .3 1 5 normal