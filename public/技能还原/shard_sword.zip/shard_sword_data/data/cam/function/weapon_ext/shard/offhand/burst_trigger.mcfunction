#交换
item replace entity @s weapon.mainhand from entity @s weapon.offhand
item replace entity @s weapon.offhand with air

#技能
execute if score @s CAM_shard_energy matches 160.. unless score @s CAM_shard_timer2 matches 1.. run function cam:weapon_ext/shard/burst/start
