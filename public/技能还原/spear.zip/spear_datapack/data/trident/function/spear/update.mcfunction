data modify storage minecraft:spear cmd set value {energy:0.0f,charge:0.0f,buff:"false"}

execute as @s[tag=spear_buff] run data modify storage minecraft:spear cmd.buff set value "true"
execute as @s[tag=spear_buff] store result storage minecraft:spear cmd.energy float 0.05 run scoreboard players get @s spear_buff_timer
execute as @s[tag=!spear_buff] store result storage minecraft:spear cmd.energy float 0.1 run scoreboard players get @s spear_energy

execute store result storage minecraft:spear cmd.charge float 1 run scoreboard players get @s spear_charge_count

execute if predicate trident:spear/main run function trident:spear/update_ with storage minecraft:spear cmd

