#应用附魔效果
scoreboard players set @s gamemode 0
scoreboard players set @s[gamemode=creative] gamemode 1
scoreboard players set @s[gamemode=adventure] gamemode 2
scoreboard players set @s[gamemode=spectator] gamemode 3

summon item_display ~ ~ ~ {Tags:["bm_misc_enchant_temp"]}
item replace entity @e[tag=bm_misc_enchant_temp,limit=1,distance=..2] contents from entity @s weapon.offhand
item replace entity @s weapon.offhand with stone[enchantments={"trident:invisibility":1}]
execute if predicate trident:fly run tag @s add bm_ench_fly

gamemode spectator
execute unless entity @s[tag=bm_ench_fly] run gamemode survival
gamemode survival @s[scores={gamemode=0}]
gamemode creative @s[scores={gamemode=1}]
gamemode adventure @s[scores={gamemode=2}]

item replace entity @s weapon.offhand with air
item replace entity @s weapon.offhand from entity @e[tag=bm_misc_enchant_temp,limit=1,distance=..2] contents

kill @e[tag=bm_misc_enchant_temp]
tag @s remove bm_ench_fly

