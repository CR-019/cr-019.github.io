tag @s remove spear_effect_temp

data modify entity @s transformation.scale set value [1.5f,1f,1.5f]