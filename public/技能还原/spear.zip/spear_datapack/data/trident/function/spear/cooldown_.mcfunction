advancement revoke @s only trident:spear_using

tag @s add spear_using