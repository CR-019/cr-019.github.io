#粒子
summon item_display ~ ~ ~ {Tags:["spear_smash_temp"]}
loot replace entity @e[limit=1,tag=spear_smash_temp,sort=nearest] contents mine ~ ~-1 ~ diamond_pickaxe[enchantments={silk_touch:1}]
loot replace entity @e[limit=1,tag=spear_smash_temp,sort=nearest] contents mine ~ ~ ~ diamond_pickaxe[enchantments={silk_touch:1}]
data modify storage spear block set value "dirt"
data modify storage spear block set from entity @e[limit=1,tag=spear_smash_temp,sort=nearest] item.id
kill @e[type=item_display,tag=spear_smash_temp]

function trident:spear/smash/particle_normal with storage spear

#特效
execute as @s[tag=spear_buff] at @s run function trident:spear/smash/effect


#声音
playsound minecraft:item.mace.smash_ground
playsound minecraft:item.mace.smash_ground
execute as @s[tag=spear_buff] run playsound minecraft:entity.wind_charge.wind_burst
execute as @s[tag=spear_buff] run playsound minecraft:entity.wind_charge.wind_burst

#伤害
execute as @s[tag=!spear_buff] as @e[tag=!spear_smash,distance=..5,type=#uin:tech/mobs] run damage @s 7 mace_smash by @a[limit=1,tag=spear_smash,sort=nearest] from @a[limit=1,tag=spear_smash,sort=nearest]
execute as @s[tag=spear_buff] as @e[tag=!spear_smash,distance=..5,type=#uin:tech/mobs] run damage @s 15 mace_smash by @a[limit=1,tag=spear_smash,sort=nearest] from @a[limit=1,tag=spear_smash,sort=nearest]

tag @s remove spear_smash