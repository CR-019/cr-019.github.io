summon item_display ~ ~.5 ~ {Tags:["spear_effect_boom","spear_effect","spear_effect_temp"],item:{id:"firework_star",components:{item_model:"spear:boom",custom_model_data:{floats:[0f]}}},item_display:"fixed"}

execute as @e[tag=spear_effect_temp,limit=1,sort=nearest] run function trident:spear/effect/boom/summon_