tag @s remove spear_buff
scoreboard players set @s spear_buff_timer 0

function trident:spear/update