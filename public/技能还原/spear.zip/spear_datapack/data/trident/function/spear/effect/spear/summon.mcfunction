summon item_display ~ ~ ~ {Tags:["spear_effect","spear_effect_spear","spear_effect_temp"],item:{id:"firework_star",components:{item_model:"spear:effect",custom_model_data:{floats:[-5f]}}},item_display:"fixed"}
data modify storage minecraft:spear effect set value {scale:1f,rotation_x:0f,rotation_y:0f,y:0f}
execute store result storage minecraft:spear effect.scale float 0.01 run random value 100..200
execute store result storage minecraft:spear effect.rotation_x float 0.01 run random value 0..36000
execute store result storage minecraft:spear effect.rotation_y float 0.01 run random value -1000..1000
execute store result storage minecraft:spear effect.y float 0.5 run data get storage minecraft:spear effect.scale

execute as @e[tag=spear_effect_temp,limit=1,sort=nearest] run function trident:spear/effect/spear/summon_ with storage minecraft:spear effect

