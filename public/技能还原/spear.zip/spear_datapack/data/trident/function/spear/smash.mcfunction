tag @s add spear_smash
tp ~ ~ ~
execute rotated 0 0 run function trident:misc/motion_macro {pos:"^ ^1 ^",times:5}
scoreboard players set @s spear_smash 20
effect give @s resistance 1 5 true