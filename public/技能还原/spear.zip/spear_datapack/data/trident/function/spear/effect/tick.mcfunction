#识别类型
execute as @s[tag=spear_effect_spear] run function trident:spear/effect/spear/tick

execute as @s[tag=spear_effect_boom] run function trident:spear/effect/boom/tick