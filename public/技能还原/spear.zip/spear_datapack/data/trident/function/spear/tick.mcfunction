#标记
execute as @a if predicate trident:spear/main run scoreboard players set @s spear_handle 1
execute as @a unless predicate trident:spear/main run scoreboard players set @s spear_handle 0
execute as @a unless score @s spear_handle = @s spear_handle_lt run function trident:spear/update
execute as @a run scoreboard players operation @s spear_handle_lt = @s spear_handle

# 冷却计时器
execute as @a run function trident:spear/cooldown
#突刺
execute as @a[tag=spear_charge] at @s run function trident:spear/charge

#下落攻击
execute as @a if score @s spear_smash matches 1.. run scoreboard players remove @s spear_smash 1
execute as @a[tag=spear_smash] if predicate trident:ground at @s run function trident:spear/smash_hit
execute as @a[tag=!spear_smash,predicate=trident:smash,predicate=trident:spear/main] unless score @s spear_smash matches 2.. at @s align xz positioned ~.5 ~ ~.5 run function trident:spear/smash

#强化
execute as @a if score @s spear_energy matches 160.. if predicate trident:spear/main if predicate trident:buff at @s run function trident:spear/buff/activate

execute as @a if score @s spear_hit matches 1.. at @s run function trident:spear/buff/hit

execute as @a[tag=spear_buff] at @s run function trident:spear/buff/tick

## 物品检查
execute as @a[tag=spear_buff] if predicate trident:spear/main unless predicate trident:buff run item modify entity @s weapon.mainhand trident:buff
execute as @a[tag=!spear_buff] if predicate trident:spear/buff run item modify entity @s weapon.mainhand trident:normal

#特效
execute as @e[tag=spear_effect] at @s run function trident:spear/effect/tick

