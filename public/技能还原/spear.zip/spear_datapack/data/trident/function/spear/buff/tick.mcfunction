execute if score @s spear_buff_timer matches 1.. run scoreboard players remove @s spear_buff_timer 1

scoreboard players operation #temp spear_buff_timer = @s spear_buff_timer
scoreboard players operation #temp spear_buff_timer %= #20 spear_buff_timer
execute if predicate trident:spear/main if score #temp spear_buff_timer matches 0 run function trident:spear/update
execute if predicate trident:spear/main if score #temp spear_buff_timer matches 0 if score @s spear_buff_bleed matches 3.. run damage @s 1


execute if score @s spear_buff_timer matches 0 run function trident:spear/buff/exit

execute unless predicate trident:spear/main run function trident:spear/buff/exit

effect give @s resistance 1 2