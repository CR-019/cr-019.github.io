execute as @s[tag=!spear_buff] if predicate trident:spear/main run scoreboard players add @s spear_energy 8
scoreboard players set @s spear_hit 0

#粒子
execute as @s[tag=spear_buff] positioned ^ ^ ^4 run particle glow_squid_ink ~ ~1 ~ 1 0.5 1 0 5
execute as @s[tag=spear_buff] positioned ^ ^ ^4 run particle glow ~ ~1 ~ 1 0.5 1 0 5

function trident:spear/update