execute if score @s spear_cooldown_1 matches 1.. run scoreboard players remove @s spear_cooldown_1 1
execute if score @s spear_cooldown_2 matches 1.. run scoreboard players remove @s spear_cooldown_2 1

execute if score @s spear_cooldown_1 <= @s spear_cooldown_2 run scoreboard players operation @s spear_cooldown = @s spear_cooldown_2
execute unless score @s spear_cooldown_1 <= @s spear_cooldown_2 run scoreboard players operation @s spear_cooldown = @s spear_cooldown_1
scoreboard players add @s spear_cooldown 10

execute as @s[tag=spear_using] run function trident:spear/cooldown_set

tag @s remove spear_using


#检查可用
execute if score @s spear_cooldown_1 matches 0 if score @s spear_cooldown_2 matches 0 run scoreboard players set @s spear_charge_count 2
execute unless score @s spear_cooldown_1 matches 0 if score @s spear_cooldown_2 matches 0 run scoreboard players set @s spear_charge_count 1
execute if score @s spear_cooldown_1 matches 0 unless score @s spear_cooldown_2 matches 0 run scoreboard players set @s spear_charge_count 1
execute unless score @s spear_cooldown_1 matches 0 unless score @s spear_cooldown_2 matches 0 run scoreboard players set @s spear_charge_count 0

execute unless score @s spear_charge_count = @s spear_charge_count_lt run function trident:spear/update
scoreboard players operation @s spear_charge_count_lt = @s spear_charge_count