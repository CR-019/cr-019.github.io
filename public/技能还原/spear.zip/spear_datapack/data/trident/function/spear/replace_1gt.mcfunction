execute as @a[tag=fixation_temp] at @s run function trident:spear/replace_
execute as @a[tag=fixation_temp] run tag @s remove fixation_temp