summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}
summon marker ~ ~ ~ {Tags:[spear_smash_effect_marker]}

$spreadplayers ~ ~ 0.5 4 under $(height) false @e[tag=spear_smash_effect_marker]
#spreadplayers ~ ~ 0.5 4 false @e[tag=spear_smash_effect_marker]

execute as @e[tag=spear_smash_effect_marker] at @s run function trident:spear/effect/spear/summon

execute as @e[tag=spear_smash_effect_marker] run kill @s

