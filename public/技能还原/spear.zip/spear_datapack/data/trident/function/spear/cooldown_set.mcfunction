execute store result storage spear cooldown float 0.05 run scoreboard players get @s spear_cooldown
execute if predicate trident:spear/main run function trident:spear/modify with storage minecraft:spear

