#突刺计时器
execute if score @s spear_charge matches 1.. run scoreboard players remove @s spear_charge 1


execute as @s[tag=!spear_buff] as @e[distance=..3,tag=!spear_charge,tag=!spear_charge_victim,type=#uin:tech/mobs] run scoreboard players add @a[tag=spear_charge,sort=nearest,limit=1] spear_energy 16
execute as @e[distance=..3,tag=!spear_charge,tag=!spear_charge_victim,type=#uin:tech/mobs] run damage @s 6 trident by @a[limit=1,sort=nearest,tag=spear_charge]
execute as @e[distance=..3,tag=!spear_charge,tag=!spear_charge_victim,type=#uin:tech/mobs] run tag @s add spear_charge_victim

execute if score @s spear_charge matches 0 run tag @e[tag=spear_charge_victim,distance=..20] remove spear_charge_victim

execute if score @s spear_charge matches 0 run tag @s remove spear_charge
execute if score @s spear_charge matches 0 run function trident:spear/update
#粒子
particle glow_squid_ink ~ ~1 ~ 1 0.5 1 0 5
particle glow ~ ~1 ~ 1 0.5 1 0 5
particle sweep_attack ~ ~1 ~ 1 0.5 1 0 3