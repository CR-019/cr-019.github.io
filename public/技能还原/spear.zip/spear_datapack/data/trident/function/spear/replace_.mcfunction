advancement revoke @s only trident:spear
function lay:macro/inventory/init
data modify storage lay Inventory.target set value "{components:{\"minecraft:custom_data\":{spear_remainder:1b}}}"
data modify storage lay Inventory.func set value "trident:spear/replace__"
function lay:macro/inventory/start

