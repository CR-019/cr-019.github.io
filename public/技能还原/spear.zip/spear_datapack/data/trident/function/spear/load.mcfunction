scoreboard objectives add spear_handle dummy
scoreboard objectives add spear_handle_lt dummy
# 两次冷却

scoreboard objectives add spear_cooldown_1 dummy
scoreboard objectives add spear_cooldown_2 dummy
scoreboard objectives add spear_cooldown dummy
scoreboard objectives add spear_charge_count dummy
scoreboard objectives add spear_charge_count_lt dummy

execute as @a unless score @s spear_cooldown_1 matches -2147483648..2147483647 run scoreboard players set @s spear_cooldown_1 0
execute as @a unless score @s spear_cooldown_2 matches -2147483648..2147483647 run scoreboard players set @s spear_cooldown_2 0

scoreboard objectives add spear_charge dummy
scoreboard objectives add spear_smash dummy

#充能
scoreboard objectives add spear_energy dummy
scoreboard objectives add spear_buff_bleed health
scoreboard objectives add spear_buff_timer dummy
scoreboard players set #20 spear_buff_timer 20
scoreboard objectives add spear_hit custom:damage_dealt

#特效
scoreboard objectives add spear_effect_timer dummy