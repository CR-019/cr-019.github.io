tag @s add fixation_temp
schedule function trident:spear/replace_1gt 1t
function trident:spear/trigger