$item modify entity @s weapon.mainhand {\
    "function": "set_components",\
    "components": {\
        "use_cooldown": {\
            "seconds": $(cooldown),\
            "cooldown_group": "spear"\
        }\
    }\
}