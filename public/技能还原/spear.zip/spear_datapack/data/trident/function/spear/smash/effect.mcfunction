execute store result score #temp spear_smash run data get entity @s Pos[1]
scoreboard players add #temp spear_smash 3
execute store result storage minecraft:spear height int 1 run scoreboard players get #temp spear_smash

function trident:spear/smash/effect_ with storage minecraft:spear

function trident:spear/effect/boom/summon

particle soul ~ ~.5 ~ 3 0 3 0 100