tag @s add spear_buff
scoreboard players set @s spear_energy 0
scoreboard players set @s spear_buff_timer 300
item modify entity @s weapon.mainhand trident:buff
playsound minecraft:block.vault.open_shutter
playsound minecraft:entity.breeze.death

function trident:spear/update

