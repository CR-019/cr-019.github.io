execute rotated ~ 0 run function trident:misc/motion_macro {pos:"^ ^ ^-1",times:5}


scoreboard players set #temp spear_cooldown 0
execute if score @s spear_cooldown_1 <= @s spear_cooldown_2 run scoreboard players set #temp spear_cooldown 1
execute if score #temp spear_cooldown matches 1 run scoreboard players set @s spear_cooldown_1 200
execute if score #temp spear_cooldown matches 0 run scoreboard players set @s spear_cooldown_2 200

scoreboard players set @s spear_charge 5
tag @s add spear_charge

#声音
playsound item.trident.riptide_3
playsound minecraft:entity.breeze.jump

function trident:spear/enchant_apply