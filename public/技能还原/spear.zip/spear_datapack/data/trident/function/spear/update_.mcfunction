$item modify entity @s weapon.mainhand {\
    "function": "set_custom_model_data",\
    "flags": {\
        "values": [$(buff)],\
        "mode": "replace_all"\
    },\
    "floats": {\
        "values": [$(energy)],\
        "mode": "replace_all"\
    },\
    "strings": {\
        "values":["$(charge)"],\
        "mode": "replace_all"\
    }\
}