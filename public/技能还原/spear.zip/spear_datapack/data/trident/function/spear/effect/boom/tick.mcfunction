execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s spear_effect_timer
scoreboard players add @s spear_effect_timer 1

execute if score @s spear_effect_timer matches 11.. run kill @s