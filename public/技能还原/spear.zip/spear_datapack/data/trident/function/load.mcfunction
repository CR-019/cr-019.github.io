scoreboard objectives add gamemode dummy


tellraw @s {"text":"[","color":"aqua","extra":[{"text":"风轮两立","color":"aqua"},{"text":"]","color":"aqua"},{"text":"[","color":"gold"},{"keybind":"key.use","color":"gold"},{"text":"]","color":"gold"},{"text":"疾速突进，对路径上的敌人造成伤害。可在空中释放，拥有两次使用次数。"}]}