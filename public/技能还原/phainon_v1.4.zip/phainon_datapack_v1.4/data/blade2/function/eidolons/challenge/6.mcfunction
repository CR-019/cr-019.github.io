tellraw @s {"text": "已全部达成"}
