tellraw @s {"text": "激活条件：发动28次终结一击。"}
tellraw @s [{"text": "达成进度："},{"score": {"name": "@s","objective": "blade2_eidolon_ult"},"color": "aqua"},{"text": "/28"}]