tellraw @s {"text": "在变身期间击败凋灵。"}
tellraw @s [{"text": "达成进度："},{"text": "0","color": "aqua"},{"text": "/1"}]