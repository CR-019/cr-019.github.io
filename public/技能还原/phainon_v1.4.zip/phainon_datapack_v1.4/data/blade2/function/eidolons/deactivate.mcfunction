execute unless score @s blade2_eidolons matches 1.. run return run tellraw @s {"text": "星魂已全部回退！","color": "red"}

scoreboard players remove @s blade2_eidolons 1
tellraw @s {"text": "星魂已回退！","color": "aqua"}
function blade2:eidolons/advancements
function blade2:eidolons/menu