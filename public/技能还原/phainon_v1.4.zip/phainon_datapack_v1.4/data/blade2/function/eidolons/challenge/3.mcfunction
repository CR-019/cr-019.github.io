tellraw @s {"text": "激活条件：获得496枚[火种]。"}
tellraw @s [{"text": "达成进度："},{"score": {"name": "@s","objective": "blade2_eidolon_spark"},"color": "aqua"},{"text": "/496"}]