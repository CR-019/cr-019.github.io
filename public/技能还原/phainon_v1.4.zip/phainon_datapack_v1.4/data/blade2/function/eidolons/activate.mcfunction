execute unless score @s blade2_eidolons < @s blade2_eidolons_max run return run tellraw @s {"text": "可激活星魂数达到上限！","color": "red"}

scoreboard players add @s blade2_eidolons 1
tellraw @s {"text": "星魂已激活！","color": "aqua"}
function blade2:eidolons/advancements
function blade2:eidolons/menu

