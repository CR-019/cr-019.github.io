execute if score @s blade2_eidolons matches ..5 run advancement revoke @s only blade2:display/6
execute if score @s blade2_eidolons matches ..4 run advancement revoke @s only blade2:display/5
execute if score @s blade2_eidolons matches ..3 run advancement revoke @s only blade2:display/4
execute if score @s blade2_eidolons matches ..2 run advancement revoke @s only blade2:display/3
execute if score @s blade2_eidolons matches ..1 run advancement revoke @s only blade2:display/2
execute if score @s blade2_eidolons matches ..0 run advancement revoke @s only blade2:display/1

execute if score @s blade2_eidolons matches 1.. run advancement grant @s only blade2:display/1
execute if score @s blade2_eidolons matches 2.. run advancement grant @s only blade2:display/2
execute if score @s blade2_eidolons matches 3.. run advancement grant @s only blade2:display/3
execute if score @s blade2_eidolons matches 4.. run advancement grant @s only blade2:display/4
execute if score @s blade2_eidolons matches 5.. run advancement grant @s only blade2:display/5
execute if score @s blade2_eidolons matches 6.. run advancement grant @s only blade2:display/6