tellraw @s {"text": "获得8128枚[火种]"}
tellraw @s [{"text": "达成进度："},{"score": {"name": "@s","objective": "blade2_eidolon_spark"},"color": "aqua"},{"text": "/8128"}]