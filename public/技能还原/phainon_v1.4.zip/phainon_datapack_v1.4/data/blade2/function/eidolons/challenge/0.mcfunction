tellraw @s {"text": "获得134枚[火种]"}
tellraw @s [{"text": "达成进度："},{"score": {"name": "@s","objective": "blade2_eidolon_spark"},"color": "aqua"},{"text": "/134"}]