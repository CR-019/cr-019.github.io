execute if predicate blade2:eidolon run scoreboard players add @s blade2_eidolon_timer 1
execute unless predicate blade2:eidolon run scoreboard players set @s blade2_eidolon_timer 0

execute if score @s blade2_eidolon_timer matches 40.. run function blade2:eidolons/menu

execute if score @s blade2_eidolon_spark matches 134.. if score @s blade2_eidolons_max matches 0 run function blade2:eidolons/trigger
execute if score @s blade2_eidolon_ult matches 28.. if score @s blade2_eidolons_max matches 2 run function blade2:eidolons/trigger
execute if score @s blade2_eidolon_spark matches 496.. if score @s blade2_eidolons_max matches 3 run function blade2:eidolons/trigger
execute if score @s blade2_eidolon_spark matches 8128.. if score @s blade2_eidolons_max matches 5 run function blade2:eidolons/trigger