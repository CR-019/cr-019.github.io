scoreboard players add @s blade2_eidolons_max 1
tellraw @s {"text": "有星魂可激活！","color": "aqua"}
tellraw @s [{"text": "长按","color": "gray"},{"keybind": "key.sneak","color": "gray"},{"text": "+","color": "gray"},{"keybind": "key.sprint","color": "gray"},{"text": "查看","color": "gray"}]