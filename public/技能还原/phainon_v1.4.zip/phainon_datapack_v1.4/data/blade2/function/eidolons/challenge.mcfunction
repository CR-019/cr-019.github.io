tellraw @s {"text": "当前挑战："}
execute if score @s blade2_eidolons_max matches 0 run function blade2:eidolons/challenge/0
execute if score @s blade2_eidolons_max matches 1 run function blade2:eidolons/challenge/1
execute if score @s blade2_eidolons_max matches 2 run function blade2:eidolons/challenge/2
execute if score @s blade2_eidolons_max matches 3 run function blade2:eidolons/challenge/3
execute if score @s blade2_eidolons_max matches 4 run function blade2:eidolons/challenge/4
execute if score @s blade2_eidolons_max matches 5 run function blade2:eidolons/challenge/5
execute if score @s blade2_eidolons_max matches 6 run function blade2:eidolons/challenge/6