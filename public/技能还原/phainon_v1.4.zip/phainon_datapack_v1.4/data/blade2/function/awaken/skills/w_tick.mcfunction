execute if score @s blade2_w_using matches 0 if score @s blade2_w_using_lt matches 1 run function blade2:awaken/skills/w_trigger

execute if score @s blade2_w_using matches 1 if score @s blade2_w_using_lt matches 0 run function blade2:awaken/skills/w_satire

#减伤
execute if score @s blade2_w_using matches 1 run item modify entity @s armor.head blade2:awaken_w_on
execute if score @s blade2_w_using matches 0 run item modify entity @s armor.head blade2:awaken_w_off

#层数
execute if score @s blade2_w_using matches 0 run scoreboard players set @s blade2_w_energy 0
loot replace entity @s weapon.offhand loot blade2:energy

scoreboard players operation @s blade2_w_using_lt = @s blade2_w_using
scoreboard players set @s blade2_w_using 0

