#首先尝试匹配
execute as @e[type=item_display,tag=blade2_wings] if score @s blade2_uid = @n[type=player,tag=blade2_wing_temp] blade2_uid run return run function blade2:awaken/wing/follow
#若没有，则生成一个
function blade2:awaken/wing/summon