#主动退出变身状态

scoreboard players operation @s blade2_sparks += @s blade2_movement
scoreboard players set @s blade2_movement 0