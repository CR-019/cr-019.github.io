execute if entity @s[tag=blade2_awaken] run function blade2:awaken/title/q
execute if entity @s[tag=blade2_awaken] run function blade2:awaken/title/w
execute if entity @s[tag=blade2_awaken] run function blade2:awaken/title/e

execute if score @s player_damage matches 1.. run function damage_display:title

scoreboard players operation panel_id title.io = @s panelid
function title:replace_panel

execute unless entity @s[gamemode=spectator] run scoreboard players operation @s title.panel_id = @s panelid
execute if entity @s[gamemode=spectator] run scoreboard players set @s title.panel_id 0