bossbar set blade2_awaken color pink
bossbar set blade2_awaken style progress
bossbar set blade2_awaken max 33550336
bossbar set blade2_awaken name {"text": "\u0001\u0100","font": "sword:icons","color": "red","extra": [{"text": "0","font": "sword:ascii","color": "dark_red"}]}