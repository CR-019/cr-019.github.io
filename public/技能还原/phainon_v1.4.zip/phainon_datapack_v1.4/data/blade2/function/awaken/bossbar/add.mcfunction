bossbar add blade2_awaken ""

bossbar set blade2_awaken color yellow
bossbar set blade2_awaken style notched_6
bossbar set blade2_awaken max 7
bossbar set blade2_awaken value 7
bossbar set blade2_awaken players @a
bossbar set blade2_awaken name {"text": "\u0001\u0100","font": "sword:icons","color": "yellow","extra": [{"text": "7","font": "sword:ascii","color": "gold"}]}