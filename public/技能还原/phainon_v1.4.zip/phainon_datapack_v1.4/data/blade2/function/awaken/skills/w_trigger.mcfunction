scoreboard players remove @s blade2_movement 1

#1星魂减cd
execute unless score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 100
execute if score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 60

effect give @s instant_health 1 3
function blade2:awaken/pack/fill


tag @s add blade2_w_satire_temp
execute as @e[distance=..20,type=#uin:tech/mobs,tag=!blade2_w_satire_temp] run effect give @s slowness 2 4 true
tag @s remove blade2_w_satire_temp
function blade2:effect/w/trigger