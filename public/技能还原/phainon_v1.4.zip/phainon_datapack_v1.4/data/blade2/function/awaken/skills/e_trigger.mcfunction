item replace entity @s weapon.offhand with air

execute if score @s blade2_scourge matches 1.. run function blade2:awaken/skills/e_debuff
#回合数-1（2星魂额外回合）
execute if score @s blade2_scourge matches 1.. run scoreboard players remove @s blade2_movement 1
execute if score @s blade2_scourge matches 4.. if score @s blade2_eidolons matches 2.. run scoreboard players add @s blade2_movement 1
#cd设置（1星魂减cd）
execute if score @s blade2_scourge matches 1.. unless score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 200
execute if score @s blade2_scourge matches 1.. if score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 120

execute if score @s blade2_scourge matches 1.. run effect give @s instant_health 1 3
function blade2:awaken/pack/fill
execute if score @s blade2_scourge matches 1 run function blade2:effect/e/trigger_1
execute if score @s blade2_scourge matches 2 run function blade2:effect/e/trigger_2
execute if score @s blade2_scourge matches 3 run function blade2:effect/e/trigger_3
execute if score @s blade2_scourge matches 4.. run function blade2:effect/e/trigger_4
