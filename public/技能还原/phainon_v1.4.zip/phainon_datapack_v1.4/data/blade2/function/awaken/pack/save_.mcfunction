$data modify storage blade2 pack.$(uid) set value []
$data modify storage blade2 pack.$(uid) set from entity @s Inventory