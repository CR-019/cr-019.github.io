xp set @s 33550336 levels
scoreboard players operation @s blade2_xp_awaken = @s blade2_cooldown
execute store result storage blade2 temp.xp_cooldown int 1 run scoreboard players operation @s blade2_xp_awaken *= $xp_unit blade2_xp_awaken
function blade2:awaken/xp/points with storage blade2 temp