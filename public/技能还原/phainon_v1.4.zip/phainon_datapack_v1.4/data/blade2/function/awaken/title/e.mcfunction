execute unless score @s blade2_cooldown matches 1.. if score @s blade2_movement matches 1.. unless score @s blade2_w_using_lt matches 1 run function blade2:awaken/title/e_enable
execute if score @s blade2_cooldown matches 1.. run function blade2:awaken/title/e_disable
execute unless score @s blade2_movement matches 1.. run function blade2:awaken/title/e_disable
execute if score @s blade2_w_using_lt matches 1 run function blade2:awaken/title/e_disable
function title:new_part

data merge storage title:io {text:'{"text":""}', align:"left",  origin:"down-right",x:-80,y:65}
function title:new_text

data merge storage title:io {text:'{"keybind":"key.swapOffhand"}',font:"default_mod",neg_font:"default_neg"}

function title:new_part

data merge storage title:io {text:'{"text":""}', align:"left",  origin:"down-right",x:-60,y:60}
function title:new_text

#毁伤
execute if score @s blade2_scourge matches 0 run data merge storage title:io {text:'{"text":"\\u0013"}',font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_scourge matches 1 run data merge storage title:io {text:'{"text":"\\u0014"}',font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_scourge matches 2 run data merge storage title:io {text:'{"text":"\\u0015"}',font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_scourge matches 3 run data merge storage title:io {text:'{"text":"\\u0016"}',font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_scourge matches 4.. run data merge storage title:io {text:'{"text":"\\u0017"}',font:"sword:icons",neg_font:"sword:icons_neg"}
function title:new_part

data merge storage title:io {text:'{"text":""}', align:"left",  origin:"down-right",x:-95,y:100}
function title:new_text

execute store result storage blade2 temp.scourge int 1 run scoreboard players get @s blade2_scourge
function blade2:awaken/title/scourge with storage blade2 temp