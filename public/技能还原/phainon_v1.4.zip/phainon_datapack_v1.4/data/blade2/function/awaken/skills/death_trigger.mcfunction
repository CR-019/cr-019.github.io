advancement revoke @s only blade2:awaken_death

function blade2:awaken/bossbar/final
function blade2:awaken/skills/final_start