#as/at: player
tag @s add blade2_wing_temp
execute if entity @s[tag=blade2_awaken] run function blade2:awaken/wing/match
execute if entity @s[tag=!blade2_awaken] run function blade2:awaken/wing/clear

tag @s remove blade2_wing_temp