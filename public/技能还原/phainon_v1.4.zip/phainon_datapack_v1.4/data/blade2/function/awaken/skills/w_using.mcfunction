advancement revoke @s only blade2:awaken_w_using

scoreboard players set @s blade2_w_using 1