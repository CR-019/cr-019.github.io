#保存并清除背包
execute store result storage blade2 temp.uid int 1 run scoreboard players get @s blade2_uid

function blade2:awaken/pack/save_ with storage blade2 temp

clear @s