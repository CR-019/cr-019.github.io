#返还背包
clear @s
summon item_display ~ ~ ~ {Tags:[blade2_pack_temp]}
execute store result storage blade2 temp.uid int 1 run scoreboard players get @s blade2_uid
function blade2:awaken/pack/return_start with storage blade2 temp



kill @e[type=item_display,tag=blade2_pack_temp]
