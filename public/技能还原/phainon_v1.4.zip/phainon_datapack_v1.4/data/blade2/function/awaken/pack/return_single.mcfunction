#单个物品处理

## 初始化
data modify storage blade2 pack.single set value {}
$data modify storage blade2 pack.single set value $(value)
execute as @n[type=item_display,tag=blade2_pack_temp] run item replace entity @s contents with air

## 填充物品
data modify entity @n[type=item_display,tag=blade2_pack_temp] item merge from storage blade2 pack.single

##判断槽位并返回
execute if data storage blade2 {pack:{single:{Slot:-106b}}} run return run item replace entity @s weapon.offhand from entity @n[type=item_display,tag=blade2_pack_temp] contents
execute if data storage blade2 {pack:{single:{Slot:100b}}} run return run item replace entity @s armor.feet from entity @n[type=item_display,tag=blade2_pack_temp] contents
execute if data storage blade2 {pack:{single:{Slot:101b}}} run return run item replace entity @s armor.legs from entity @n[type=item_display,tag=blade2_pack_temp] contents
execute if data storage blade2 {pack:{single:{Slot:102b}}} run return run item replace entity @s armor.chest from entity @n[type=item_display,tag=blade2_pack_temp] contents
execute if data storage blade2 {pack:{single:{Slot:103b}}} run return run item replace entity @s armor.head from entity @n[type=item_display,tag=blade2_pack_temp] contents

execute store result score @s blade2_temp run data get storage blade2 pack.single.Slot
execute if score @s blade2_temp matches 0..8 run return run function blade2:awaken/pack/return_single_hotbar with storage blade2 pack.single
execute store result storage blade2 pack.single.slot_correction int 1 run scoreboard players remove @s blade2_temp 9
function blade2:awaken/pack/return_single_inventory with storage blade2 pack.single