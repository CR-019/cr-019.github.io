$function lay:macro/list/init {func:"blade2:awaken/pack/return_single",list:"storage blade2 pack.$(uid)"}
