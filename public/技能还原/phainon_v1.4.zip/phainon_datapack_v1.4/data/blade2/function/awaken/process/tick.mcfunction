execute if score @s blade2_timer matches 1.. run scoreboard players remove @s blade2_timer 1
execute if score @s blade2_timer matches 1.. run tp @s @n[type=marker,tag=blade2_awaken_lock]
execute if score @s blade2_timer matches 0 run kill @n[type=marker,tag=blade2_awaken_lock]
execute if score @s blade2_timer matches 0 run tag @s remove blade2_awaken_pre
execute if score @s blade2_timer matches 0 run function blade2:awaken

particle dust{color:16767232,scale:1} ~ ~1 ~ 1.5 1.5 1.5 0 100
particle enchant ~ ~2 ~ 0 0 0 1 20