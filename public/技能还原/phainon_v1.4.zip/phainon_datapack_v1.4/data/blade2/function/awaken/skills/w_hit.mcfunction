advancement revoke @s only blade2:awaken_w_hit
scoreboard players add @s blade2_w_energy 1
playsound block.anvil.land player @a ~ ~ ~ 0.5 0.5
execute anchored eyes run particle gust ^ ^ ^1 0 0 0 0 0
execute anchored eyes run particle dust{color:16767232,scale:1} ^ ^ ^0.5 1 1 1 0 40