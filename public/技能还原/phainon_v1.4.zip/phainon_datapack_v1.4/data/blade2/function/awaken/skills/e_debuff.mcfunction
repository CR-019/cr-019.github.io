#解除所有负面效果

effect clear @s slowness
effect clear @s minecraft:mining_fatigue
effect clear @s nausea
effect clear @s blindness
effect clear @s hunger
effect clear @s weakness
effect clear @s poison
effect clear @s wither
effect clear @s glowing
effect clear @s levitation
effect clear @s unluck
effect clear @s bad_omen
effect clear @s darkness
effect clear @s wind_charged
effect clear @s weaving
effect clear @s oozing
effect clear @s infested