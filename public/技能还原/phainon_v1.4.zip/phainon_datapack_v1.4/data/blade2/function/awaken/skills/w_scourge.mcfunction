tag @s add blade2_w_scourge_temp
execute store result score #temp blade2_scourge if entity @e[type=#uin:tech/mobs,tag=!blade2_w_scourge_temp,distance=..20]
scoreboard players operation #temp blade2_scourge /= $3 blade2_scourge
scoreboard players add #temp blade2_scourge 1
execute if score #temp blade2_scourge matches 6.. run scoreboard players set #temp blade2_scourge 5
scoreboard players operation @s blade2_scourge += #temp blade2_scourge
execute if score @s blade2_scourge matches 8.. run scoreboard players set @s blade2_scourge 7
tag @s remove blade2_w_scourge_temp