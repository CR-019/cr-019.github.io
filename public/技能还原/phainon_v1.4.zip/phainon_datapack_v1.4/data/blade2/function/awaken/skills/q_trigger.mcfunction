scoreboard players remove @s blade2_movement 1

#1星魂减cd
execute unless score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 100
execute if score @s blade2_eidolons matches 1.. run scoreboard players set @s blade2_cooldown 60

scoreboard players add @s blade2_scourge 2
execute if score @s blade2_scourge matches 8.. run scoreboard players set @s blade2_scourge 7
effect give @s instant_health 1 3
function blade2:awaken/pack/fill

function blade2:effect/q/trigger