#嘲讽周围的生物
tag @s add blade2_w_satire_temp
execute as @e[distance=..20,type=#uin:tech/mobs,tag=!blade2_w_satire_temp] run damage @s 0.1 player_attack by @n[tag=blade2_w_satire_temp]
tag @s remove blade2_w_satire_temp
function blade2:awaken/skills/w_scourge

#初始化层数
execute unless score @s blade2_eidolons matches 4.. run scoreboard players set @s blade2_w_energy 1
execute if score @s blade2_eidolons matches 4.. run scoreboard players set @s blade2_w_energy 5