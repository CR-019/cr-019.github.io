$data modify entity @s transformation.scale set value [$(scale)f,$(scale)f,$(scale)f]
data modify entity @s start_interpolation set value 0