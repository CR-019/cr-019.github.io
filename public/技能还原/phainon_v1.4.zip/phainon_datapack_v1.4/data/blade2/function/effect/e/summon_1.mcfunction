tag @s add blade2_e_marker_selected

function blade2:effect/e/effect/spear_small/summon
function blade2:effect/e/effect/spear_small/summon

execute as @e[distance=..1,type=item_display,tag=blade2_e_effect_temp2] run data modify entity @s item.components."minecraft:custom_data".Owner set from entity @n[tag=blade2_e_marker_selected] data.Owner

spreadplayers ~ ~ 1 30 false @e[distance=..1,tag=blade2_e_effect_temp2]

scoreboard players operation #temp blade2_e_timer = @s blade2_e_timer
scoreboard players operation #temp blade2_e_timer %= $10 blade2_e_timer
execute if score #temp blade2_e_timer matches 0 at @e[distance=..30,type=#uin:tech/mobs,type=!player,sort=random,limit=1] run function blade2:effect/e/effect/spear_small/summon


tag @e remove blade2_e_effect_temp2

tag @s remove blade2_e_marker_selected