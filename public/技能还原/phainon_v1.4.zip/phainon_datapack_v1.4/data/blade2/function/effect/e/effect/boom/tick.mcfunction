#查表计算纵向位移
execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s blade2_e_timer
scoreboard players add @s blade2_e_timer 1

execute if score @s blade2_e_timer matches 10.. run kill @s