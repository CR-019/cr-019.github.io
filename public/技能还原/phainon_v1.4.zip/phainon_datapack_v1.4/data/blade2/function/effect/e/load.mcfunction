scoreboard objectives add blade2_e_timer dummy
scoreboard objectives add blade2_e_level dummy

scoreboard players set $10 blade2_e_timer 10
scoreboard players set $8 blade2_e_timer 8
scoreboard players set $5 blade2_e_timer 5