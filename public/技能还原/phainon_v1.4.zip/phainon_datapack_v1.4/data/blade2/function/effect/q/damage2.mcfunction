#playsound entity.generic.explode player @a
#particle explosion_emitter ~ ~ ~ 0 0 0 0 0


$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 3.. run function blade2:damage/main {damage:29,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..5]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 3.. run function blade2:damage/main {damage:34,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..5]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}