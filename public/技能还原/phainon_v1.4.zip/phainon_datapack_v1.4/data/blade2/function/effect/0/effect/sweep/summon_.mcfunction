scoreboard players set @s blade2_w_timer -1
tag @s remove blade2_0_effect_temp
rotate @s ~ ~

data modify entity @s transformation.scale set value [3f,5f,3f]
