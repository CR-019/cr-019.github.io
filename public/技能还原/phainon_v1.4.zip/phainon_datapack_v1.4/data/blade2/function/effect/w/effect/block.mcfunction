#粒子
summon item_display ~ ~ ~ {Tags:["w_particle_temp"]}
loot replace entity @e[limit=1,tag=w_particle_temp,sort=nearest] contents mine ~ ~-1 ~ diamond_pickaxe[enchantments={silk_touch:1}]
loot replace entity @e[limit=1,tag=w_particle_temp,sort=nearest] contents mine ~ ~ ~ diamond_pickaxe[enchantments={silk_touch:1}]
data modify storage blade block set value "air"
data modify storage blade block set from entity @e[limit=1,tag=w_particle_temp,sort=nearest] item.id
kill @e[type=item_display,tag=w_particle_temp]

function blade2:effect/w/effect/particle with storage blade

data modify storage blade2 damage set from entity @s data
function blade2:effect/w/effect/damage with entity @s data