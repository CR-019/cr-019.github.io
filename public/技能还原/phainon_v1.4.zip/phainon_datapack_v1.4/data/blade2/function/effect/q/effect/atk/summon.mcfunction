summon item_display ~ ~ ~ {Tags:["blade2_q_effect","blade2_q_effect_atk","blade2_q_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:atk_effect"}},item_display:"fixed",interpolation_duration:1,billboard:"vertical",glow_color_override:16712965,Glowing:1b}


execute as @e[tag=blade2_q_effect_temp,limit=1,sort=nearest] run function blade2:effect/q/effect/atk/summon_