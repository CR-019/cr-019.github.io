scoreboard players set @s blade2_e_timer 22
tag @s remove blade2_e_effect_temp

#$data modify entity @s transformation.translation set value [0f,$(y)f,0f]

$data modify entity @s Rotation[0] set value $(rotation_x)f
$data modify entity @s Rotation[1] set value $(rotation_y)f

$data modify entity @s transformation.scale set value [$(scale)f,$(scale)f,$(scale)f]

