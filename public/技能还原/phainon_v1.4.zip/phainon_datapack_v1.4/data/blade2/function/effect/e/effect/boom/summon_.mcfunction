scoreboard players set @s blade2_e_timer -1
tag @s remove blade2_e_effect_temp

data modify entity @s transformation.scale set value [4f,4f,4f]
