summon item_display ~ ~ ~ {Tags:["blade2_e_effect","blade2_e_effect_spear","blade2_e_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:aerolite"}},interpolation_duration:20,glow_color_override:16712965}
data modify storage minecraft:spear effect set value {scale:1f,rotation_x:0f,rotation_y:0f,y:0f}
execute store result storage minecraft:spear effect.rotation_x float 0.01 run random value 0..36000

execute as @e[tag=blade2_e_effect_temp,limit=1,sort=nearest] run function blade2:effect/e/effect/spear/summon_ with storage minecraft:spear effect

