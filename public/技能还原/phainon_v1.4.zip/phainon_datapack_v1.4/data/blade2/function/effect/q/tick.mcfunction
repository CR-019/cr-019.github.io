execute as @e[type=marker,tag=blade2_q_marker] at @s run function blade2:effect/q/execute

execute as @e[tag=blade2_q_effect] at @s run function blade2:effect/q/effect/tick