scoreboard objectives add blade2_1_timer dummy
scoreboard objectives add blade2_1_scale dummy