
execute if score @s blade2_e_timer matches 1 run data modify entity @s transformation.scale set value [200f,100f,200f]

execute if score @s blade2_e_timer matches 1 run data modify entity @s start_interpolation set value 0

execute if score @s blade2_e_timer matches 17 run data modify entity @s interpolation_duration set value 300
execute if score @s blade2_e_timer matches 17 run data modify entity @s transformation.right_rotation set value [0f,1f,0f,0f]
execute if score @s blade2_e_timer matches 17 run data modify entity @s start_interpolation set value 0

execute if score @s blade2_e_timer matches 55 run effect give @a[distance=..100] darkness 2 0 true



scoreboard players add @s blade2_e_timer 1

execute if score @s blade2_e_timer matches 70.. run kill @s