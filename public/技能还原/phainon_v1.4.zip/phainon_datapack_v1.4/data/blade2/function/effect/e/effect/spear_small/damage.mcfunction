playsound entity.generic.explode player @a
particle explosion_emitter ~ ~ ~ 0 0 0 0 0
particle flame ~ ~ ~ 0 0 0 0.1 200
particle landing_lava ~ ~ ~ 0 0 0 0.1 200


$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:10,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..7]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:15,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..7]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
