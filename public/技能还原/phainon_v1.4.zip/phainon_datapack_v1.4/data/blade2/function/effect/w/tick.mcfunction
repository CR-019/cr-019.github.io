execute as @e[type=marker,tag=blade2_w_marker] at @s run function blade2:effect/w/execute


#execute as @e[tag=blade2_w_effect] at @s run function blade2:effect/w/effect/tick