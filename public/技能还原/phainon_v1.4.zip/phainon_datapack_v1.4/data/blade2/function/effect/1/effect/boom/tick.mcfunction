#查表计算纵向位移
execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s blade2_1_timer
scoreboard players add @s blade2_1_timer 1

execute if score @s blade2_1_timer matches 8 store result storage minecraft:blade2 scale float 0.01 run random value 500..1500
execute if score @s blade2_1_timer matches 8 run function blade2:effect/1/effect/boom/scale with storage minecraft:blade2

execute if score @s blade2_1_timer matches 16.. run kill @s