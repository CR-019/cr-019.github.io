summon item_display ~ ~ ~ {Tags:["blade2_1_effect","blade2_1_effect_ball","blade2_1_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:explode"}},item_display:"fixed",interpolation_duration:25,view_range:100}


execute as @e[tag=blade2_1_effect_temp,limit=1,sort=nearest] run function blade2:effect/1/effect/ball/summon_