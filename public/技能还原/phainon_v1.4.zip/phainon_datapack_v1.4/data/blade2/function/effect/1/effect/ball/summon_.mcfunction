scoreboard players set @s blade2_e_timer -1
tag @s remove blade2_1_effect_temp

data modify entity @s transformation.scale set value [-150f,-150f,-150f]
