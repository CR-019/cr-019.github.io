execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s blade2_w_timer
scoreboard players add @s blade2_w_timer 1

execute if score @s blade2_w_timer matches 11.. run kill @s