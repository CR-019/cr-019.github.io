#as:player

summon marker ~ ~ ~ {Tags:["blade2_e_marker"]}

data modify entity @n[distance=..0.5,tag=blade2_e_marker] data.Owner set from entity @s UUID
scoreboard players set @n[distance=..0.5,tag=blade2_e_marker] blade2_e_level 1

scoreboard players remove @s blade2_scourge 1