playsound entity.generic.explode player @a ~ ~ ~ 7
playsound entity.generic.explode player @a ~ ~ ~ 7
playsound entity.generic.explode player @a ~ ~ ~ 7
particle explosion_emitter ~ ~ ~ 15 0 15 0 100

$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:15,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..30]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:22,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..30]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
