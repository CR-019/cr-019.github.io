#as:player

execute rotated ~ 0 run summon marker ^-2 ^ ^ {Tags:["blade2_w_marker","blade2_w_marker_temp"]}

data modify entity @n[tag=blade2_w_marker_temp] data.Owner set from entity @s UUID
scoreboard players operation #temp blade2_w_energy = @s blade2_w_energy
scoreboard players add #temp blade2_w_energy 4
execute unless score @s blade2_eidolons matches 5.. store result entity @n[tag=blade2_w_marker_temp] data.damage int 4 run scoreboard players get #temp blade2_w_energy
execute if score @s blade2_eidolons matches 5.. store result entity @n[tag=blade2_w_marker_temp] data.damage int 5 run scoreboard players get #temp blade2_w_energy
rotate @n[tag=blade2_w_marker_temp] ~ 0
tag @e remove blade2_w_marker_temp
