#as:player

execute rotated ~ 0 run summon marker ^ ^ ^5 {Tags:["blade2_q_marker","blade2_q_marker_temp"]}

data modify entity @n[tag=blade2_q_marker_temp] data.Owner set from entity @s UUID
tag @e remove blade2_q_marker_temp
