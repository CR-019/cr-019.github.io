summon item_display ~ ~ ~ {Tags:["blade2_1_effect","blade2_1_effect_boom","blade2_1_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:boom",custom_model_data:{floats:[-5f]}}},item_display:"fixed",interpolation_duration:6}

data modify storage minecraft:blade2 effect set value {scale:1f,rotation_x:0f,rotation_y:0f}
execute store result storage minecraft:blade2 effect.rotation_x float 0.01 run random value 0..36000
execute store result storage minecraft:blade2 effect.rotation_y float 0.01 run random value -6000..6000

execute as @e[tag=blade2_1_effect_temp,limit=1,sort=nearest] run function blade2:effect/1/effect/boom/summon_ with storage minecraft:blade2 effect