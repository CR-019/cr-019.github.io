scoreboard players set @s blade2_1_timer -1
tag @s remove blade2_1_effect_temp

$data modify entity @s Rotation[0] set value $(rotation_x)f
$data modify entity @s Rotation[1] set value $(rotation_y)f

data modify entity @s transformation.scale set value [1.5f,1.5f,1.5f]
