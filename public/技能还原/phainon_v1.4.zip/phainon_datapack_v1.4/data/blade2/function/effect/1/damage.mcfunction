playsound entity.generic.explode player @a ~ ~ ~ 2 0.8
particle explosion_emitter ~ ~ ~ 0 0 0 0 0

#伤害均摊
$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 3.. run scoreboard players set $damage blade2_temp 180
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 3.. run scoreboard players set $damage blade2_temp 210
$execute store result score $count blade2_temp if entity @e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..30]
scoreboard players operation $damage blade2_temp /= $count blade2_temp

$data modify storage blade2:temp 1.damage set value {damage:0,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..30]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
execute store result storage blade2:temp 1.damage.damage float 1 run scoreboard players get $damage blade2_temp

function blade2:damage/main with storage blade2:temp 1.damage