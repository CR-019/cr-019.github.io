$particle flame ~ ~$(particle) ~ 0.5 2 0.5 0.01 30 force @a
$particle dust{color:16732416,scale:1} ~ ~$(particle) ~ 0.5 2 0.5 0.01 30 force @a