#查表计算纵向位移
execute if score @s blade2_e_timer matches 22 run data modify entity @s transformation.translation[1] set value 80f
execute if score @s blade2_e_timer matches 21 run data modify entity @s interpolation_duration set value 20
execute if score @s blade2_e_timer matches 20 run data modify entity @s transformation.translation[1] set value 0f
execute if score @s blade2_e_timer matches 20 run data modify entity @s start_interpolation set value 0
execute if score @s blade2_e_timer matches 19 run data modify entity @s Glowing set value 1b


execute if score @s blade2_e_timer matches 0 run function blade2:effect/e/effect/spear_small/damage with entity @s item.components."minecraft:custom_data"

execute store result storage stone particle int 4 run scoreboard players get @s blade2_e_timer
function blade2:effect/e/effect/spear_small/particle with storage stone
scoreboard players remove @s blade2_e_timer 1

execute if score @s blade2_e_timer matches ..-2 run kill @s