
execute if score @s blade2_e_timer matches 20 run data modify entity @s transformation.scale set value [6f,6f,6f]

execute if score @s blade2_e_timer matches 20 run data modify entity @s start_interpolation set value 0

execute if score @s blade2_e_timer matches ..20 run particle portal ~ ~3 ~ 0.1 1 0.1 0 20
execute if score @s blade2_e_timer matches 21.. run particle portal ~ ~3 ~ 1 1 1 0 40
execute if score @s blade2_e_timer matches 39 run particle dust{color:9109671,scale:1} ~ ~3 ~ 1 1 1 0 200
execute if score @s blade2_e_timer matches 40.. run kill @s

scoreboard players add @s blade2_e_timer 1