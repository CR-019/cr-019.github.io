execute as @e[type=marker,tag=blade2_1_marker] at @s run function blade2:effect/1/execute

execute as @e[tag=blade2_1_effect] at @s run function blade2:effect/1/effect/tick