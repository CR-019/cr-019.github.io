scoreboard players add @s blade2_w_timer 1



execute if score @s blade2_w_timer matches 1 run function animated_java:w/summon {args:{}}

execute if score @s blade2_w_timer matches 1 as @n[type=item_display,tag=aj.w.root] at @s run function animated_java:w/animations/w/play

execute if score @s blade2_w_timer matches 61 as @n[type=item_display,tag=aj.w.root] at @s run function animated_java:w/remove/this

execute if score @s blade2_w_timer matches 1 run playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10 0.793

execute if score @s blade2_w_timer matches 25 run playsound minecraft:entity.lightning_bolt.thunder player @a ~ ~ ~ 2 1
execute if score @s blade2_w_timer matches 25 run playsound minecraft:entity.lightning_bolt.thunder player @a ~ ~ ~ 2 1
execute if score @s blade2_w_timer matches 35 run playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 1

execute if score @s blade2_w_timer matches 30 positioned ^ ^ ^-12 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 30 positioned ^ ^ ^-10 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 30 positioned ^ ^ ^-8 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 31 positioned ^ ^ ^-6 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 31 positioned ^ ^ ^-4 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 31 positioned ^ ^ ^-2 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 32 positioned ^ ^ ^0 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 32 positioned ^ ^ ^2 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 32 positioned ^ ^ ^4 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 33 positioned ^ ^ ^6 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 33 positioned ^ ^ ^8 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 33 positioned ^ ^ ^10 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 34 positioned ^ ^ ^12 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 34 positioned ^ ^ ^14 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 34 positioned ^ ^ ^16 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 35 positioned ^ ^ ^18 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 35 positioned ^ ^ ^20 run function blade2:effect/w/effect/block
execute if score @s blade2_w_timer matches 35 positioned ^ ^ ^22 run function blade2:effect/w/effect/block

execute if score @s blade2_w_timer matches 61 run function blade2:effect/w/effect/vanish
execute if score @s blade2_w_timer matches 62.. run kill @s

