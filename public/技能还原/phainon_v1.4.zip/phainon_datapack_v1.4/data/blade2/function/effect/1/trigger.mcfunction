#as:player

execute anchored eyes rotated ~ 0 run summon marker ^ ^0.5 ^2 {Tags:["blade2_1_marker","blade2_1_marker_temp"]}

data modify entity @n[tag=blade2_1_marker_temp] data.Owner set from entity @s UUID
rotate @n[tag=blade2_1_marker_temp] ~ 0
tag @e remove blade2_1_marker_temp

scoreboard players add @s blade2_eidolon_ult 1