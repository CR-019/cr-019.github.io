execute if entity @s[tag=blade2_e_effect_spear] run function blade2:effect/e/effect/spear/tick
execute if entity @s[tag=blade2_e_effect_boom] run function blade2:effect/e/effect/boom/tick
execute if entity @s[tag=blade2_e_effect_spear_small] run function blade2:effect/e/effect/spear_small/tick
execute if entity @s[tag=blade2_e_effect_ring] run function blade2:effect/e/effect/ring/tick