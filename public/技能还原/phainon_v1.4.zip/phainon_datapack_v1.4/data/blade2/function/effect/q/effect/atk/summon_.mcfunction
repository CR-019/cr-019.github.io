scoreboard players set @s blade2_e_timer -1
tag @s remove blade2_e_effect_temp

data modify entity @s transformation.scale set value [0.1f,6f,6f]
data modify entity @s transformation.translation set value [0f,3f,0f]