#查表计算纵向位移
execute if score @s blade2_e_timer matches -18 run data modify entity @s transformation.scale set value [30f,30f,30f]
execute if score @s blade2_e_timer matches -18 run data modify entity @s transformation.translation[1] set value 60f
execute if score @s blade2_e_timer matches -18 run data modify entity @s start_interpolation set value 0


execute if score @s blade2_e_timer matches 1 run data modify entity @s transformation.translation[1] set value 30f
execute if score @s blade2_e_timer matches 1 run data modify entity @s interpolation_duration set value 50
execute if score @s blade2_e_timer matches 1 run data modify entity @s start_interpolation set value 0

execute if score @s blade2_e_timer matches 51 run data modify entity @s transformation.translation[1] set value 0f
execute if score @s blade2_e_timer matches 51 run data modify entity @s interpolation_duration set value 55
execute if score @s blade2_e_timer matches 51 run data modify entity @s start_interpolation set value 0
execute if score @s blade2_e_timer matches 51 run data modify entity @s Glowing set value 1b

execute if score @s blade2_e_timer matches 51 run playsound block.beacon.deactivate player @a ~ ~ ~ 5 0
execute if score @s blade2_e_timer matches 51 run playsound block.beacon.deactivate player @a ~ ~ ~ 5 0
execute if score @s blade2_e_timer matches 51 run playsound block.beacon.deactivate player @a ~ ~ ~ 5 0

execute if score @s blade2_e_timer matches 55 run effect give @a[distance=..100] darkness 4 0 true
execute if score @s blade2_e_timer matches 54 run effect give @a[distance=..100] night_vision 4 0 true

scoreboard players add @s blade2_e_timer 1

execute if score @s blade2_e_timer matches 110.. run kill @s