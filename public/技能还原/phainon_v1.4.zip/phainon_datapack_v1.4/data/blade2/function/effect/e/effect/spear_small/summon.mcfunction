summon item_display ~ ~ ~ {Tags:["blade2_e_effect","blade2_e_effect_spear_small","blade2_e_effect_temp","blade2_e_effect_temp2"],item:{id:"magma_block"},item_display:"fixed",interpolation_duration:1,glow_color_override:16712965,brightness:{sky:15,block:15}}
data modify storage minecraft:spear effect set value {scale:1f,rotation_x:0f,rotation_y:0f,y:0f}
execute store result storage minecraft:spear effect.scale float 0.01 run random value 250..400
execute store result storage minecraft:spear effect.rotation_x float 0.01 run random value 0..36000
execute store result storage minecraft:spear effect.y float 0.5 run data get storage minecraft:spear effect.scale

execute as @e[tag=blade2_e_effect_temp,limit=1,sort=nearest] run function blade2:effect/e/effect/spear_small/summon_ with storage minecraft:spear effect

