scoreboard players add @s blade2_1_timer 1

#execute if score @s blade2_1_timer matches 1 run playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10


execute if score @s blade2_1_timer matches 1 run function blade2:effect/1/effect/ball/summon

execute if score @s blade2_1_timer matches 1 run playsound block.beacon.deactivate player @a ~ ~ ~ 5 0
execute if score @s blade2_1_timer matches 35 run stopsound @a player block.beacon.deactivate

execute if score @s blade2_1_timer matches 30 run effect give @a[distance=..100] darkness 4 0 true
execute if score @s blade2_1_timer matches 30 run effect give @a[distance=..100] night_vision 4 0 true

execute if score @s blade2_1_timer matches 27 run function blade2:effect/1/effect/boom/summon
execute if score @s blade2_1_timer matches 28 run function blade2:effect/1/effect/boom/summon
execute if score @s blade2_1_timer matches 29 run function blade2:effect/1/effect/boom/summon

execute if score @s blade2_1_timer matches 35 run function blade2:effect/1/damage with entity @s data


execute if score @s blade2_1_timer matches 62.. run kill @s

