summon item_display ~ ~ ~ {Tags:["blade2_e_effect","blade2_e_effect_boom","blade2_e_effect_temp"],item:{id:"firework_star",components:{item_model:"arrows:boom",custom_model_data:{floats:[-5f]}}},item_display:"fixed",interpolation_duration:1}


execute as @e[tag=blade2_e_effect_temp,limit=1,sort=nearest] run function blade2:effect/e/effect/boom/summon_