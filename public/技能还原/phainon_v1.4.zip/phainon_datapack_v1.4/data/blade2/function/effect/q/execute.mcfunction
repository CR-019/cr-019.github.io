scoreboard players add @s blade2_q_timer 1

#execute if score @s blade2_q_timer matches 1 run playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10

execute if score @s blade2_q_timer matches 1 run function blade2:effect/q/effect/atk/summon

execute if score @s blade2_q_timer matches 1 run playsound minecraft:entity.wither.ambient player @a

execute if score @s blade2_q_timer matches 20 run playsound minecraft:entity.wither.shoot player @a

data modify storage blade2 damage set from entity @s data

execute if score @s blade2_q_timer matches 20 run function blade2:effect/q/damage2 with entity @s data


execute if score @s blade2_q_timer matches 40 run function blade2:effect/q/damage3 with entity @s data

execute if score @s blade2_q_timer matches 41.. run kill @s

