execute if entity @s[tag=blade2_1_effect_boom] run function blade2:effect/1/effect/boom/tick

execute if entity @s[tag=blade2_1_effect_ball] run function blade2:effect/1/effect/ball/tick
