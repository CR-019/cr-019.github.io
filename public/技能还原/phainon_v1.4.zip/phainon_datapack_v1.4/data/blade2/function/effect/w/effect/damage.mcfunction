#playsound entity.generic.explode player @a
#particle explosion_emitter ~ ~ ~ 0 0 0 0 0


$function blade2:damage/main {damage:$(damage),target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..7]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}