summon item_display ~ ~ ~ {Tags:["blade2_e_effect","blade2_e_effect_ring","blade2_e_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:ring_effect"}},item_display:"fixed",interpolation_duration:15}


execute as @e[tag=blade2_e_effect_temp,limit=1,sort=nearest] run function blade2:effect/e/effect/ring/summon_