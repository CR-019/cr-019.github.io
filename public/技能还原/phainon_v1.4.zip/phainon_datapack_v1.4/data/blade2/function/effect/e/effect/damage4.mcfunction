playsound entity.generic.explode player @a ~ ~ ~ 15
playsound entity.generic.explode player @a ~ ~ ~ 15
playsound entity.generic.explode player @a ~ ~ ~ 15
playsound entity.generic.explode player @a ~ ~ ~ 15
particle explosion_emitter ~ ~ ~ 30 0 30 0 200

$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:10,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..40]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:18,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..40]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
