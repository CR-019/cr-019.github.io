playsound entity.generic.explode player @a ~ ~ ~ 3
playsound entity.generic.explode player @a ~ ~ ~ 3
particle explosion_emitter ~ ~ ~ 5 0 5 0 20

$execute unless score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:25,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..20]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
$execute if score @n[type=player,nbt={UUID:$(Owner)}] blade2_eidolons matches 5.. run function blade2:damage/main {damage:30,target:"@e[type=#uin:tech/mobs,nbt=!{UUID:$(Owner)},distance=..20]",origin:"@a[limit=1,nbt={UUID:$(Owner)}]"}
