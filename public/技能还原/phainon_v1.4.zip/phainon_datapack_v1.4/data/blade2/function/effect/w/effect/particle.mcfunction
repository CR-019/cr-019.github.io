particle explosion_emitter ~ ~ ~ 0 0 0 0 0

$particle dust_pillar{block_state:{Name:"$(block)"}} ^0.5 ^ ^ 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-0.5 ^ ^ 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^0.5 ^ ^1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-0.5 ^ ^1 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^0.5 ^ ^-1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-0.5 ^ ^-1 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^1 ^ ^ 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-1 ^ ^ 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^1 ^ ^1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-1 ^ ^1 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^1 ^ ^-1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-1 ^ ^-1 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^2 ^ ^ 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-2 ^ ^ 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^2 ^ ^1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-2 ^ ^1 0.3 0 0.3 0 50

$particle dust_pillar{block_state:{Name:"$(block)"}} ^2 ^ ^-1 0.3 0 0.3 0 50
$particle dust_pillar{block_state:{Name:"$(block)"}} ^-2 ^ ^-1 0.3 0 0.3 0 50