scoreboard players set @s blade2_e_timer -1
tag @s remove blade2_e_effect_temp

data modify entity @s transformation.translation set value [0f,50f,0f]
data modify entity @s transformation.scale set value [0f,0f,0f]
