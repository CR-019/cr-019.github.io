execute as @e[type=marker,tag=blade2_e_marker] at @s run function blade2:effect/e/execute

execute as @e[tag=blade2_e_effect] at @s run function blade2:effect/e/effect/tick