
execute if score @s blade2_1_timer matches 2 run data modify entity @s transformation.scale set value [1f,1f,1f]
execute if score @s blade2_1_timer matches 2 run data modify entity @s start_interpolation set value 0

execute if score @s blade2_1_timer matches 35 run data modify entity @s transformation.scale set value [100f,100f,100f]
execute if score @s blade2_1_timer matches 35 run data modify entity @s interpolation_duration set value 3
execute if score @s blade2_1_timer matches 35 run data modify entity @s start_interpolation set value 0

scoreboard players add @s blade2_1_timer 1

execute if score @s blade2_1_timer matches 60.. run kill @s