scoreboard players operation @s blade2_uid = #current blade2_uid
scoreboard players add #current blade2_uid 1