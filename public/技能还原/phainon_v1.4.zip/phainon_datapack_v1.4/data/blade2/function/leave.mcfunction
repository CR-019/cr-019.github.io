kill @e[tag=blade2_0_effect]
kill @e[tag=blade2_1_effect]
kill @e[tag=blade2_e_effect]
kill @e[tag=blade2_q_effect]
kill @e[tag=blade2_wings]
scoreboard players set @a blade2_leave 0