#交换
item replace entity @s weapon.mainhand from entity @s weapon.offhand
item replace entity @s weapon.offhand with air

#触发效果
execute if score @s blade2_sparks matches 12.. run function blade2:awaken/process/start
execute if score @s blade2_sparks matches 12.. run scoreboard players remove @s blade2_sparks 12