#正常形态，右键
advancement revoke @s only blade2:consume

tag @s add blade2_replace_temp
schedule function blade2:trigger_1gt 1t

tag @s add blade2_trigger_temp
execute anchored eyes rotated ~ 0 positioned ^ ^-1 ^4 run function blade2:effect/0/effect/sweep/summon


execute anchored eyes rotated ~ 0 positioned ^ ^ ^3 run function blade2:damage/main {damage:8,target:"@e[tag=!blade2_trigger_temp,type=#uin:tech/mobs,distance=..5]",origin:"@n[tag=blade2_trigger_temp]"}


playsound entity.player.attack.sweep player @a
scoreboard players add @s blade2_sparks 2
scoreboard players add @s blade2_eidolon_spark 2
execute unless score @s blade2_eidolons matches 6.. if score @s blade2_sparks matches 16.. run scoreboard players set @s blade2_sparks 15
tag @s remove blade2_trigger_temp