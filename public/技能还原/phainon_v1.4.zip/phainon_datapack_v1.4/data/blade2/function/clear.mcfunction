execute if items entity @s player.cursor *[custom_data~{blade2_offhand:1b}] run clear @s *[custom_data~{blade2_offhand:1b}]
execute if items entity @s hotbar.* *[custom_data~{blade2_offhand:1b}] run clear @s *[custom_data~{blade2_offhand:1b}]
execute if items entity @s inventory.* *[custom_data~{blade2_offhand:1b}] run clear @s *[custom_data~{blade2_offhand:1b}]
