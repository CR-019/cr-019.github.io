execute as @a[tag=blade2_replace_temp] unless predicate blade2:main run clear @s *[custom_data~{blade2:1b}]
execute as @a[tag=blade2_replace_temp] unless predicate blade2:main run loot give @s loot blade2:sword
execute as @a[tag=blade2_replace_temp] run tag @s remove blade2_replace_temp
