$data modify storage blade2 damage.damage set value $(damage)
$execute as $(target) run damage @s $(damage) player_attack by $(origin)