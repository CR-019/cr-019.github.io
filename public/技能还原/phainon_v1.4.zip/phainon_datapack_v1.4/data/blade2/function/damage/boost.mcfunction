#计算增伤区
#基础100%
scoreboard players set @s blade2_boost 100




#每级力量折算10%增伤
scoreboard players set $strength blade2_boost 0
execute if predicate blade2:strength run function blade2:damage/strength

scoreboard players operation @s blade2_boost += $strength blade2_boost

#额外增伤区
scoreboard players operation @s blade2_boost += @s blade2_boost_extra