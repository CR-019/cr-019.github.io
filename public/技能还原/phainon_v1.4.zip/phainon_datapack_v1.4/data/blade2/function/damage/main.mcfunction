#args: (float)damage (target)target (target)origin

$data modify storage blade2:damage damage set value {damage:0f,target:"$(target)",origin:"$(origin)"}
$data modify storage blade2:damage temp.base set value $(damage)
$execute store result storage blade2:damage temp.boost float 0.0001 run scoreboard players get $(origin) blade2_boost
function blade2:damage/multiply with storage blade2:damage temp
function blade2:damage/execute with storage blade2:damage damage
