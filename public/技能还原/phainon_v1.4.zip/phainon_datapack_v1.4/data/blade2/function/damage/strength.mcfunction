execute store result score $strength blade2_boost run data get entity @s active_effects[{id:"minecraft:strength"}].amplifier
scoreboard players add $strength blade2_boost 1
scoreboard players operation $strength blade2_boost *= $10 blade2_boost