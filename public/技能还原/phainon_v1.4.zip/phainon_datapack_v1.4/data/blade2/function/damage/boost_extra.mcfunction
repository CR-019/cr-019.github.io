#计算额外增伤
scoreboard players set @s blade2_boost_extra 0

#星魂1变身增伤20%
execute if entity @s[tag=blade2_awaken] if score @s blade2_eidolons matches 1.. run scoreboard players add @s blade2_boost_extra 20

#星魂2变身增伤20%
execute if entity @s[tag=blade2_awaken] if score @s blade2_eidolons matches 2.. run scoreboard players add @s blade2_boost_extra 20

#星魂6变身增伤36%
execute if entity @s[tag=blade2_awaken] if score @s blade2_eidolons matches 6.. run scoreboard players add @s blade2_boost_extra 36