#tag处理
tag @s add blade2_awaken

#保存背包
function blade2:awaken/pack/save

#属性处理
attribute @s max_health modifier add blade2_awaken 3.7 add_multiplied_total
attribute @s movement_speed modifier add blade2_awaken 0.2 add_multiplied_total
attribute @s safe_fall_distance modifier add blade2_awaken 17 add_value
attribute @s fall_damage_multiplier modifier add blade2_awaken -0.5 add_value
attribute @s block_interaction_range modifier add blade2_awaken -1 add_multiplied_total
attribute @s entity_interaction_range modifier add blade2_awaken 3 add_value
attribute @s armor modifier add blade2_awaken 20 add_value
attribute @s armor_toughness modifier add blade2_awaken 12 add_value
attribute @s jump_strength modifier add blade2_awaken 1 add_multiplied_total
effect give @s instant_health 1 3 true
effect give @s saturation 1 10 true

#毁伤
scoreboard players add @s blade2_scourge 4
execute if score @s blade2_scourge matches 8.. run scoreboard players set @s blade2_scourge 7

#bossbar
function blade2:awaken/bossbar/add
scoreboard players set @s blade2_cooldown 0
scoreboard players set @s blade2_movement 7
scoreboard players set @s blade2_timer -1

#效果
particle flash ~ ~1 ~ 1 1 1 0 10 force
playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10 1.059

#经验锁定
execute store result score @s blade2_xp_level run xp query @s levels
execute store result score @s blade2_xp_point run xp query @s points
