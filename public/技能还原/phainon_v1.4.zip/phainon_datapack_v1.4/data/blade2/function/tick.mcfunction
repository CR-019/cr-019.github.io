function blade2:effect/e/tick
function blade2:effect/q/tick
function blade2:effect/w/tick
function blade2:effect/1/tick
function blade2:effect/0/tick


execute as @a run function blade2:damage/boost
execute as @a run function blade2:damage/boost_extra
execute as @a run function blade2:eidolons/tick

execute as @a at @s run function blade2:awaken/wing/tick
execute as @a[tag=blade2_awaken] at @s run function blade2:awaken/tick
execute as @a[tag=blade2_awaken_pre] at @s run function blade2:awaken/process/tick
execute as @a run scoreboard players reset @s blade2_q_damage

execute as @a if predicate blade2:main run function blade2:offhand
execute as @a unless predicate blade2:main_both run clear @s *[custom_data~{blade2_offhand:1b}]
execute as @a if predicate blade2:off at @s run function blade2:awaken_trigger

execute as @e[type=item] if items entity @s contents *[custom_data~{blade2:2b}] on origin if score @s blade2_eidolons matches 6.. unless score @s blade2_movement matches -1 run function blade2:awaken/skills/6_trigger
execute as @a run function blade2:clear
execute as @e[type=item] if items entity @s contents *[custom_data~{blade2_offhand:1b}] run kill @s
execute as @e[type=item] if items entity @s contents *[custom_data~{blade2_awaken_fill:1b}] run kill @s

execute as @a unless score @s blade2_sparks matches -2147483648..2147483647 run scoreboard players set @s blade2_sparks 0

execute as @a at @s run function blade2:awaken/title/main

execute as @a if score @s blade2_leave matches 1 run schedule function blade2:leave 1s

