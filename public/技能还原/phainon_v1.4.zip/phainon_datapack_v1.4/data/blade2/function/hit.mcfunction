advancement revoke @s only blade2:hit

scoreboard players add @s blade2_sparks 1
scoreboard players add @s blade2_eidolon_spark 1
execute unless score @s blade2_eidolons matches 6.. if score @s blade2_sparks matches 16.. run scoreboard players set @s blade2_sparks 15