execute store result storage damage player_damage int 0.1 run scoreboard players get @s player_damage

function damage_display:title_ with storage damage