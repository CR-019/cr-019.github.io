execute if score @s player_timer matches 1.. run scoreboard players remove @s player_timer 1
execute unless score @s player_damage = @s player_damage_lt run scoreboard players set @s player_timer 60

execute if score @s player_timer matches 0 run scoreboard players set @s player_damage 0
execute if score @s player_timer matches 0 run scoreboard players set @s player_damage_lt 0

scoreboard players operation @s player_damage_lt = @s player_damage