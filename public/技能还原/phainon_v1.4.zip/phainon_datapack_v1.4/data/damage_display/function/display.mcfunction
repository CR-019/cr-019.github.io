$summon item ~ ~ ~ {Item:{id:"firework_star",count:1,components:{item_model:"sword:empty"}},Age:5990,PickupDelay:32767,Passengers:[{id:"text_display",Tags:["damage_display"],text:"{\"text\":\"$(damage)\",\"bold\":true}",alignment:"center",transformation:{scale:[2f,2f,2f],translation:[0f,0f,0f],left_rotation:[0,0,0,1],right_rotation:[0,0,0,1]},billboard:"center"}],Motion:[0f,0.01f,0f]}

