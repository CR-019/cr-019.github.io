execute as @e[type=#uin:tech/mobs] at @s if entity @a[distance=..50] run function damage_display:tick_as_mob

execute as @a at @s run function damage_display:tick_as_player

execute as @e[type=text_display,tag=damage_display] at @s run function damage_display:tick_as_display