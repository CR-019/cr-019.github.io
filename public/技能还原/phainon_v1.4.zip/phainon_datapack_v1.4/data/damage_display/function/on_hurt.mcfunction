tag @s add on_hurt_temp
scoreboard players operation @s hurt = @s health_lt
scoreboard players operation @s hurt -= @s health

execute store result storage damage damage int 0.1 run scoreboard players get @s hurt
execute on attacker at @n[tag=on_hurt_temp] facing entity @s eyes positioned ^ ^1 ^1.5 run function damage_display:display with storage damage

execute on attacker if entity @s[type=player] run scoreboard players operation @s player_damage += @n[tag=on_hurt_temp] hurt

tag @s remove on_hurt_temp

