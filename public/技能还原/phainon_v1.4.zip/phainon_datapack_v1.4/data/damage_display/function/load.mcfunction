scoreboard objectives add player_damage dummy
scoreboard objectives add player_damage_lt dummy
scoreboard objectives add player_timer dummy

scoreboard objectives add health dummy
scoreboard objectives add health_lt dummy
scoreboard objectives add hurt dummy