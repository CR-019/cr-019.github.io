execute store result score @s health run data get entity @s Health 10

execute if data entity @s {HurtTime:10s} run function damage_display:on_hurt


scoreboard players operation @s health_lt = @s health