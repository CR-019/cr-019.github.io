advancement revoke @s only damage_display:kill

execute store result score #temp player_damage run data get storage blade2 damage.damage 10
scoreboard players operation @s player_damage += #temp player_damage