advancement revoke @s only blade:consume
function lay:macro/inventory/init
data modify storage lay Inventory.target set value "{components:{\"minecraft:custom_data\":{blade_remainder:1b}}}"
data modify storage lay Inventory.func set value "blade:replace__"
function lay:macro/inventory/start

