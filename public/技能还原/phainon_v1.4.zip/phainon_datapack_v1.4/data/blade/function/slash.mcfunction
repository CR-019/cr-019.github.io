execute store result score #temp blade_timer run random value 0..2
execute if score #temp blade_timer matches 0..2 run function blade:shadow/summon
execute if score #temp blade_timer matches 2 run function blade:shadow/summon