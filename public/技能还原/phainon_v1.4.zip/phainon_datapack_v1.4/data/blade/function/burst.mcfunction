tag @s add blade_player_temp
summon marker ~ ~ ~ {Tags:["burst_marker"]}

summon marker ~ ~ ~ {Tags:["burst_marker2"]}
execute store result score #temp blade_target run data get entity @e[limit=1,tag=burst_marker] Pos[1]
scoreboard players add #temp blade_target 3
execute store result storage minecraft:blade height int 1 run scoreboard players get #temp blade_target

function blade:burst_ with storage minecraft:blade

execute at @e[tag=burst_marker2,limit=1] facing entity @e[limit=1,tag=burst_marker] feet run function blade:shadow/summon

kill @e[tag=burst_marker]
kill @e[tag=burst_marker2]

scoreboard players add @s blade_burst 1
execute if score @s blade_burst matches 2.. run scoreboard players remove @s blade_omen 1
execute if score @s blade_burst matches 2.. run scoreboard players set @s blade_burst 0
execute if score @s blade_omen matches 0 run tag @s remove blade_burst
tag @s remove blade_player_temp