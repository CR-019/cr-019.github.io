scoreboard players set @s blade_damage 0
execute if predicate blade:main run function blade:hit_