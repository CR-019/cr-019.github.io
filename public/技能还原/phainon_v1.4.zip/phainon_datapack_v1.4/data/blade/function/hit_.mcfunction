tag @s add blade_player_temp
execute store result score #temp blade_target run random value 1..10
execute if score #temp blade_target matches 1..5 anchored eyes positioned ^ ^ ^3 run function blade:shadow/summon

execute anchored eyes positioned ^ ^ ^3 as @e[distance=..4,tag=!blade_player_temp] run damage @s 4 player_attack by @a[limit=1,tag=blade_player_temp]
execute anchored eyes positioned ^ ^-1 ^3 run function blade:sweep/summon
tag @s remove blade_player_temp
