tag @s add blade_player_temp
execute if score @s blade_target matches 1.. run function blade:find
tag @s remove blade_player_temp