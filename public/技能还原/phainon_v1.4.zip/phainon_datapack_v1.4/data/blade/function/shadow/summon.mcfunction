summon marker ~ ~ ~ {Tags:["shadow_marker"]}

summon marker ~ ~ ~ {Tags:["shadow_marker2"]}
execute store result score #temp blade_target run data get entity @e[limit=1,tag=shadow_marker] Pos[1]
scoreboard players add #temp blade_target 3
execute store result storage minecraft:blade height int 1 run scoreboard players get #temp blade_target

function blade:shadow/summon_ with storage minecraft:blade

execute at @e[tag=shadow_marker2,limit=1] facing entity @e[limit=1,tag=shadow_marker] feet run function blade:shadow/play

kill @e[tag=shadow_marker]
kill @e[tag=shadow_marker2]

execute unless score @s blade_omen matches 12.. unless entity @s[tag=blade_burst] run scoreboard players add @s blade_omen 1