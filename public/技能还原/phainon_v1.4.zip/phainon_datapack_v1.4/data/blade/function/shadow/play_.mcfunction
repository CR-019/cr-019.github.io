tag @s add shadow_mark
scoreboard players set @s blade_timer 0

data modify entity @s item set value {id:"stone",count:1,components:{"minecraft:custom_data":{blade_origin:1},item_model:"sword:empty"}}
data modify entity @s item.components."minecraft:custom_data".blade_origin set from entity @a[limit=1,tag=blade_player_temp] UUID

function animated_java:shadow/animations/animation_model_new/play