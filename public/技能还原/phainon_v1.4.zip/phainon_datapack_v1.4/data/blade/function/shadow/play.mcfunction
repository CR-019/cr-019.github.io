execute rotated ~ 0 run function animated_java:shadow/summon {args:{}}
execute positioned ~ ~1 ~ run particle gust

execute as @e[distance=..2,limit=1,tag=!shadow_mark,tag=aj.shadow.root,type=item_display] run function blade:shadow/play_