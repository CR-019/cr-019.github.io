execute if score @s blade_timer matches ..40 run scoreboard players add @s blade_timer 1


execute if score @s blade_timer matches 15 at @s run function blade:shadow/damage
execute if score @s blade_timer matches 40.. run function animated_java:shadow/remove/this