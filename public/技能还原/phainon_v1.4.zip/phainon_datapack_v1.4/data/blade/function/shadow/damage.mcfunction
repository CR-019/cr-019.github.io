summon item ~ ~ ~ {Item:{id:"stone"},Tags:["blade_item_temp"]}
data modify entity @e[limit=1,tag=blade_item_temp] Thrower set from entity @s item.components."minecraft:custom_data".blade_origin
execute as @e[limit=1,tag=blade_item_temp] on origin run tag @s add blade_owner

playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 0.5
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 0.5
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 0.5
execute positioned ^ ^ ^3 as @e[tag=!blade_owner,distance=..4] run damage @s 6 blade:slash by @a[tag=blade_owner,limit=1]

tag @a remove blade_owner
kill @e[tag=blade_item_temp]