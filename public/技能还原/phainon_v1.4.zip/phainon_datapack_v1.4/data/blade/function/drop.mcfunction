tag @s add bm_wp_wc_drop_player_temp
data modify storage bmw:weapon wuchuan.temp set from entity @s Inventory[{Slot:-106b}]
summon item ~ ~ ~ {Tags:[bm_wp_wc_drop_temp],Item:{id:"stone",count:1}}
execute as @e[type=item,distance=..2,tag=bm_wp_wc_drop_temp] run function blade:drop_
item replace entity @s weapon.offhand with air
tag @s remove bm_wp_wc_drop_player_temp