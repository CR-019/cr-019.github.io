scoreboard players set @a[tag=blade_aim_player_temp] blade_target 20

execute store result score @a[tag=blade_aim_player_temp] blade_target_0 run data get entity @s UUID[0]
execute store result score @a[tag=blade_aim_player_temp] blade_target_1 run data get entity @s UUID[1]
execute store result score @a[tag=blade_aim_player_temp] blade_target_2 run data get entity @s UUID[2]
execute store result score @a[tag=blade_aim_player_temp] blade_target_3 run data get entity @s UUID[3]