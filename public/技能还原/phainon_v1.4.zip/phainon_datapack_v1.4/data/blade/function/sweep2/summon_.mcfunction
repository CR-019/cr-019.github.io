tag @s remove blade_effect_temp

data modify entity @s transformation.scale set value [16f,8f,16f]