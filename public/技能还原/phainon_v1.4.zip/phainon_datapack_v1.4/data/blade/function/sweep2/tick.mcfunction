execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s blade_timer
scoreboard players add @s blade_timer 1

execute if score @s blade_timer matches 12.. run kill @s