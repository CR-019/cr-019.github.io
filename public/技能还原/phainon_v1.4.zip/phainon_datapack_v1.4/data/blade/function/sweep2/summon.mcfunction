summon item_display ~ ~.5 ~ {Tags:["blade_effect2","blade_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:sweep_max",custom_model_data:{floats:[0f]}}},item_display:"fixed",billboard:"center"}

execute as @e[tag=blade_effect_temp,limit=1,sort=nearest] run function blade:sweep2/summon_