data modify entity @s Owner set from entity @a[limit=1,tag=bm_wp_wc_drop_player_temp] UUID
data modify entity @s Item set from storage bmw:weapon wuchuan.temp
tag @s remove bm_wp_wc_drop_temp