tag @s remove blade_effect_temp

data modify entity @s transformation.scale set value [8f,4f,8f]