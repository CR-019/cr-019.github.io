#交换
item replace entity @s weapon.mainhand from entity @s weapon.offhand
item replace entity @s weapon.offhand with air

#技能
execute if score @s blade_omen matches 4.. run tag @s add blade_burst
execute if score @s blade_omen matches 8.. anchored eyes positioned ^ ^ ^5 run function blade:explode