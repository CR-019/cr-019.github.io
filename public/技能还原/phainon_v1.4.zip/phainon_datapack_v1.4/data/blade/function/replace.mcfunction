tag @s add fixation_temp
schedule function blade:replace_1gt 1t
function blade:trigger