tag @s add blade_aim_player_temp
execute as @e[type=#uin:tech/mobs,distance=..16] run function blade:entity
tag @s remove blade_aim_player_temp