scoreboard objectives add blade_timer dummy
scoreboard objectives add blade_damage custom:damage_dealt
scoreboard objectives add blade_hurt custom:damage_taken
scoreboard objectives add blade_omen dummy
scoreboard objectives add blade_burst dummy

scoreboard objectives add blade_target dummy

scoreboard objectives add blade_target_timer dummy
scoreboard objectives add blade_target_0 dummy
scoreboard objectives add blade_target_1 dummy
scoreboard objectives add blade_target_2 dummy
scoreboard objectives add blade_target_3 dummy