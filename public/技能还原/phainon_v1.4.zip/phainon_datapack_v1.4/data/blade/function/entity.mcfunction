tag @s add blade_entity_temp

scoreboard players set #target blade_target 0
execute as @a[tag=blade_aim_player_temp] if predicate blade:aim run scoreboard players set #target blade_target 1
execute if score #target blade_target matches 1 run tag @s add blade_entity

execute if entity @s[tag=blade_entity] at @s run particle smoke ~ ~1 ~ .5 0.5 0.5 0 1 normal @a[tag=blade_aim_player_temp]
execute if entity @s[tag=blade_entity] run function blade:store

tag @s remove blade_entity_temp
tag @s remove blade_entity