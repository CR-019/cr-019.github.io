tag @s add blade_player_temp

execute as @e[distance=..7,tag=!blade_player_temp] run damage @s 12 player_attack by @a[limit=1,tag=blade_player_temp]
execute rotated ~ 0 positioned ~ ~2 ~ run function blade:sweep2/summon
playsound entity.ender_dragon.growl
tag @s remove blade_player_temp