scoreboard players set @s blade_hurt 0

execute if score @s blade_omen matches 1.. run scoreboard players remove @s blade_omen 1