execute as @e[tag=shadow_mark,type=item_display] at @s run function blade:shadow/timer

execute as @a if predicate blade:main run tag @s add blade_aim_player
execute as @a unless predicate blade:main run tag @s remove blade_aim_player

execute as @a[tag=blade_aim_player] at @s run function blade:aim

execute as @a if predicate blade:off at @s run function blade:burst_trigger
execute as @a[tag=blade_burst] at @s anchored eyes positioned ^ ^ ^5 run function blade:burst

execute as @a run function blade:clear
execute as @a[tag=blade_aim_player] at @s run function blade:main
kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{blade_offhand:1b}}}}]

execute as @a if score @s blade_target matches 1.. run scoreboard players remove @s blade_target 1

execute as @a if score @s blade_damage matches 1.. at @s run function blade:hit
execute as @a if score @s blade_hurt matches 1.. at @s run function blade:hurt

execute as @e[tag=blade_effect] at @s run function blade:sweep/tick
execute as @e[tag=blade_effect2] at @s run function blade:sweep/tick
