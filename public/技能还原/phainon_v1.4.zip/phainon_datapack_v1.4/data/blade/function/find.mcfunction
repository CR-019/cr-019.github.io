data modify storage blade UUID set value [I;0,0,0,0]

execute store result storage blade UUID[0] int 1 run scoreboard players get @s blade_target_0
execute store result storage blade UUID[1] int 1 run scoreboard players get @s blade_target_1
execute store result storage blade UUID[2] int 1 run scoreboard players get @s blade_target_2
execute store result storage blade UUID[3] int 1 run scoreboard players get @s blade_target_3

function blade:find_ with storage blade