data merge storage title:io {text:{"text":"总伤害","color":"gold"}, align:"right",  origin:"up-right",x:-10,y:-65}
function title:new_text

$data merge storage title:io {text:{"text":"$(player_damage)","color":"white"}, align:"right",  origin:"up-right",x:-10,y:-75}
function title:new_text