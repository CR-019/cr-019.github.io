execute if data entity @s equipment.offhand unless predicate blade:offhand run function blade:drop
execute if score @s blade_omen matches 1.. run loot replace entity @s weapon.offhand loot blade:omen
execute if score @s blade_omen matches 1.. run effect give @s resistance 1 3 true