execute unless predicate blade:both run clear @s *[custom_data~"{blade_offhand:1b}"]
execute store result score #temp blade_omen run data get entity @s equipment.offhand.count
execute store result score #temp2 blade_omen run clear @s *[custom_data~"{blade_offhand:1b}"] 0
execute unless score @s blade_omen = #temp blade_omen run clear @s *[custom_data~"{blade_offhand:1b}"]
execute unless score @s blade_omen = #temp2 blade_omen run clear @s *[custom_data~"{blade_offhand:1b}"]