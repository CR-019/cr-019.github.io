#tag处理
tag @s remove blade2_awaken

#返还背包
function blade2:awaken/pack/return

#属性处理
attribute @s max_health modifier remove blade2_awaken
attribute @s movement_speed modifier remove blade2_awaken
attribute @s safe_fall_distance modifier remove blade2_awaken
attribute @s fall_damage_multiplier modifier remove blade2_awaken
attribute @s block_interaction_range modifier remove blade2_awaken
attribute @s entity_interaction_range modifier remove blade2_awaken
attribute @s armor modifier remove blade2_awaken
attribute @s armor_toughness modifier remove blade2_awaken
attribute @s jump_strength modifier remove blade2_awaken
attribute @s gravity modifier remove blade2_awaken
attribute @s gravity modifier remove blade2_awaken_float
attribute @s step_height modifier remove blade2_awaken

effect give @s instant_health 1 2 true
effect give @s slow_falling 10 1 true

#bossbar
function blade2:awaken/bossbar/remove

#火种返还
scoreboard players add @s blade2_sparks 3
scoreboard players add @s blade2_eidolon_spark 3

#经验返还
execute store result storage blade2 temp.xp.levels int 1 run scoreboard players get @s blade2_xp_level
execute store result storage blade2 temp.xp.points int 1 run scoreboard players get @s blade2_xp_point
function blade2:xp with storage blade2 temp.xp
