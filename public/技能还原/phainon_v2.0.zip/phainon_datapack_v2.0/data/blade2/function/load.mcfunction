function blade2:effect/e/load
function blade2:effect/q/load
function blade2:effect/w/load
function blade2:effect/1/load

scoreboard objectives add blade2_uid dummy
execute unless score #current blade2_uid matches -2147483648..2147483647 run scoreboard players set #current blade2_uid 0
execute as @a unless score @s blade2_uid matches -2147483648..2147483647 run function blade2:encode

scoreboard objectives add blade2_sparks dummy
scoreboard objectives add blade2_scourge dummy
scoreboard players set $3 blade2_scourge 3
scoreboard objectives add blade2_movement dummy
scoreboard objectives add blade2_cooldown dummy
scoreboard objectives add blade2_timer dummy
scoreboard objectives add blade2_temp dummy
scoreboard objectives add blade2_w_using dummy
scoreboard objectives add blade2_w_using_lt dummy
scoreboard objectives add blade2_w_energy dummy
scoreboard objectives add blade2_q_damage custom:damage_dealt

scoreboard objectives add blade2_xp_level dummy
scoreboard objectives add blade2_xp_point dummy
scoreboard objectives add blade2_xp_awaken dummy
scoreboard players set $xp_unit blade2_xp_awaken 1509764

scoreboard objectives add blade2_eidolons dummy
scoreboard objectives add blade2_eidolons_max dummy
scoreboard objectives add blade2_eidolon_challenge dummy
scoreboard objectives add blade2_eidolon_spark dummy
scoreboard objectives add blade2_eidolon_ult dummy
scoreboard objectives add blade2_eidolon_timer dummy

scoreboard objectives add blade2_leave custom:leave_game

scoreboard objectives add blade2_boost dummy "增伤 x100"
scoreboard objectives add blade2_boost_extra dummy "额外增伤 x100"
scoreboard players set $100 blade2_boost 100
scoreboard players set $10 blade2_boost 10
scoreboard objectives add blade2_damage dummy

scoreboard objectives add blade2_clock dummy
execute unless score #clock blade2_clock matches -2147483648..2147483647 run scoreboard players set #clock blade2_clock 0