summon item_display ~ ~ ~ {Tags:["blade2_0_effect","blade2_0_effect_temp"],item:{id:"firework_star",components:{item_model:"sword:sweep_slash",custom_model_data:{floats:[-5f]}}},item_display:"fixed",interpolation_duration:1,brightness:{block:15,sky:15}}


execute as @e[tag=blade2_0_effect_temp,limit=1,sort=nearest] run function blade2:effect/0/effect/sweep/summon_

