scoreboard players add @s blade2_e_timer 1

execute if score @s blade2_e_timer matches 1 run playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10 0.944
execute if score @s blade2_e_timer matches 16 run playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10 0.890

execute if score @s blade2_e_level matches 1 if score @s blade2_e_timer matches 10..40 run function blade2:effect/e/summon_1
execute if score @s blade2_e_level matches 2 if score @s blade2_e_timer matches 10..40 run function blade2:effect/e/summon_2
execute if score @s blade2_e_level matches 3.. if score @s blade2_e_timer matches 10..40 run function blade2:effect/e/summon_3

execute if score @s blade2_e_level matches 4 if score @s blade2_e_timer matches 1 run function blade2:effect/e/effect/spear/summon
execute if score @s blade2_e_timer matches 1 run function blade2:effect/e/effect/ring/summon

data modify storage blade2 damage set from entity @s data
execute if score @s blade2_e_level matches 4 if score @s blade2_e_timer matches 75 run function blade2:effect/e/effect/damage with entity @s data
execute if score @s blade2_e_level matches 4 if score @s blade2_e_timer matches 85 run function blade2:effect/e/effect/damage2 with entity @s data
execute if score @s blade2_e_level matches 4 if score @s blade2_e_timer matches 95 run function blade2:effect/e/effect/damage3 with entity @s data
execute if score @s blade2_e_level matches 4 if score @s blade2_e_timer matches 105 run function blade2:effect/e/effect/damage4 with entity @s data


#模型
execute if score @s blade2_e_timer matches 150.. as @a[tag=blade2_awaken] run item modify entity @s armor.head blade2:head_show

execute if score @s blade2_e_timer matches 150.. run kill @s

