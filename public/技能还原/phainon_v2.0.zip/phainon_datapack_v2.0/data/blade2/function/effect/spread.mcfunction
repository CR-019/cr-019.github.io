execute store result score #temp blade2_temp run data get entity @s Pos[1]
scoreboard players add #temp blade2_temp 1
execute store result storage blade2:temp spread.y float 1 run scoreboard players get #temp blade2_temp
function blade2:effect/spread_ with storage blade2:temp spread