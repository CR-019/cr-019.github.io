scoreboard players set @s blade2_eidolon_timer 0
execute unless score @s blade2_eidolons_max matches -2147483648..2147483647 run scoreboard players set @s blade2_eidolons_max 0
execute unless score @s blade2_eidolons matches -2147483648..2147483647 run scoreboard players set @s blade2_eidolons 0
execute unless score @s blade2_eidolon_spark matches -2147483648..2147483647 run scoreboard players set @s blade2_eidolon_spark 0
execute unless score @s blade2_eidolon_ult matches -2147483648..2147483647 run scoreboard players set @s blade2_eidolon_ult 0

tellraw @s {"text": "==============","color": "gold"}
tellraw @s [{"text": "当前已激活星魂数：","color": "aqua"},{"score": {"name": "@s","objective": "blade2_eidolons"},"color": "gold"}]
tellraw @s [{"text": "最多可激活星魂数：","color": "aqua"},{"score": {"name": "@s","objective": "blade2_eidolons_max"},"color": "gold"}]
function blade2:eidolons/challenge

tellraw @s [{"text": "[激活]","color": "green","click_event": {"action": "run_command","command": "/function blade2:eidolons/activate"}},{"text": "   "},{"text": "[回退]","color": "red","click_event": {"action": "run_command","command": "/function blade2:eidolons/deactivate"}}]


tellraw @s {"text": "==============","color": "gold"}