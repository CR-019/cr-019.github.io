execute if data entity @s equipment.offhand unless predicate blade2:offhand at @s run function blade2:drop

execute unless predicate blade2:offhand run loot replace entity @s weapon.offhand loot blade2:spark

scoreboard players set #temp blade2_sparks -1
execute store result score #temp blade2_sparks run data get entity @s equipment.offhand.components."minecraft:custom_model_data".floats[0]
execute unless score @s blade2_sparks = #temp blade2_sparks run loot replace entity @s weapon.offhand loot blade2:spark

execute store result score #temp blade2_sparks run data get entity @s equipment.offhand.count
execute if score @s blade2_sparks matches 1.. unless score @s blade2_sparks = #temp blade2_sparks run loot replace entity @s weapon.offhand loot blade2:spark
execute if score @s blade2_sparks matches 0 unless score #temp blade2_sparks matches 1 run loot replace entity @s weapon.offhand loot blade2:spark