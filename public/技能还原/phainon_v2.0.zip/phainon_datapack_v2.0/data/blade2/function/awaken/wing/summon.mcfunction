execute rotated ~ 0 run summon item_display ^ ^1.3 ^ {Tags:["blade2_wings","blade2_wings_temp"],item:{id:"firework_star",components:{item_model:"sword:wings"}},teleport_duration:4,item_display:"head",brightness:{block:15,sky:15}}

scoreboard players operation @n[tag=blade2_wings_temp] blade2_uid = @s blade2_uid

tag @e[tag=blade2_wings_temp] remove blade2_wings_temp