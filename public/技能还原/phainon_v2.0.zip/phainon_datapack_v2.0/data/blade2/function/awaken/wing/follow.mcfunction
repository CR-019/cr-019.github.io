data modify storage latch:io temp.vars.target_x set from entity @n[type=player,tag=blade2_wing_temp] Pos[0]
data modify storage latch:io temp.vars.target_y set from entity @n[type=player,tag=blade2_wing_temp] Pos[1]
data modify storage latch:io temp.vars.target_z set from entity @n[type=player,tag=blade2_wing_temp] Pos[2]

execute positioned 0. 0. 0. rotated 180 0 run function blade2:awaken/wing/follow_ with storage latch:io temp.vars

execute at @n[tag=blade2_wing_temp] run rotate @s ~ 0

data modify storage latch:io temp.vars.prev_x set from storage latch:io temp.vars.target_x 
data modify storage latch:io temp.vars.prev_y set from storage latch:io temp.vars.target_y 
data modify storage latch:io temp.vars.prev_z set from storage latch:io temp.vars.target_z 