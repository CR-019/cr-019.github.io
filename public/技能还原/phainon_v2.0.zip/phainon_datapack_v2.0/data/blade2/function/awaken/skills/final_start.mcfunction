scoreboard players set @s blade2_movement -1
scoreboard players set @s blade2_timer 35
effect give @s resistance 2 5 true
summon marker ~ ~ ~ {Tags:["blade2_awaken_lock"]}
rotate @n[type=marker,tag=blade2_awaken_lock] ~ ~
function blade2:effect/1/trigger

#timeline
function blade2:clock/move_to_0