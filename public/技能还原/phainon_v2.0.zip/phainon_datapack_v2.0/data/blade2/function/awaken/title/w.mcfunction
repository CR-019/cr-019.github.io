execute unless score @s blade2_cooldown matches 1.. if score @s blade2_movement matches 1.. unless score @s blade2_w_using_lt matches 1 run data merge storage title:io {text:{"text":"\u0004"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_cooldown matches 1.. run data merge storage title:io {text:{"text":"\u0005"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute unless score @s blade2_movement matches 1.. run data merge storage title:io {text:{"text":"\u0005"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_w_using_lt matches 1 run data merge storage title:io {text:{"text":"\u0012"},font:"sword:icons",neg_font:"sword:icons_neg"}
function title:new_part

data merge storage title:io {text:{"text":"","color":"white"}, align:"left",  origin:"down-right",x:-120,y:35}
function title:new_text

#data merge storage title:io {text:{"keybind":"key.use"},font:"default_mod",neg_font:"default_neg"}
data merge storage title:io {text:{"text":"右键"},font:"default_mod",neg_font:"default_neg"}

function title:new_part

data merge storage title:io {text:{"text":"","color":"white"}, align:"left",  origin:"down-right",x:-107,y:28}
function title:new_text
