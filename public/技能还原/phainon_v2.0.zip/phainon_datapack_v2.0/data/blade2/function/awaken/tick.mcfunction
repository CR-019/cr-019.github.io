#技能
execute if predicate blade2:off_awaken if score @s blade2_cooldown matches ..0 if score @s blade2_movement matches 1.. unless score @s blade2_w_using_lt matches 1 run function blade2:awaken/skills/e_trigger
function blade2:awaken/skills/w_tick
execute if score @s blade2_q_damage matches 1.. if score @s blade2_cooldown matches ..0 if score @s blade2_movement matches 1.. unless score @s blade2_w_using_lt matches 1 run function blade2:awaken/skills/q_trigger

#手持剑
execute store result score @s blade2_temp run clear @s *[custom_data~{blade2_awaken_fill:1b}] 0
execute unless score @s blade2_temp matches 38 run function blade2:awaken/pack/fill
execute unless predicate blade2:main_awaken run function blade2:awaken/pack/fill

#冷却计数
execute if score @s blade2_cooldown matches 1 run function blade2:awaken/pack/fill
execute if score @s blade2_cooldown matches 1.. run scoreboard players remove @s blade2_cooldown 1

#bossbar
execute if score @s blade2_movement matches 0.. run function blade2:awaken/bossbar/tick

execute if score @s blade2_movement matches 0 run function blade2:awaken/bossbar/final

#xp
function blade2:awaken/xp/main

#悬浮
function blade2:awaken/float

#移除降雨
weather clear

#最终攻击
execute if score @s blade2_movement matches 0 if score @s blade2_cooldown matches ..0 run function blade2:awaken/skills/final_start
execute if score @s blade2_timer matches 1.. run scoreboard players remove @s blade2_timer 1
execute if score @s blade2_timer matches 1.. run tp @s @n[type=marker,tag=blade2_awaken_lock]
execute if score @s blade2_timer matches 0 run kill @n[type=marker,tag=blade2_awaken_lock]
execute if score @s blade2_timer matches 0 run function blade2:end

