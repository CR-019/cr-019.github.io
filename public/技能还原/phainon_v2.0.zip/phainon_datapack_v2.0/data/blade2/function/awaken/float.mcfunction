#悬浮：按住空格且动量不向上，则给予低重力效果

attribute @s gravity modifier remove blade2_awaken_float
execute if predicate blade2:float if predicate blade2:float/reverse run attribute @s gravity modifier add blade2_awaken_float -1.05 add_multiplied_total
execute if predicate blade2:float unless predicate blade2:float/reverse run attribute @s gravity modifier add blade2_awaken_float -0.3 add_multiplied_total