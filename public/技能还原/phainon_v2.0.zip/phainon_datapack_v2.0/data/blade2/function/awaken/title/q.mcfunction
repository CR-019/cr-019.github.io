execute unless score @s blade2_cooldown matches 1.. if score @s blade2_movement matches 1.. unless score @s blade2_w_using_lt matches 1 run data merge storage title:io {text:{"text":"\u0002"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_cooldown matches 1.. run data merge storage title:io {text:{"text":"\u0003"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute unless score @s blade2_movement matches 1.. run data merge storage title:io {text:{"text":"\u0003"},font:"sword:icons",neg_font:"sword:icons_neg"}
execute if score @s blade2_w_using_lt matches 1 run data merge storage title:io {text:{"text":"\u0003"},font:"sword:icons",neg_font:"sword:icons_neg"}
function title:new_part

data merge storage title:io {text:{"text":"","color":"white"}, align:"left",  origin:"down-right",x:-160,y:25}
function title:new_text

#data merge storage title:io {text:{"keybind":"key.attack"},font:"default_mod",neg_font:"default_neg"}
data merge storage title:io {text:{"text":"左键"},font:"default_mod",neg_font:"default_neg"}

function title:new_part

data merge storage title:io {text:{"text":"","color":"white"}, align:"left",  origin:"down-right",x:-152,y:18}
function title:new_text
