tag @s add blade2_awaken_pre
scoreboard players set @s blade2_timer 40
effect give @s resistance 2 5 true
summon marker ~ ~ ~ {Tags:["blade2_awaken_lock"]}
rotate @n[type=marker,tag=blade2_awaken_lock] ~ ~
playsound minecraft:entity.elder_guardian.curse player @a ~ ~ ~ 10 0.707

#timeline
function blade2:clock/move_to_100