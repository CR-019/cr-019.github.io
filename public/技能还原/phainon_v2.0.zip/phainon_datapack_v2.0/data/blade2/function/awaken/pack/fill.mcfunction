#填满背包，防止自动拾取
item replace entity @s inventory.0 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.1 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.2 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.3 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.4 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.5 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.6 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.7 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.8 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.9 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.10 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.11 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.12 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.13 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.14 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.15 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.16 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.17 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.18 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.19 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.20 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.21 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.22 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.23 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.24 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.25 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s inventory.26 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]

item replace entity @s hotbar.0 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.1 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.2 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.3 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.4 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.5 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.6 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.7 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]
item replace entity @s hotbar.8 with firework_star[custom_data={blade2_awaken_fill:1b},tooltip_display={hide_tooltip:true},item_model="sword:empty",item_name={"text":""}]

#填充主手、头盔物品
loot replace entity @s armor.head loot blade2:head
loot replace entity @s armor.chest loot blade2:wings
execute if score @s blade2_cooldown matches ..1 if score @s blade2_movement matches 1.. run loot replace entity @s weapon.mainhand loot blade2:sword_awaken
execute unless score @s blade2_cooldown matches ..1 run loot replace entity @s weapon.mainhand loot blade2:sword_awaken_cooldown
execute unless score @s blade2_movement matches 1.. run loot replace entity @s weapon.mainhand loot blade2:sword_awaken_cooldown