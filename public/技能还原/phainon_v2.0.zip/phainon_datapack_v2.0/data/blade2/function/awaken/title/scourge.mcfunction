$data merge storage title:io {text:{"text":"$(scourge)/4","color":"gold"},font:"default_mod",neg_font:"default_neg"}
function title:new_part
data merge storage title:io {text:{"text":"","color":"white"}, align:"left",  origin:"down-right",x:-100,y:90}
function title:new_text