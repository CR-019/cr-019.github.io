execute store result storage blade2:temp clock.time int 1 run scoreboard players get #clock blade2_clock
function blade2:clock/sync_ with storage blade2:temp clock