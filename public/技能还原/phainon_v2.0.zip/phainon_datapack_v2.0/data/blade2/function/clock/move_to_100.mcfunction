schedule clear blade2:clock/move_to_0
execute unless score #clock blade2_clock matches 100.. run scoreboard players add #clock blade2_clock 2
execute unless score #clock blade2_clock matches 100.. run schedule function blade2:clock/move_to_100 1t