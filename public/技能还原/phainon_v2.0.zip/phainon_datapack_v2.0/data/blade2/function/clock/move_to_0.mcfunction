schedule clear blade2:clock/move_to_100
execute unless score #clock blade2_clock matches ..0 run scoreboard players remove #clock blade2_clock 1
execute unless score #clock blade2_clock matches ..0 run schedule function blade2:clock/move_to_0 1t