time of blade2:iron_tomb pause

scoreboard players operation #temp blade2_clock = #clock blade2_clock
scoreboard players operation #temp blade2_clock -= #clock_lt blade2_clock
execute unless score #temp blade2_clock matches 0 run function blade2:clock/sync

scoreboard players operation #clock_lt blade2_clock = #clock blade2_clock